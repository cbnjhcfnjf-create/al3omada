
const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('Hello World!'));

app.listen(port, () => console.log(`Example app`));

const emj = require('./emj.json');


const moment = require("moment")
const ms = require("ms")
const { Client, Intents, MessageEmbed, Interaction, MessageButton, MessageActionRow, Modal, WebhookClient, createEmbed, MessageSelectMenu, Collection, Permissions, TextInputComponent, MessageFlags, GatewayIntentBits } = require("discord.js");
const Discord = require('discord.js');

const client = new Client({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_MEMBERS, 32767]
});
client.setMaxListeners(0)

client.login("MTMyODcxMjMyMzM4MDE1NDM3OQ.G9lm6p.SPna9GWxgPQiHNKvgvc1__hUczEi3BM1YjoY4w");
client.on("ready", () => {
  console.log(`Logged in as  ${client.user.username}`)
  client.user.setActivity(`# ~ Everest System`, { type: 'PLAYING' })
  client.user.setStatus("idle")
});

const db = require("pro.db")
const probot = require("probot-tax");
const MeetRole = "1124836425989357628" 
const staffManagerRole = "1241129866515185669"
const discorsLeader = "996364341462970388"
const OfficialRole = "1030122382179971123"
const ticketManagerRole = '1241129866515185669'
const adsManagerRole = '1122861235759747115'
const RolesRole = "1028593200803360768"
const discordStaff = "996364077817405531"
const UnderTestRole = "1206870979771367434"
const developerId = "1087401297705173042"
const bankid = "979266698689519618"
const spinbank = "979266698689519618"
const manshoratRoom = '৳・المنشورات・المميزة'
const roomschannel12345 = 'ⵌ・فتح・غلق'
const adsroom = '૱・اعلانات・المنشن'
const prefix = "$"
const lineLink = "https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&"
const logChannelID = "1250443610961219725"
const colorE = ""
const posts = "1122530314531647589"

client.on("messageCreate", msg => { 
if(msg.channel.id == "1235865430749614082"){
if(msg.author.id === "282859044593598464")return;
if(msg.author.bot)return;
msg.delete()
}
});
const { Client, Intents } = require('discord.js');
const cron = require('node-cron');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });

let config2 = {
  guildId: "1241129866422653019", // ايدي السيرفر
  channels: ["1262287540635963423", "1262287542628257865", "1262287544759095438", "1262287546843664414", "1262287548559134802", "1262287550228201543", "1262287552635994173", "1262287554250543188"], // رومات لاتجيه
  notificationChannel: "1262905922162921575", // الروم اليرسل فيه لو الرومات فتحت او انقفلت
  close_time: "00:00", // وقت القفل
  open_time: "08:00", // وقت الفتح
  line: "https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=669990a1&is=66983f21&hm=fdd0753c62c2bca1d72e9e43e1c13c98d0df050ec937fb6e3197a295a74c7566&" // الخط
};

client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}`);
  scheduleChannelCleaning();
  scheduleChannelOpenClose();
});

function scheduleChannelCleaning() {
  setInterval(async () => {
    let guild = client.guilds.cache.get(config2.guildId);
    if (!guild) return;
    for (const channelId of config2.channels) {
      const channel = guild.channels.cache.get(channelId);
      if (channel && channel.isText()) {
        try {
          const fetchedMessages = await channel.messages.fetch({ limit: 100 });
          await channel.bulkDelete(fetchedMessages);
          console.log(`Cleared messages in channel ${channelId}`);
        } catch (error) {
          console.error(`Failed to clear messages in channel ${channelId}:`, error);
        }
      } else {
        console.error(`Channel ${channelId} is not a text channel or does not exist`);
      }
    }
  }, 16 * 60 * 60 * 1000); // 16 ساعة بالميلي ثانية
}

function scheduleChannelOpenClose() {
  let close_gg = config2.close_time.split(":");
  cron.schedule(`${close_gg[1]} ${close_gg[0]} * * *`, async () => {
    let guild = client.guilds.cache.get(config2.guildId);
    if (!guild) return;
    let channel = guild.channels.cache.get(config2.notificationChannel);
    for (const c of config2.channels) {
      let ch = guild.channels.cache.get(c);
      if (!ch) continue;
      await ch.permissionOverwrites.edit(guild.id, { VIEW_CHANNEL: false }).catch(() => 0);
    }
    if (channel) {
      await channel.bulkDelete(100).catch(console.error);
      channel.send({ content: ` **تم اغلاق الرومات ، لكن لا تقلق سيتم فتح الرومات في التاسعة صباحاً اوتماتيكيا.. \@here**` });
      channel.send({ files: [config2.line] });
    }
  }, {
    timezone: "Asia/Amman"
  });

  let open_gg = config2.open_time.split(":");
  cron.schedule(`${open_gg[1]} ${open_gg[0]} * * *`, async () => {
    let guild = client.guilds.cache.get(config2.guildId);
    if (!guild) return;
    let channel = guild.channels.cache.get(config2.notificationChannel);
    for (const c of config2.channels) {
      let ch = guild.channels.cache.get(c);
      if (!ch) continue;
      await ch.permissionOverwrites.edit(guild.id, { VIEW_CHANNEL: true }).catch(() => 0);
    }
    if (channel) {
      await channel.bulkDelete(100).catch(console.error);
      channel.send({ content: `**تم فتح الرومات يمكنك النشر حالياً ، \@everyone**` });
      channel.send({ files: [config2.line] });
    }
  }, {
    timezone: "Asia/Amman"
  });
}
client.on("messageCreate", message => {
  if (message.content.startsWith(prefix + "اعلان")) {
    if (message.member.roles.cache.some(r=> r.id == discorsLeader)) {

if(message.content.startsWith(prefix + "اعلانات")) return false;
  
member = message.mentions.members.first()
      if (!member) return message.reply("** يرجى منشن صاحب الاعلان أولاً !**")
manshor = message.content.split(" ").slice(2).join(" ");
  if (!manshor) return message.reply("** يرجى وضع الاعلان أولاً !**")

let embed = new Discord.MessageEmbed()
      .setTitle(`** إختر نوع المنشن :**`)
      .setDescription(`** يرجى إختيار نوع المشنن المناسب : \`here\` أو \`everyone\`\nالاعلان :\n\`${manshor}\`**`)
      .setColor("15FFAF")
  let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("here")
        .setCustomId("adhere")
        .setStyle("SECONDARY")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("everyone")
        .setCustomId("adeve")
        .setStyle("SECONDARY")
    )

  message.reply({ embeds: [embed], components: [row] })
            }}});

client.on("interactionCreate", async interaction => {
  if (!interaction.isButton()) return;

 if (interaction.customId === "adhere") {
    if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
    const message = await interaction.channel.messages.fetch(interaction.message.id); 

const heremanshor = `@here\n${manshor}`

    
let embed2 = new Discord.MessageEmbed()
      .setTitle(`** هل انت متأكد من إرسال الاعلان ؟**`)
  .setDescription(`** يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n الاعلان :\n\`${heremanshor}**`)
      .setColor("15FFAF")
  let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("adhcompleteid")
        .setStyle("SUCCESS")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("adhcancelid")
        .setStyle("DANGER")
    )
    
    message.edit({ embeds: [embed2], components: [row2] });
      } else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    }
  } else if (interaction.customId === "adeve") {
    if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
    const message = await interaction.channel.messages.fetch(interaction.message.id); 

const evemanshor = `@everyone\n${manshor}`

    
let embed2 = new Discord.MessageEmbed()
      .setTitle(`** هل انت متأكد من إرسال الاعلان ؟**`)
  .setDescription(`** يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n الاعلان :\n\`${evemanshor}**`)
      .setColor("15FFAF")
  let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("adecompleteid")
        .setStyle("SUCCESS")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("adecancelid")
        .setStyle("DANGER")
    )
    
    message.edit({ embeds: [embed2], components: [row2] });
      } else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    }
  }
});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "adhcancelid") {
if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
  
let embed3 = new Discord.MessageEmbed()
  .setColor(`15FFAF`)
  .setDescription(`** تم إلغاء إرسال هذا الاعلان .
 بواسطة :
${interaction.member}
**`)

message.edit({ embeds: [embed3], components: [] });
} else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
}
}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "adecancelid") {
if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
  
let embed3 = new Discord.MessageEmbed()
  .setColor(`15FFAF`)
  .setDescription(`** تم إلغاء إرسال هذا الاعلان .
 بواسطة :
${interaction.member}
**`)

message.edit({ embeds: [embed3], components: [] });
} else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
}
}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "adhcompleteid") {
if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const adChannel = client.channels.cache.get('1110183189982482553');
  const adLog = interaction.guild.channels.cache.get('1124686893821476906');

  const memhere = `${member}`
  const manshorhere = `@here\n${manshor}\n

علان مدفوع فقط تبي مثله حياك <#996376383896957059>`
  
let embed5 = new Discord.MessageEmbed()
  .setColor(`15FFAF`)
  .setDescription(`** تم إرسال هذا الاعلان إلى ${adChannel}
 بواسطة :
${interaction.member}
**`)

message.edit({ embeds: [embed5], components: [] });

  await adChannel.send(`${manshorhere}`);
await adChannel.send(`${lineLink}`)

await adLog.send(`** الاعلان :\n\`${manshor}\`\n المنشن :\nhere\n المشرف المسؤول :\n${interaction.member}\n صاحب الاعلان :\n${memhere}\n تاريخ الاعلان : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await adLog.send(`${lineLink}`)
  
} else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
}
}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "adecompleteid") {
if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const adChannel2 = client.channels.cache.get('1110183189982482553');
  const adLog2 = interaction.guild.channels.cache.get('1124686893821476906');

  const memeve = `${member}`
  const manshoreve = `@everyone\n${manshor}\n

علان مدفوع فقط تبي مثله حياك <#996376383896957059>`
  
let embed5 = new Discord.MessageEmbed()
  .setColor(`15FFAF`)
  .setDescription(`** تم إرسال هذا الاعلان إلي ${adChannel2}
 بواسطة :
${interaction.member}
**`)

message.edit({ embeds: [embed5], components: [] });

  await adChannel2.send(`${manshoreve}`);
await adChannel2.send(`${lineLink}`)

await adLog2.send(`** الاعلان :\n\`${manshor}\`\n المنشن :\neveryone\n المشرف المسؤول :\n${interaction.member}\n صاحب الاعلان :\n${memeve}\n تاريخ الاعلان : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await adLog2.send(`${lineLink}`)
  
} else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
}
}});
client.on('messageCreate', (message) => {
let probot = ["282859044593598464"]
if(!probot.includes(message.author.id)) return;
  if (message.content.toLowerCase().includes('قام بتحويل') && message.channel.id === '1235936661821587557') {
    message.channel.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`);
  }
});

const replace = [
  {
    word: "متوفر",
    replace: "مت9فر"
  },
   {
    word: "بيع",
    replace: "بي3"
  },
   {
    word: "شوب",
    replace: "ش9ب"
  },
   {
    word: "ديسكورد",
    replace: "ديس_ورد"
   },
  {
    word: "تبادل",
    replace: "تبا1دل"
 },
{
  word: "توكن",
    replace: "ت9كن"
   },
  {
    word: "بوست",
    replace: "ب9ست"
   },
  {
    word: "توكنات",
    replace: "ت9كنات"
   },
  {
    word: "بوستات",
    replace: "ب9ستات"
   },
  {
    word: "حساب",
    replace: "حس1ب"
   },
  {
    word: "حسابات",
    replace: "حس1ب1ت"
   },
  {
word: "نتفيلكس",
    replace:"ن$$فيلكس"
  },
{
  word: "اون",
    replace: "ا9ن"
   },
  {
    word: "متوفر",
    replace: "مت9فر"
  },
   {
    word: "بيع",
    replace: "بي3"
  },
   {
    word: "شوب",
    replace: "ش9ب"
  }, 
   {
    word: "ديسكورد",
    replace: "ديس_ورد"
  },
   {
    word: "للبيع",
    replace: "للـب-ع"
  }, 
   {
    word: "حساب",
    replace: "7ساب"
  },
   {
    word: "سعر",
    replace: "س3ر"
  },
   {
    word: "شحن",
    replace: "شـ7ن"
  }, 
   {
    word: "فيزا",
   replace: "فـيز-"
  },
   {
    word: "سيرفر",
    replace: "سيرفr"
  },
   {
    word: "شراء",
    replace: "شـrاء"
   },
   {
    word: "نيترو",
    replace: "نيتر9"
   },

]
  
client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "tt")) {
  if(!message.member.permissions.has("ADMINISTRATOR")) return;
    const embed = new MessageEmbed()
    .setTitle("تشفير منشورك")
    .setDescription("**<:74:1242783266348466197> لتشفير منشورك يرجى الضغط على تشفير منشورك ووضع منشورك ويتم تشفيره مباشر وقم بنسخه فقط . <:21:1242766459592249394> **")
    .setColor("15FFAF")
    .setImage("https://cdn.discordapp.com/attachments/1113504839696126044/1242811736994746408/20240521_222647.jpg?ex=664f3220&is=664de0a0&hm=2ace07fc294979564c94b1c0f759abbe3a21d883d83c44581dcb9abdae65c135&")
    .setThumbnail(message.guild.iconURL())
    
      const row = new MessageActionRow()
        .addComponents(
            new MessageButton()
            .setStyle("SUCCESS")
            .setLabel("تشفير")
            .setCustomId('replace')
            
          
        )
    message.channel.send({embeds: [embed], components: [row]})
  }
})


client.on("interactionCreate", async i => {
  if (!i.isButton()) return;
  if (i.customId == "replace") {
            const modal = new Modal()
            .setTitle('تشفير')
            .setCustomId('rep')

   const replacer = new TextInputComponent()
            .setCustomId('replacetext')
            .setLabel(`قم بكتابة منشورك الذي تريد تشفيره`)
            .setMaxLength(2000)
            .setRequired(true)
            .setStyle("PARAGRAPH")
    
       const rows = [replacer].map(
                (component) => new MessageActionRow().addComponents(component)
            )
            modal.addComponents(...rows);
            i.showModal(modal);
        
  }
  
})

client.on("interactionCreate", async i => {
  if (!i.isModalSubmit()) return;
  if (i.customId == "rep") {
let text = i.fields.getTextInputValue('replacetext');
    let replaced = false;

    replace.forEach(t => {
      const regex = new RegExp(t.word, 'g');
      if (regex.test(text)) {
        text = text.replace(regex, t.replace);
        replaced = true;
      }
    });


    if (replace) {
i.reply({content: `\`تم بنجاح تشفير منشورك :\`\n\n ${text}`, ephemeral: true})
    } else {
      i.reply({content: "**عذرا حدث خطأ ما منشور غير صالح برجاء تاكد من منشورك ومحاولة مره اخرى.**", ephemeral: true})
    }
  }
  
})

client.on("messageCreate", async message => {
if (message.author.bot) return;
if (!message.channel.guild) return;
if (message.content.startsWith(prefix + 'say')) {
    if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("** 😕 You don't have permissions **"); 
}
if(!message.guild.me.permissions.has('ADMINISTRATOR')) {
  return message.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position. **`);
}
let args = message.content.split(' ').slice(2).join(' ')
let argss = message.content.split(' ')
        let channel = message.mentions.channels.first() || message.guild.channels.cache.get(argss[1])
        let attach = message.attachments.first()
        if (!channel) return message.channel.send('** 😕 Please mention channel or id **');
        if (!args) return message.channel.send('** ❌ Please select a message **');
        message.delete()
      if (!attach) {
        channel.send({content: `${args}`});
} else {
        channel.send({content: `${args}`, files: [attach]});
}
    }
});



client.on('messageCreate', async msg => {
  if(msg.content.startsWith(prefix + "send-submit")){
    if(!msg.member.permissions.has(`ADMINISTRATOR`))return;
    let row = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setStyle('PRIMARY')
      .setLabel(`اضغط للتقديم`)
      .setEmoji('📜')
      .setCustomId('submit-order')
    )
    msg.channel.send({embeds: [
      new MessageEmbed()
      .setTitle('تقديم الإدارة')
       .setImage('https://cdn.discordapp.com/attachments/1113504839696126044/1242833678292484167/20240521_222935.jpg?ex=664f468f&is=664df50f&hm=a392964cbb9eb7a612da6144c65b84409a893f2aeb0e85c783702ffd49b1dd1b&')
      .setThumbnail(msg.guild.iconURL())
      .setDescription(`** Na7la S Staff Apply・تقديم الإدارة**

> **<:74:1242783266348466197> اسمك ؟**
> **<:74:1242783266348466197> عمرك ؟**
> **<:74:1242783266348466197> من وين ؟ **
> **<:74:1242783266348466197> كم مدة تفاعلك باليوم ؟ **
> **<:74:1242783266348466197> هل لديك خبرة في سيرفرات الشوب ؟ وهل كنت اداري في سيرفر شوب قبل ؟ **
<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>
> ** يمنع الإستهبال بـ التقديم .**
> ** يمنع التزوير في معلوماتك .**
> ** يمنع التقديم بدون وضع الشعار .**
> ** التقديم مرة واحدة فقط , التقديم اكثر من مرة = رفضك<:emoji_78:1242783447689461822> **
<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>
**الشعار :** 
**! N7 - Name .**

**#N7S_Owners**`)
      .setColor('15FFAF')
    ], components: [row]})
  }
})
client.on('interactionCreate', async interaction => {
  if(!interaction.isButton())return;
  if(interaction.customId === "submit-order"){
   
    const modal = new Modal() 
	.setCustomId('modal-submit')
	.setTitle('تقديم للاداره')
    const name = new TextInputComponent() 
    .setCustomId("name")
      .setLabel("اسمك")
      .setStyle("SHORT")
      .setRequired(true);
    const age = new TextInputComponent() 
      .setCustomId("age")
      .setLabel("عمرك")
      .setStyle("SHORT")
      .setRequired(true);
      const place = new TextInputComponent() 
      .setCustomId('place')
      .setLabel('من وين')
      .setStyle('SHORT') 
      .setRequired(true);
       const discordd = new TextInputComponent() 
      .setCustomId('discord')
	  .setLabel('هل لديك خبرات في سيرفرات الشوب؟')
	  .setStyle('SHORT') 
	  .setRequired(true);
      const admin = new TextInputComponent() 
      .setCustomId('admin')
	  .setLabel('هل كنت اداري في سيرفر شوب من قبل؟')
	  .setStyle('SHORT') 
	  .setRequired(true)
      
    const row = new MessageActionRow().addComponents(name)
    const row2 = new MessageActionRow().addComponents(age)
    const row3 = new MessageActionRow().addComponents(place)
    const row4 = new MessageActionRow().addComponents(discordd)
    const row5 = new MessageActionRow().addComponents(admin)
      modal.addComponents(row, row2, row3, row4, row5)
       await interaction.showModal(modal)

			
}

    
})

client.on('interactionCreate', async (modal) => {
if (!modal.isModalSubmit()) return;
	if (modal.customId == 'modal-submit') {
   
    const name = modal.fields.getTextInputValue('name');
    const age = modal.fields.getTextInputValue('age');
    const place = modal.fields.getTextInputValue('place');
    const discord = modal.fields.getTextInputValue('discord');
    const admin = modal.fields.getTextInputValue('admin');
    const embed = new MessageEmbed()
    .addFields(
      {name: 'الاسم', value: name},
      {name: 'العمر', value: age},
      {name: 'من وين ؟', value: place},
      {name: 'هل لديك خبرات في سيرفرات الشوب؟', value: discord},
     {name: 'هل كنت اداري في سيرفر شوب من قبل؟', value: admin}
    )
    .setColor('15FFAF')
    .setThumbnail(modal.guild.iconURL())
    .setTitle(`تقديم اداره لدي ${modal.user.username}`)
    let channel = modal.guild.channels.cache.get('1236263496962936872')
    let row = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setLabel('قبول')
      .setEmoji('1242766069970501764')
      .setStyle('SUCCESS')
      .setCustomId(`accept-submit_${modal.user.id}`),
      new MessageButton()
      .setLabel('رفض')
      .setEmoji('1242766106020544542')
      .setStyle('DANGER')
      .setCustomId(`declin-submit_${modal.user.id}`)
    )
    
    channel.send({content: `<@${modal.user.id}>`, embeds: [embed], components: [row]})
    modal.reply({content: `**${emj.True} تم ارسال تقديمك**`, ephemeral: true})
  }

})

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;
  let customId = interaction.customId;
  let acceptAnddeclinRole = interaction.guild.roles.cache.get("1206870979771367434");
  let accepedRole = interaction.guild.roles.cache.get("1206870979771367434");
  if (customId.split("_")[0] == "accept-submit") {
    const member = customId.split("_")[1];
    const summiter = interaction.guild.members.cache.get(member);
    if (!interaction.member.roles.cache.has(acceptAnddeclinRole.id))
      return interaction.reply("انت لست مسؤول القبول");
    let embed = new MessageEmbed()
      .setAuthor(
        interaction.guild.name,
        interaction.guild.iconURL({ dynamic: true })
      )
      .setDescription(`تم قبول ${summiter}\n الاداري: ${interaction.member}`)
      .setColor("GREEN");
    summiter.roles.add(accepedRole.id).then(async () => {
        const acceptedEmbed = new MessageEmbed().setDescription(`**مرحبا ، لقد تم قبولك مبدئياَ في سيرفر __نحلة S__
      يرجى فتح تكت <#1235935921883447396> تعليم لكي يتم تعليمك و اختبارك 
      نتمنى لك حظا موفقاً🌹.**`)
       summiter.send({embeds: [acceptedEmbed]}).catch(e => {
        return interaction.reply(`error with sending congrats for submiting ${summiter}`)
      })
    }).catch(e => {
      return interaction.reply(`error with give role for ${summiter}`)
    })
    interaction.reply({ embeds: [embed] });
      interaction.message.edit({components: []})
  } else if(customId.split("_")[0] == "declin-submit") {
    let member = customId.split("_")[1];
    const summiter = interaction.guild.members.cache.get(member);
    if (!interaction.member.roles.cache.has(acceptAnddeclinRole.id))
    return interaction.reply("انت لست مسؤول القبول");
    let embed = new MessageEmbed()
      .setAuthor(
        interaction.guild.name,
        interaction.guild.iconURL({ dynamic: true })
      )
      .setDescription(`تم رفض ${summiter}\n الاداري: ${interaction.member}`)
      .setColor("RED");
      const declinedEmbed = new MessageEmbed().setDescription(`**مرحبا ، نعتذر لقد تم رفضك في سيرفر __نحلة S__
      بلتوفيق لك**`)
    await interaction.reply({ embeds: [embed] });
      interaction.message.edit({components: []})
        summiter.send({embeds: [declinedEmbed]}).catch(e => {
         interaction.reply(`error with sending sorry for submiting ${summiter}`)
      })
  }
});

const logChannelId2 = '1243284239173025843';
const logWheelSpin = (userId, commandAuthorId, prize, wheelType) => {
  const currentDate = new Date().toLocaleString();
  // إعداد رسالة الإيمبد
  const logEmbed = new MessageEmbed()
    .setColor('#15FFAF')
    .setTitle('Wheel Spin Log')
    .addFields(
      { name: 'التاريخ', value: currentDate, inline: true },
      { name: 'ايدي الشخص', value: userId, inline: true },
      { name: 'ايدي المشرف', value: commandAuthorId, inline: true },
      { name: 'الجائزة', value: prize, inline: true },
      { name: 'نوع العجلة', value: wheelType, inline: true },  
    );

  // إرسال رسالة الإيمبد إلى القناة المحددة
  const logChannel = client.channels.cache.get(logChannelId2);
  if (logChannel) {
    logChannel.send({ embeds: [logEmbed] });
  } else {
    console.error('[ERROR] - تعذر العثور على قناة اللوج. تحقق من إعدادات logChannelId2.');
  }
};
// إعداد زر الـ Spin
const perms = '996364077817405531';

// Your existing code for initializing the client and other imports...

client.on('messageCreate', (message) => {
  if (message.content === '$spin') {
    if (message.member.roles.cache.some((role) => role.name === 'Spin') || message.member.roles.cache.some(r => r.id == perms)) {
      const button = new MessageButton()
        .setStyle('SUCCESS')
        .setLabel('Spin')
        .setCustomId('spin_button');
      const row = new MessageActionRow().addComponents(button);
      const embed = new MessageEmbed()
        .setColor('15FFAF')
        .setTitle(`**  Na7la \`S\` Wheel Of Luck・عجلة الحظ**`)
        .setDescription('> ** إضغط على الزر Spin لتدوير العجلة .**');
      message.channel.send({ embeds: [embed], components: [row] });
    } else {
      message.author.send({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    }
  }
});

client.on('interactionCreate', async (interaction) => {
    if(!interaction.isButton()) return;
  if (interaction.customId == "spin_button") {
    if (interaction.member.roles.cache.some((role) => role.name === 'Member') || interaction.member.roles.cache.some(r => r.id == perms)) {
      const prizes = [
        { name: '<@&996382760564445184>', chance: 0.4 },
        { name: '<@&996382617198927873>', chance: 0.4 },
        { name: '50k', chance: 0.5 },
        { name: 'خصم 50', chance: 0.4 },
        { name: '70k', chance: 0.4 },
        { name: 'اعلان هير', chance: 0.3 },
        { name: 'اعلان ايفري', chance: 0.2 },
        { name: 'منشور هير', chance: 0.4 },
        { name: 'منشور ايفري', chance: 0.3 },
        
      ];
      const totalChance = prizes.reduce((acc, prize) => acc + prize.chance, 0);
      const random = Math.random() * totalChance;
      let selectedPrize = null;
      let cumulativeChance = 0;

      for (const prize of prizes) {
        cumulativeChance += prize.chance;
        if (random < cumulativeChance) {
          selectedPrize = prize;
          break;
        }
      }

      // Call the logWheelSpin function to log information
      logWheelSpin(interaction.user.id, interaction.member.user.id, selectedPrize.name, 'Spin');

      // Defer the reply before sending the interaction
      await interaction.deferReply();

      // Mention the user who clicked the button in the follow-up message
      if (selectedPrize) {
        await interaction.followUp(`** ${emj .Give} مبروك ! ${interaction.user} لقد ربحت : ${selectedPrize.name}**`);
      } else {
        await interaction.followUp(`**لف مرة أخري ${interaction.user} مجانا **`);
      }

      // Delete the original message
      await interaction.message.delete();
    } else {
      await interaction.reply({ content: `** لا يمكنك إستخام هذا الزر .**`, ephemeral: true });
    }
  }
});

// إعداد زر الـ VIP Spin
        
client.on('messageCreate', (message) => {
  if (message.content === '$vipspin') {
    if (message.member.roles.cache.some((role) => role.name === 'Spin') || message.member.roles.cache.some(r => r.id == perms)) {
      const button = new MessageButton()
        .setStyle('SUCCESS')
        .setLabel('VIP Spin')
        .setCustomId('spin_button1');
      const row = new MessageActionRow().addComponents(button);
      const embed = new MessageEmbed()
        .setColor('15FFAF')
        .setTitle(`**  Na7la \`S\` VIP Wheel Of Luck・عجلة الحظ**`)
        .setDescription('> ** إضغط على الزر VIP Spin لتدوير العجلة .**');
      message.channel.send({ embeds: [embed], components: [row] });
    } else {
      message.author.send({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    } 
  }
});

// استجابة الزر الـ VIP Spin
client.on('interactionCreate', async (interaction) => {
  if(!interaction.isButton()) return;
  if (interaction.customId == "spin_button1") {
    if (interaction.member.roles.cache.some((role) => role.name === 'Member') || interaction.member.roles.cache.some(r => r.id == perms)) {
      const prizes = [
        { name: '<@&996365835465674792>', chance: 0.3 },
        { name: '<@&1173940676619157536>', chance: 0.3 },
      
        { name: '80k', chance: 0.3 },
        { name: '120k', chance: 0.2 },
        { name: '200k', chance: 0.2 },
        { name: '250k', chance: 0.1 },
        { name: '650k', chance: 0.0 },
        { name: 'مليون كريديت ', chance: 0.0 },
      ];
      const totalChance = prizes.reduce((acc, prize) => acc + prize.chance, 0);
      const random = Math.random() * totalChance;
      let selectedPrize = null;
      let cumulativeChance = 0;

      for (const prize of prizes) {
        cumulativeChance += prize.chance;
        if (random < cumulativeChance) {
          selectedPrize = prize;
          break;
        }
      }

      // دعوة وظيفة اللوج لتسجيل المعلومات
      logWheelSpin(interaction.user.id, interaction.member.user.id, selectedPrize.name, 'VIP Spin');

      await interaction.deferReply();

      if (selectedPrize) {
        await interaction.followUp(`** ${emj.Give} مبروك ! لقد ربحت : ${selectedPrize.name}**`);
      } else {
        await interaction.followUp('** لف مرة أخري مجانا**');
      }

      // Delete the original message
      await interaction.message.delete();
    } else {
      await interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    }
  }
});

/// الطلبات

client.on('messageCreate', async message => {
  if (message.content.startsWith('$نداء') && message.member.roles.cache.has(discordStaff) || message.content.startsWith('$come') && message.member.roles.cache.has(discordStaff)) {
    try {
      const channel = message.channel;
      const args = message.content.split(' ');
      const user = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
      const commandLink = `https://discord.com/channels/${message.guild.id}/${message.channel.id}/${message.id}`;
      if (!user) return message.reply("**منشن الشخص أولاً أو ضع الإيدي !**")
      await user.send(`** يرجى التوجه إلى ${channel} في أقرب وقت !\n  الإستدعاء من قبل : ${message.member} .\n  رسالة الإستدعاء : ${commandLink}**`)
      await message.reply(`**${emj.True} لقد تم نداء ${user} إلى هذا الروم بنجاح !**`)
    } catch {
      await message.reply(`**${emj.False} لا يمكنني ارسال رسالة لهذا الشخص !**`)
    }
  }
});
      

      
      
   

    

    

  
      
    
 


 		



client.on("ready" , () => {
  const guild1 = "996135517320134776"
  const guild = client.guilds.cache.get(guild1)
  var commands
    if(guild) {
      commands = guild.commands
    } else {
      commands = client.application.commands
    }
      commands.create({
        name:"embed",
        description:"Make Your Own Embed !",
        options:[
          {
            name:`title`,
            description:"Specfiy The Title For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:true
          },
          {
            name:`description`,
            description:"Specfiy The Description For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:true
          },
          {
            name:`color`,
            description:"Specfiy The Color In Large letters For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:true
          },
          {
            name:`image`,
            description:"Specfiy The Link Of Image For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:false
          },
          {
            name:`thumbnail`,
            description:"Specfiy The Link Of Thumbnail For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:false
          }
        ]
    })
  commands.create({
         name:"abdo",
        description:"تبي تشوف سومو ؟!"
  })
  });


  client.on("interactionCreate" , interaction => {
    if(interaction.commandName == "embed") {
      let title = interaction.options.getString('title');
      let description = interaction.options.getString('description');
      let color = interaction.options.getString('color');
      let image = interaction.options.getString('image');
      let thumb = interaction.options.getString('thumbnail')
      let embed = new Discord.MessageEmbed()
      .setTitle(`${title}`)
      .setColor(`${color}`)
      .setDescription(`${description}`)
      if(image) {
        embed.setImage(`${image}`)
      }
      if(thumb) {
        embed.setThumbnail(`${thumb}`)
      }
      interaction.reply({content : `**تم انشاء الايمبيد !**` , ephemeral:true})
      interaction.channel.send({embeds:[embed]}).catch(err=>{})
    }
  });

  client.on("interactionCreate" , interaction => {
    if(interaction.commandName == "abdo") {
      let embed = new Discord.MessageEmbed()
      .setTitle("**😱**")
      .setDescription("**لا تستطيع مقاومة الجمال**")
      .setImage("https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/FullMoon2010.jpg/1200px-FullMoon2010.jpg")
      .setColor("BLACK")
      interaction.reply({embeds:[embed]})
    }
  });


client.on("messageCreate" , message => {
if(message.author.bot) return;
if(message.channel.name.startsWith("〢↯・")) {
  message.channel.send(`${lineLink}`)
}
})


//////////

//////////



///////////////

client.on('messageCreate', async message => {
if (message.content.startsWith(prefix + 'تقيم') || message.content.startsWith(prefix + 'تقييم')) {
if(message.content.startsWith(prefix + "تقيمات")) return false;
if(message.content.startsWith(prefix + "تقييمات")) return false;
const now = new Date();
const args = message.content.split(" ")
const user = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
if(!user) return message.reply("**منشن الإداري أولاً !**")
const titlefeed = message.content.split(" ").slice(2).join(" ")
if (!titlefeed) return message.reply("**يرجى وضع محتوى التقييم أولاً .**")
if(user.id === message.member.id) return message.reply("**لا تستطيع تقييم نفسك !**")
if(!user.roles.cache.some(r=>r.id == 1121187991763812435)) return message.reply("**هذا الشخص ليس اداري !**")
const feedbackData = db.get(`feedback_${user.id}`);
if(feedbackData) {
for (const entry of feedbackData) {
  const memberId = entry.member;
  if(memberId == message.member.id) return message.reply("**لا يمكنك تقييم الشخص اكثر من مرة !**")}}
const FeedBackLog = await message.client.channels.fetch("1128638873166155846");

 let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
      .setLabel("⭐ 1")
      .setCustomId("s1")
      .setStyle("SECONDARY"),
            new Discord.MessageButton()
      .setLabel("⭐ 2")
      .setCustomId("s2")
      .setStyle("SECONDARY"),
            new Discord.MessageButton()
      .setLabel("⭐ 3")
      .setCustomId("s3")
      .setStyle("SECONDARY"),
            new Discord.MessageButton()
      .setLabel("⭐ 4")
      .setCustomId("s4")
      .setStyle("SECONDARY"),
            new Discord.MessageButton()
      .setLabel("⭐ 5")
      .setCustomId("s5")
      .setStyle("SECONDARY"),
    )

message.reply({content:`**${emj.Dot} الاداري : ${user}**\n**${emj.Dot} تقييمك : ${titlefeed}**\n**${emj.Warn} يرجى اختيار عدد النجوم التي تعطيها للاداري عبر الازرار في الاسفل**` , components:[row]}).then(m => {

db.set(`temp_${m.id}` , message.member.id)
db.set(`tempuser_${message.member.id}` , user.id)
db.set(`tempfeedback_${message.member.id}` , titlefeed)
})

}
});

client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {
  if(interaction.customId == "s1") {
  if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})
  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 1**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:1 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)


  }
  }
});
client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {

    if(interaction.customId == "s2") {
        if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})

  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 2**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:2 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)


  }
    }
});
client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {

    if(interaction.customId == "s3") {
       if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})

  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 3**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:3 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)



  }
    }
});
client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {

    if(interaction.customId == "s4") {
        if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})

  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 4**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:4 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)

      }
}

});
  client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {

    if(interaction.customId == "s5") {
       if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})
  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 5**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:5 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)


  }

  }
})

client.on("messageCreate" , async message => {
if(message.content.startsWith(prefix + "تقييمات")) {
    const args = message.content.split(" ")
    const member = message.mentions.members.first() ||     message.guild.members.cache.find(r=>r.id == args[1])
    if(!member) return message.reply("**منشن الإداري أولاً !**")
    if(!db.has(`feedback_${member.id}`)) return message.reply("**هذا الشخص ليس لديه تقييمات !**")
    if(!member.roles.cache.some(r=>r.id == 1121187991763812435)) return message.reply("**هذا الشخص ليس اداري !**")
    const feedbackData = db.get(`feedback_${member.id}`); 
let usersData = [];
    for (const entry of feedbackData) {
      var stars = entry.stars;
      var title = entry.title;
      var memberId = entry.member;
      var star1 = "⭐";
      var star2 = "⭐⭐";
      var star3 = "⭐⭐⭐";
      var star4 = "⭐⭐⭐⭐";
      var star5 = "⭐⭐⭐⭐⭐";
      usersData.push({ user: memberId, stars, title });
    }
    usersData.sort((a, b) => b.stars - a.stars);
    const embed = new MessageEmbed()
      .setColor(`${colorE}`)
      .setDescription(`**${member} Reviews :**`);
    const topUsers = usersData.slice(0, 20);
    topUsers.forEach((user, index) => {
      var starsString = "";
      if (user.stars == 1) {
        starsString = star1;
      } else if (user.stars == 2) {
        starsString = star2;
      } else if (user.stars == 3) {
        starsString = star3;
      } else if (user.stars == 4) {
        starsString = star4;
      } else if (user.stars == 5) {
        starsString = star5;
      }
      embed.addField(`**#${index + 1} | **`, `**المقيم : <@${user.user}>\n- عدد النجوم : ${starsString}\n- التقييم : ${user.title}**\n`);});
message.reply({embeds:[embed]})}});

///////////////

//////////////





let sug = ["1218917277420879922"]; 
client.on("messageCreate",async (message) => {
        let args = message.content.split(",");
  if (message.author.bot) return;
if(sug.includes(message.channel.id)) {
    message.delete()
    const embed = new Discord.MessageEmbed()
.setAuthor({name: message.author.tag,iconURL: 
 message.author.avatarURL({dynamic:true})})
.setColor(`#15FFAF`)
.setThumbnail(message.guild.iconURL({ dynamic: false }))
.setDescription(`> **${args}**`)
.setTimestamp()
let attachm = message.attachments.first()
if (attachm) {
    embed.setImage(attachm.proxyURL)
}  
message.channel.send({ embeds: [embed] }).then(msg => {
 msg.react('<:emoji_75:1242783380437991424>').then(() => {   
  
 msg.react('<:emoji_76:1242783398997524521>')
})
message.channel.send(lineLink)
})
.catch(console.error) 
}
});  





///////////////
client.on('messageCreate', async message => {
if (message.content.startsWith('$رول') && message.member.roles.cache.has(RolesRole) || message.content.startsWith('$role') && message.member.roles.cache.has(RolesRole)) {
 if(message.content.startsWith(prefix + "رولات")) return false;
  const args = message.content.split(' ');
    const user = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
    if (!user) return message.reply("**منشن الشخص أولاً أو ضع الإيدي !**")
    if(!args) return message.reply("**منشن الشخص أولاً أو ضع الإيدي !**")
    let row = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setPlaceholder("اختر نوع الدور..")
          .setCustomId('menu-select')
          .setMaxValues(1)
          .addOptions([
            {
              label: 'رتب بائعين',
              value: 'sellR'
            },
            {
              label: 'رتب اخرى',
              value: 'otherR'
            } ]) )
    let m = await message.reply({ content: `**${emj.Dot} يرجى تحديد نوع الرتبة :**`, components: [row] })
  db.set(`giverole_${m.id}` , user.id)}});

client.on("interactionCreate" , interaction => {
  if(interaction.customId == "menu-select") {
  if (interaction.values[0] === 'sellR') {
if (interaction.member.roles.cache.has(RolesRole)) {
let row1 = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setPlaceholder("Select Role ..")
          .setCustomId('menu-select1')
          .setMaxValues(5)
          .addOptions([
              {

              label: '🜲 || NA7LA S',

              value: '1211710662481543268'
              },
              {
              label: '🜲 || N7 SUPERHERO',
              value: '1173940676619157536'
              },
              {
               
              label: '🜲 || N7',
              value: '996365835465674792'
              },
              {
              
              label: '🜲 || BEE',
              value: '996368935211503616'
            },
            {
              label: '🜲 || HONEY',
              value: '996382617198927873'
            },
            {
              label: '🜲 || A ROSE',
              value: '996382760564445184'
            },
            {
              label: '🜲 || Flower',
              value: '996382954521624666'
            },
            {
              label: '🜲 || Designer S',
              value: '997259592176246835'
            },
            {
              label: '🜲 || Developer S',
              value: '997260131962204262'
            
            
              
            }, ]) )
        interaction.message.edit({ content: `**${emj.Dot} يرجى تحديد الرتبة :**`, components: [row1] })
interaction.deferUpdate() }}
if (interaction.values[0] === 'otherR') {
if (interaction.member.roles.cache.has(RolesRole)) {
let row1 = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setPlaceholder("Select Role ..")
          .setCustomId('menu-select2')
          .setMaxValues(2)
          .addOptions([
            {
              label: '🜲 || Trust S',
              value: '1028594799961444472'
            },
            {
              label: 'warn 100%',
              value: '996693069183332352'
            },
            {
              label: 'warn 50%',
              value: '996693208111251477'
            
            
            }, ]) )
        interaction.message.edit({ content: `**${emj.Dot} يرجى تحديد الرتبة :**`, components: [row1] })
  interaction.deferUpdate() }}}});

client.on("interactionCreate" , async interaction => {
  if(interaction.isSelectMenu()) {
    if(interaction.customId == "menu-select1") {
      if (interaction.member.roles.cache.has(RolesRole)) {
      let rolesAdded = [];
      let rolesRemoved = [];
      let u = db.get(`giverole_${interaction.message.id}`)
      let member = interaction.guild.members.cache.find(r=>r.id == u)
      let roles = interaction.values;
      for (const r of roles) {
        var s;
        const role = interaction.guild.roles.cache.find(ro=>ro.id == r)
        if(role) {
    if(member.roles.cache.some(ro=>ro.id == r)) {
          await member.roles.remove([role])
          rolesRemoved.push(role.name.replace(/\|\|/g, '')); } else {
          await member.roles.add([role])
          rolesAdded.push(role.name.replace(/\|\|/g, '')); }}}
      let message = `**${emj.Lift} تم تحديث رتب ${member}**\n`;
    if (rolesAdded.length > 0) {
      message += `> **${emj.Dot} الرتب التي تم اضافتها : ${rolesAdded.join(' , ')}**\n`; }
    if (rolesRemoved.length > 0) {
      message += `> **${emj.Dot} الرتب التي تم ازالتها : ${rolesRemoved.join(' , ')}**\n`; }
 interaction.message.edit({content:`${message}` , components:[]})
      interaction.deferUpdate()
        db.delete(`giverole_${interaction.message.id}`) }} 
    if(interaction.customId == "menu-select2") {
if (interaction.member.roles.cache.has(RolesRole)) {
      let rolesAdded = [];
      let rolesRemoved = [];
      let u = db.get(`giverole_${interaction.message.id}`)
      let member = interaction.guild.members.cache.find(r=>r.id == u)
      let roles = interaction.values;
      for (const r of roles) {
        var s;
        const role = interaction.guild.roles.cache.find(ro=>ro.id == r)
        if(role) {
      if(member.roles.cache.some(ro=>ro.id == r)) {
          await member.roles.remove([role])
          rolesRemoved.push(role.name.replace(/\|\|/g, '')); } else {
          await member.roles.add([role])
          rolesAdded.push(role.name.replace(/\|\|/g, '')); }}}
      let message = `**${emj.Lift} تم تحديث رتب ${member}**\n`;
    if (rolesAdded.length > 0) {
      message += `> **${emj.Dot} الرتب التي تم اضافتها : ${rolesAdded.join(' , ')}**\n`; }
    if (rolesRemoved.length > 0) {
      message += `> **${emj.Dot} الرتب التي تم ازالتها : ${rolesRemoved.join(' , ')}**\n`; }
 interaction.message.edit({content:`${message}` , components:[]})
      interaction.deferUpdate()
db.delete(`giverole_${interaction.message.id}`) }}}});

///////////////
client.on("messageCreate", async message => {
if(message.author.bot || !message.guild) return;
    if (message.content.startsWith(prefix + 'embed') || (message.content.startsWith(prefix + 'e'))) {
      if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
if(!message.guild.me.permissions.has('ADMINISTRATOR')) {
  return message.reply("**للأسف انا لا امتلك صلاحية `ADMINISTRATOR`**");
}
      await message.channel.sendTyping();
let args = message.content.split(' ').slice(1).join(' ')
if (!args) return message.reply('**يرجى وضع النص أولاً .**')
message.delete();
const embed = new Discord.MessageEmbed()
    .setDescription(`${args}`) 
   .setColor(`${colorE}`) 
let attach = message.attachments.first();
if (attach) {
    embed.setImage(attach.proxyURL) }
message.channel.send({embeds: [embed]}); }})

///////////////

let manshor;
let member;

client.on("messageCreate", message => {
  if (message.content.startsWith(prefix + "منشور")) {
if (message.member.roles.cache.has('1122530314531647589') || message.member.permissions.has("ADMINISTRATOR")) {

if(message.content.startsWith(prefix + "منشورات")) return false;

member = message.mentions.members.first()
      if (!member) return message.reply(`**${emj.False} يرجى منشن صاحب المنشور أولاً !**`)
manshor = message.content.split(" ").slice(2).join(" ");
  if (!manshor) return message.reply(`**${emj.False} يرجى وضع المنشور أولاً !**`)

let embed = new Discord.MessageEmbed()
      .setTitle(`**${emj.Lift} إختر نوع المنشن :**`)
      .setDescription(`**${emj.Dot} يرجى إختيار نوع المشنن المناسب : \`here\` أو \`everyone\`\n${emj.Dot} المنشور :\n\`${manshor}\`**`)
      .setColor(`${colorE}`)
  let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("here")
        .setCustomId("menthere")
        .setStyle("SECONDARY")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("everyone")
        .setCustomId("menteve")
        .setStyle("SECONDARY")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("no mention")
        .setCustomId("nomen")
        .setStyle("SECONDARY")
    )

  message.reply({ embeds: [embed], components: [row] })
            }}});

client.on("interactionCreate", async interaction => {
  if (!interaction.isButton()) return;

  if (interaction.customId === "menthere") {
    if (interaction.member.roles.cache.some((role) => role.id === posts)) {
    const message = await interaction.channel.messages.fetch(interaction.message.id);

    const heremanshor = `${manshor}\n@here`

let embed1 = new Discord.MessageEmbed()
      .setTitle(`**${emj.Lift} هل انت متأكد من إرسال المنشور ؟**`)
  .setDescription(`**${emj.Dot} يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n${emj.Dot} المنشور :\n\`${heremanshor}\n\nتواصل مع : ${member}\`**`)
      .setColor(`${colorE}`)
  let row1 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("completeid")
        .setStyle("SUCCESS")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("cancelid")
        .setStyle("DANGER")
    )
      interaction.deferUpdate()

    message.edit({ embeds: [embed1], components: [row1] });     } else {
      interaction.reply({ content: `**${emj.False} لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });    } } else if (interaction.customId === "menteve") {
    if (interaction.member.roles.cache.some((role) => role.id === posts)) {
    const message = await interaction.channel.messages.fetch(interaction.message.id); 
const evemanshor = `${manshor}\n@everyone`
let embed2 = new Discord.MessageEmbed()
      .setTitle(`**${emj.Lift} هل انت متأكد من إرسال المنشور ؟**`)
  .setDescription(`**${emj.Dot} يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n${emj.Dot} المنشور :\n\`${evemanshor}\n\nتواصل مع : ${member}\`**`)
      .setColor("EA3648")
  let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("completeid2")
        .setStyle("SUCCESS")   )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("cancelid")
        .setStyle("DANGER")   )
    interaction.deferUpdate()
    message.edit({ embeds: [embed2], components: [row2] });     } else {
      interaction.reply({ content: `**${emj.False}
 لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });   }  } else if (interaction.customId === "nomen") {
    if (interaction.member.roles.cache.some((role) => role.id === posts)) {
    const message = await interaction.channel.messages.fetch(interaction.message.id); 
const nomenmanshor = `${manshor}`
let embed2 = new Discord.MessageEmbed()
      .setTitle(`**${emj.Lift} هل انت متأكد من إرسال المنشور ؟**`)
  .setDescription(`**${emj.Dot} يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n${emj.Dot} المنشور :\n\`${nomenmanshor}\n\nتواصل مع : ${member}\`**`)
      .setColor(`${colorE}`)
  let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("completeid3")
        .setStyle("SUCCESS")    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("cancelid")
        .setStyle("DANGER")    )
    interaction.deferUpdate()
    message.edit({ embeds: [embed2], components: [row2] }); } else {
      interaction.reply({ content: `**${emj.False} لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "cancelid") {
if (interaction.member.roles.cache.some((role) => role.id === posts)) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
let embed3 = new Discord.MessageEmbed()
  .setColor(`EA3648`)
  .setDescription(`**${emj.Dot} تم إلغاء إرسال هذا المنشور .
${emj.Dot} بواسطة :
${interaction.member}
**`)
interaction.deferUpdate()
message.edit({ embeds: [embed3], components: [] }); } else {
      interaction.reply({ content: `**${emj.False} لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "completeid") {
if (interaction.member.roles.cache.some(r=>r.id == posts)) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const ManshoratChannel = client.channels.cache.find(channel => channel.name === manshoratRoom);
const ManshoratLog = client.channels.cache.get('1105215612810170409');
  const memhere = `${member}`
  const manshorhere = `${manshor}\n\nتواصل مع : ${memhere}\n@here`
let embed4 = new Discord.MessageEmbed()
  .setColor(`${colorE}`)
  .setDescription(`**${emj.Dot} تم إرسال هذا المنشور إلى ${ManshoratChannel}
${emj.Dot} بواسطة :
${interaction.member}
**`)
message.edit({ embeds: [embed4], components: [] });
interaction.deferUpdate()
await ManshoratChannel.send(`${manshorhere}`)

  await ManshoratChannel.send(`${lineLink}`)

//await ManshoratChannel.send(`${lineLink}`)
await ManshoratLog.send(`**${emj.Dot} المنشور :\n\`${manshor}\`\n${emj.Dot} المنشن :\nhere\n${emj.Dot} المشرف المسؤول :\n${interaction.member}\n${emj.Dot} صاحب المنشور :\n${memhere}\n${emj.Dot} تاريخ المنشور : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await ManshoratLog.send(`${lineLink}`) } else {
      interaction.reply({ content: `**${emj.False}
 لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "completeid2") {
if (interaction.member.roles.cache.some((role) => role.id === posts) ) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const ManshoratChannel2 = client.channels.cache.find(channel => channel.name === manshoratRoom);
  const ManshoratLog2 = interaction.guild.channels.cache.get('1105215612810170409');

  const memeve = `${member}`
  const manshoreve = `${manshor}\n\nتواصل مع : ${memeve}\n@everyone`

let embed5 = new Discord.MessageEmbed()
  .setColor(`${colorE}`)
  .setDescription(`**${emj.Dot} تم إرسال هذا المنشور إلى ${ManshoratChannel2}
${emj.Dot} بواسطة :
${interaction.member}
**`)
message.edit({ embeds: [embed5], components: [] });
interaction.deferUpdate()
await ManshoratChannel2.send(`${manshoreve}`);

  await ManshoratChannel2.send(`${lineLink}`)

await ManshoratLog2.send(`**${emj.Dot} المنشور :\n\`${manshor}\`\n${emj.Dot} المنشن :\neveryone\n${emj.Dot} المشرف المسؤول :\n${interaction.member}\n${emj.Dot} صاحب المنشور :\n${memeve}\n${emj.Dot} تاريخ المنشور : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await ManshoratLog2.send(`${lineLink}`) } else {
      interaction.reply({ content: `**${emj.False} لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "completeid3") {
if (interaction.member.roles.cache.some(r=>r.id == posts)) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const ManshoratChannel3 = client.channels.cache.find(channel => channel.name === manshoratRoom);
const ManshoratLog3 = client.channels.cache.get('1105215612810170409');
  const nomen = `${member}`
  const manshorno = `${manshor}\n\nتواصل مع : ${nomen}`
let embed4 = new Discord.MessageEmbed()
  .setColor(`${colorE}`)
  .setDescription(`**${emj.Dot} تم إرسال هذا المنشور إلى ${ManshoratChannel3}
${emj.Dot} بواسطة :
${interaction.member}
**`)
message.edit({ embeds: [embed4], components: [] });
interaction.deferUpdate()

await ManshoratChannel3.send(`${manshorno}`)

await ManshoratChannel3.send(`${lineLink}`)

await ManshoratLog3.send(`**${emj.Dot} المنشور :\n\`${manshor}\`\n${emj.Dot} المنشن :\nno mention\n${emj.Dot} المشرف المسؤول :\n${interaction.member}\n${emj.Dot} صاحب المنشور :\n${nomen}\n${emj.Dot} تاريخ المنشور : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await ManshoratLog3.send(`${lineLink}`) } else {
      interaction.reply({ content: `**${emj.False}
 لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

/////////////// 
client.on("messageCreate", async message => {
  let args = message.content
    .split(" ")
    .slice(1)
    .join(" ");
  if (args.endsWith("b")) {
    args = args.replace(/b/gi, "") * 1000000000;
  } else if (args.endsWith("m")) {
    args = args.replace(/m/gi, "") * 1000000;
  } else if (args.endsWith("k")) {
    args = args.replace(/k/gi, "") * 1000;
  }

  if (message.author.bot) return;
  if (!message.guild) return;
  if (
    message.content.startsWith(prefix + "/#sjnskwndnsk") ||
    message.content.startsWith("ضريبة") ||
    message.content.startsWith("ضريبه") ||
    message.content.startsWith("$tax") ||
    message.content.startsWith("$ضريبه") ||
    message.content.startsWith("$ضريبة")
  ) {
    let args2 = parseInt(args);
    let tax = Math.floor(args2 * (20 / 19) + 1);
    let tax2 = Math.floor(args2 * (20 / 19) + 1 - args2);
    let tax3 = Math.floor(tax2 * (20 / 19) + 1);
    let tax4 = Math.floor(tax2 + tax3 + args2);
    let embed1 = new Discord.MessageEmbed()
      .setTitle(`**${emj.False} | Error \`:\`**`)
      .setDescription("**يرجى وضع المبلغ المراد حساب ضريبته .**")
      .setThumbnail(message.author.avatarURL({ dynamic: true }))
      .setColor(`${colorE}`)
      .setTimestamp()
      .setFooter("# ~ Na7la S.");
    if (!args2) return message.channel.send({ embeds: [embed1] });
    let embed2 = new Discord.MessageEmbed()
      .setTitle(`**${emj.False} | Error \`:\`**`)
      .setDescription("**يرجى وضع المبلغ المراد حساب ضريبته .**")
      .setThumbnail(message.author.avatarURL({ dynamic: true }))
      .setColor(`${colorE}`)
      .setTimestamp()
      .setFooter("# ~ Na7la S.");
    if (isNaN(args2)) return message.channel.send({ embeds: [embed2] });
    if (args2 < 1) return message.channel.send(3);
    let embed4 = new Discord.MessageEmbed()
      .setTitle(`**${emj.Right} | Tax \`:\`**`)
      .setDescription(`**${emj.Dot} The amount to be paid \`:\` 1**`)
      .setThumbnail(message.author.avatarURL({ dynamic: true }))
      .setColor(`${colorE}`)
      .setTimestamp()
      .setFooter("# ~ Na7la S.");
    if (args2 == 1) return message.channel.send({ embeds: [embed4] });
    let taxmsg = new Discord.MessageEmbed()
      .setTitle(`**${emj.Right} | Tax \`:\`**`)
      .setColor(`${colorE}`)
      .setDescription(`**${emj.Dot} The amount to be paid \`:\` ${tax}\n${emj.Dot} Mediator tax \`:\` \`الوسيط\` ${tax4}**`)
      .setFooter("# ~ Na7la S.")
      .setThumbnail(message.author.avatarURL({ dynamic: true }))
      .setTimestamp();
if (args2 >= 100000000) {
      taxmsg.setImage(`https://i8.ae/OlCHy`); 
    }
    message.channel.send({ embeds: [taxmsg] }); 
  }});

///////////////
client.on("messageCreate", message => {
  if (message.content.startsWith(prefix + "staff-role")) {
          if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
      let r = message.content.split(" ").slice(1).join(" ")
      let role = message.guild.roles.cache.find(r => r.id == r)
      if (!r) {
        if (!role) {
          if (isNaN(r)) {
            message.reply("> **Error : Please put the rank ID**") 
          }
        }
      }
      db.set(`role_${message.guild.id}`, r)
      message.reply(`> **تم تعيين رتبة <@&${r}> مستخدم لـ زر الكلايم .**`) 

  }
});

client.on("channelCreate", channel => {
  if (channel.name.startsWith("ticket-")) {
    let embed = new Discord.MessageEmbed()
      .setDescription("**إضغط على الزر لتصبح مسؤول التذكرة**")
      .setColor(`${colorE}`)
    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("Claim")
        .setCustomId("claim")
        .setStyle("SUCCESS")
    )
    setTimeout(() => {
      channel.send({ embeds: [embed], components: [row] }).then(m => db.set(`message_${channel.id}`, m.id)) }, 1000);
  }
    
});

client.on("interactionCreate", interaction => {
  if (interaction.isButton()) {
    let message = db.get(`message_${interaction.channel.id}`)
    let msg = interaction.channel.messages.cache.find(r => r.id == message)
    let role = interaction.guild.roles.cache.find(r => r.id == 996364077817405531)
      if (interaction.customId == "claim") {
        if(db.has(`inactive_${interaction.member.id}`)) return interaction.reply({content:`**عليك تسجيل نفسك بالاول : <#1168669813346930779>**` , ephemeral:true})
        if (!interaction.member.roles.cache.some(r => r.id == 996364077817405531)) return interaction.reply({ content: "**يمكن للإدارة فقط إستخدام هذا الزر .**", ephemeral: true })
        let embed = new Discord.MessageEmbed()
          .setDescription(`**مسؤول التذكرة : ${interaction.member} .**`)
          .setColor(`${colorE}`)
        let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("Unclaim")
        .setCustomId("unclaim")
        .setStyle("DANGER") )
        interaction.channel.permissionOverwrites.edit(role, {
          SEND_MESSAGES: false, })
        interaction.channel.permissionOverwrites.edit(interaction.member, {
          SEND_MESSAGES: true, })
        interaction.channel.setName(`ticket-${interaction.member.user.username}`)
      db.set(`claimed_${interaction.channel.id}_${interaction.member.id}`, interaction.member.id)
        db.set(`user_${interaction.channel.id}`, interaction.member.id)
        db.add(`weekuser_${interaction.member.id}`, 1)
        db.add(`alluser_${interaction.member.id}`, 1)
        interaction.reply({ embeds: [new Discord.MessageEmbed().setDescription(`**تم إستلام التذكرة من قبل : ${interaction.member} .**`).setColor(`${colorE}`)] })
        msg.edit({ embeds: [embed], components: [row] })      }
      if (interaction.customId == "unclaim") {
        if (!interaction.member.roles.cache.some(r => r.id == db.get(`role_${interaction.guild.id}`))) return interaction.reply({ content: "**يمكن للإدارة فقط إستخدام هذا الزر .**", ephemeral: true })
        if (!db.has(`claimed_${interaction.channel.id}_${interaction.member.id}`)) return interaction.reply({ content: "**يمكن لصاحب التذكرة فقط إستخدام هذا الزر .**", ephemeral: true })
        interaction.reply({ content: `${role}`, embeds: [new Discord.MessageEmbed().setDescription(`**تم ترك التذكرة من قبل : ${interaction.member} .**`).setColor(`${colorE}`)] })
        let embed = new Discord.MessageEmbed()
          .setDescription("**إضغط على الزر لتصبح مسؤول التذكرة**")
          .setColor(`${colorE}`)
        let row = new Discord.MessageActionRow().addComponents(
          new Discord.MessageButton()
            .setLabel("Claim")
            .setCustomId("claim")
            .setStyle("SECONDARY") )
        interaction.channel.permissionOverwrites.edit(role, {
          SEND_MESSAGES: true, })
interaction.channel.permissionOverwrites.edit(interaction.member, {
          SEND_MESSAGES: false, })

        db.subtract(`weekuser_${interaction.member.id}`, 1)
        db.subtract(`alluser_${interaction.member.id}`, 1)
        db.delete(`claimed_${interaction.channel.id}_${interaction.member.id}`)
        db.delete(`user_${interaction.channel.id}`)
        msg.edit({ embeds: [embed], components: [row] })
      }
  }
});

client.on("channelDelete" , channel => {
if(db.has(`user_${channel.id}`)) {
const s = db.get(`user_${channel.id}`)    
  if(db.has(`claimed_${channel.id}_${s}`)) {
    db.delete(`claimed_${channel.id}_${s}`) 
  }
    if(db.has(`message_${channel.id}`)) {
    db.delete(`message_${channel.id}`)
    db.delete(`user_${channel.id}`)
    }
}
})

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "نقااط") || message.content.startsWith(prefix + "نقاط") || message.content.startsWith(prefix + "نقط")) {
    let user = message.mentions.members.first()
    if (user) {
      let member = message.guild.members.cache.find(u => u == user.id)
      var points = db.get(`weekuser_${user.id}`)
      var weekwarns = db.get(`weekwarns_${user.id}`)
      var allpoints = db.get(`alluser_${user.id}`)
      var allwarns = db.get(`allwarns_${user.id}`)
      var allmute = db.get(`muteall_${user.id}`)
      var weekmute = db.get(`muteweek_${user.id}`)
      if(!points) {
         points = 0 }
      if(!weekwarns) {
         weekwarns = 0 }
      if(!allpoints) {
         allpoints = 0 } 
      if(!allwarns) {
         allwarns = 0 }
      if(!allmute) {
        allmute = 0 }
      if(!weekmute) {
        weekmute = 0 }
      let embed2 = new Discord.MessageEmbed()
        .setDescription(`${emj.Right} **${member.user} , Points :**\n${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li}\n> ${emj.Dot} **Week Points : \`${points + weekwarns + weekmute}\`**\n> ${emj.Dot} **All Points : \`${allpoints + allwarns + allmute}\`**\n${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li}\n> ${emj.Dot} **Week Tickets : \`${points}\`**\n> ${emj.Dot} **Week Warns : \`${weekwarns}\`**\n> ${emj.Dot} **Week Mutes : \`${weekmute}\`**\n${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li}\n> ${emj.Dot} **All Tickets : \`${allpoints}\`**\n> ${emj.Dot} **All Warns : \`${allwarns}\`**\n> ${emj.Dot} **All Mutes : \`${allmute}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed2] }) }
    if (!user) {
      var points = db.get(`weekuser_${message.member.id}`)
      var weekwarns = db.get(`weekwarns_${message.member.id}`)
      var allpoints = db.get(`alluser_${message.member.id}`)
      var allwarns = db.get(`allwarns_${message.member.id}`)
      var allmute = db.get(`muteall_${message.member.id}`)
      var weekmute = db.get(`muteweek_${message.member.id}`)
      if(!points) {
         points = 0 }
      if(!weekwarns) {
         weekwarns = 0 }
      if(!allpoints) {
         allpoints = 0 } 
      if(!allwarns) {
         allwarns = 0 }
      if(!allmute) {
        allmute = 0 }
      if(!weekmute) {
        weekmute = 0 }
      let embed4 = new Discord.MessageEmbed()
        .setDescription(`${emj.Right} **${message.member.user} , Points :**\n${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li}\n> ${emj.Dot} **Week Points : \`${points + weekwarns + weekmute}\`**\n> ${emj.Dot} **All Points : \`${allpoints + allwarns + allmute}\`**\n${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li}\n> ${emj.Dot} **Week Tickets : \`${points}\`**\n> ${emj.Dot} **Week Warns : \`${weekwarns}\`**\n> ${emj.Dot} **Week Mutes : \`${weekmute}\`**\n${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li} ${emj.Li}\n> ${emj.Dot} **All Tickets : \`${allpoints}\`**\n> ${emj.Dot} **All Warns : \`${allwarns}\`**\n> ${emj.Dot} **All Mutes : \`${allmute}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed4] }) 
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "tickets") || message.content.startsWith(prefix + "تكتات") || message.content.startsWith(prefix + "تكت")) {
    let user = message.mentions.members.first()
    if (user) {
      let member = message.guild.members.cache.find(u => u == user.id)
      let points = db.get(`weekuser_${user.id}`)
      let allpoints = db.get(`alluser_${user.id}`)
      let embed1 = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`0\`**\n> **All Tickets : \`${allpoints}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested by : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      let embedd = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`${points}\`**\n> **All Tickets : \`0\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested by : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
          let embed44 = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`0\`**\n> **All Tickets : \`0\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested by : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      if (!db.has(`weekuser_${user.id}`)) return message.reply({ embeds: [embed1] })
      if (!db.has(`alluser_${user.id}`)) return message.reply({ embeds: [embedd] })
      let embed2 = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`${points}\`**\n> **All Tickets : \`${allpoints}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed2] })
    }
    if (!user) {
      let points = db.get(`weekuser_${message.member.id}`)
      let allpoints = db.get(`alluser_${message.member.id}`)
      let embed3 = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`0\`**\n> **All Tickets : \`${allpoints}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
        let embedd = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`${points}\`**\n> **All Tickets : \`0\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      if (!db.has(`weekuser_${message.member.id}`)) return message.reply({ embeds: [embed3] })
     if (!db.has(`alluser_${message.member.id}`)) return message.reply({ embeds: [embedd] })
      let embed4 = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`${points}\`**\n> **All Tickets : \`${allpoints}\`**`)

        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed4] }) 
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "mutes") || message.content.startsWith(prefix + "ميوتات")) {
    let user = message.mentions.members.first()
    if (user) {
      let member = message.guild.members.cache.find(u => u == user.id)
      var mutes = db.get(`muteweek_${user.id}`)
      var allmutes = db.get(`muteall_${user.id}`)
      if(!mutes) {
        mutes = 0
      }
      if(!allmutes) {
        allmutes = 0 }
      let embed2 = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Mutes :`)
        .setDescription(`> **All Mutes : \`${allmutes}\`**\n> **Week Mutes : \`${mutes}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed2] }) }
    if (!user) {
      var mutes = db.get(`muteweek_${message.member.id}`)
      var allmutes = db.get(`muteall_${message.member.id}`)
      if(!mutes) {
        mutes = 0 }
      if(!allmutes) {
        allmutes = 0 }
      let embed4 = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Mutes :`)
        .setDescription(`> **Week Mutes : \`${mutes}\`**\n> **All Mutes : \`${allmutes}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed4] }) 
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "ticket(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`weekuser_${user.id}`, args2)
      await db.add(`alluser_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} ticket points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] })
      let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم اضافة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "allticket(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`alluser_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} ticket points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم اضافة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "mute(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`muteweek_${user.id}`, args2)
      await db.add(`muteall_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} mute points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم اضافة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "allmute(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`muteall_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} mute points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم اضافة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "allwarn(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`allwarns_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} warn points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم اضافة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "ticket(-)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      if (!db.has(`weekuser_${user.id}`)) return message.reply("**This user does not have any points**")
      if (!db.has(`alluser_${user.id}`)) return message.reply("**This user does not have any points**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be removed**")
      await db.subtract(`weekuser_${user.id}`, args2)
await db.subtract(`alluser_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done removed ${args2} ticket points from ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم ازالة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المزالة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }

  }

});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "warn(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`weekwarns_${user.id}`, args2)
      await db.add(`allwarns_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} warn points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم اضافة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "warn(-)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      if (!db.has(`weekwarns_${user.id}`)) return message.reply("**This user does not have any points**")
      if (!db.has(`allwarns_${user.id}`)) return message.reply("**This user does not have any points**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be removed**")
      await db.subtract(`weekwarns_${user.id}`, args2)
      await db.subtract(`allwarns_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done removed ${args2} warn points from ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
                  let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم ازالة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المزالة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "mute(-)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      if (!db.has(`muteweek_${user.id}`)) return message.reply("**This user does not have any points**")
      if (!db.has(`muteall_${user.id}`)) return message.reply("**This user does not have any points**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be removed**")
      await db.subtract(`muteweek_${user.id}`, args2)
      await db.subtract(`muteall_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done removed ${args2} mute points from ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
                  let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم ازالة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المزالة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", message => {
  if (message.content == prefix + "claim") {


      let embed = new Discord.MessageEmbed()
        .setDescription("**إضغط على الزر لتصبح مسؤول التذكرة**")
        .setColor(`${colorE}`)
      let row = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
          .setLabel("Claim")
          .setCustomId("claim")
          .setStyle("SUCCESS")
      )
      message.delete()
      message.channel.send({ embeds: [embed], components: [row] }).then(m => db.set(`message_${message.channel.id}`, m.id)) 

  }
});

///////////////
client.on("messageCreate" , message => {
if(message.content.startsWith("$تحويل")) {
message.delete()
message.channel.send(`**${emj.Dot} التحويل فقط لـ <@${bankid}> .**`);
}
});



client.on('messageCreate', async (message) => {
  if (message.content.startsWith('$setr')) {
    let args = message.content.split(" ")
    const roles = message.mentions.roles.first() || message.guild.roles.cache.find((x) => x.id == args[1]) || message.guild.roles.cache.find((x) => x.name == message.content.split(' ').slice(1).join(' '));
    if (!message.member.permissions.has("MANAGE_ROLES"))  {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
    if(!args) return message.reply("**حدد رتبة !**")
        if(!roles) return message.reply("**حدد رتبة !**")


    const members = roles.members.map((e) => `${emj.Dot} |  <@${e.user.id}>`);
    const membersCount = roles.members.size;
    const MAX_LENGTH = 2000;
    const chunks = [];
    let currentChunk = '';
    for (const member of members) {
      if (currentChunk.length + member.length + 1 <= MAX_LENGTH) {
        currentChunk += `${member}\n`; } else {
        chunks.push(currentChunk);
        currentChunk = `${member}\n`; }}
    if (currentChunk) {
      chunks.push(currentChunk); }
    for (let i = 0; i < chunks.length; i++) {
      const content = i === chunks.length - 1 ? `**${chunks[i]}\nعددهم : \`${membersCount}\`**` : `**${chunks[i]}**`;
      await message.reply({ content }); }
  }
});

////////////////
client.on("messageCreate" , message => {
if(message.content.startsWith("خط")) {
if(message.content.startsWith("خطط")) return false;
message.channel.send(`${lineLink}`)
        message.delete(); 
}
});

////////////////

client.on("messageCreate" , message => {
  if(message.channel.id == 1164798267004039168) {
  if(message.author.bot) return;
  if(message.content.startsWith(prefix + "طلب")) return false;
  setTimeout(()=> {
    message.delete()
  },3000)
  }
});

    client.on("messageCreate" , message => {
      if(message.content.startsWith(prefix + "طلب")) {
        if(message.channel.id == 1164798267004039168) {
        let args = message.content.split(" ").slice(1).join(" ")
        if(!args) {
          message.reply(`**طريقة الطلب \`:\` ${prefix}طلب + طلبك**`).then(m => {
            setTimeout(() => {
              m.delete()
              message.delete()
            },3000)
          })
        }
        if(args) {
        let row = new Discord.MessageActionRow().addComponents(
          new Discord.MessageButton()
          .setLabel("منتجات 🎮")
          .setCustomId("mon")
          .setStyle("SECONDARY"),
          new Discord.MessageButton()
          .setLabel("تصاميم 🎨")
          .setCustomId("des")
          .setStyle("SECONDARY"),
          new Discord.MessageButton()
          .setLabel("برمجيات 💻")
          .setCustomId("dev")
          .setStyle("SECONDARY"),
          new Discord.MessageButton()
          .setLabel("الغاء ❌")
          .setCustomId("can")
          .setStyle("DANGER"), )
        let embed = new Discord.MessageEmbed()
        .setTitle("**__إختر المكان الصحيح لطلبك :__                                                                  **")
        .setDescription(`**منتجات : 🎮                                                                                        
- مثل : نيترو , حسابات , الخ ..
تصاميم : 🎨
- مثل صورة , بنر , الخ ..
برمجيات : 💻
- مثل : بوت , كود , الخ ..
إلغاء الطلب : ❌
- لإلغاء طلبك، عدم إرساله للبائعين .**`)
        .setColor(`${colorE}`)
db.set(`talab_${message.member.id}` , args)        
          message.channel.send({content:`${message.member}` , embeds:[embed] , components:[row]})
        message.delete() 
        }
        }
      }
    })

    client.on("interactionCreate" , interaction => {
      if(interaction.isButton()) {
        if(interaction.customId == "mon") {
          let talab = db.get(`talab_${interaction.member.id}`)
          let number = db.fetch(`OrderMsg_${interaction.guild.id}`)
            if(!number || number === null) number = 1;
db.add(`OrderMsg_${interaction.guild.id}`,1)
          const row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
            .setLabel("Delete")
            .setCustomId("del")
            .setStyle("DANGER") )
          let mon = new Discord.MessageEmbed()
          .setTitle("> **الطلب الجديد :                                                                  **")
          .setAuthor({name : `${interaction.member.user.username}` , iconURL : interaction.member.displayAvatarURL()})
          .setDescription(`**${talab}**`)
          .setColor(`${colorE}`)
          .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
          .setFooter({text : `${interaction.guild.name}` , iconURL : interaction.guild.iconURL()})
          interaction.guild.channels.cache.get("1121188125885071521").send({content: `<@&1121188022227058778>\n**صاحب الطلب : ${interaction.member}\nرقم الطلب : ${number}**`, embeds:[mon] , components:[row]})
    interaction.guild.channels.cache.get("1121188125885071521").send({content: `${lineLink}`})
          interaction.reply("> **تم إرسال طلبك إلى البائعين، الرجاء الإنتظار ليتواصل معك أحدهم .**")
            interaction.message.delete()
  .then((reply) => {
    setTimeout(() => {
      interaction.deleteReply().catch(err=>{}) }, 5000); })
        db.delete(`talab_${interaction.member.id}`)
        }
        if(interaction.customId == "des") {
                    let talab = db.get(`talab_${interaction.member.id}`)

let number = db.fetch(`OrderMsg_${interaction.guild.id}`)
            if(!number || number === null) number = 1;
db.add(`OrderMsg_${interaction.guild.id}`,1)
            const row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
            .setLabel("Delete")
            .setCustomId("del")
            .setStyle("DANGER") )
          let mon = new Discord.MessageEmbed()
          .setTitle("> **الطلب الجديد :                                                                  **")
          .setAuthor({name : `${interaction.member.user.username}` , iconURL : interaction.member.displayAvatarURL()})
          .setDescription(`**${talab}**`)
          .setColor(`${colorE}`)
          .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
          .setFooter({text : `${interaction.guild.name}` , iconURL : interaction.guild.iconURL()})
          interaction.guild.channels.cache.get("1121188127613128724").send({content: `<@&1121188024387121192>\n**صاحب الطلب : ${interaction.member}\nرقم الطلب : ${number}**`, embeds:[mon] , components:[row]})
          interaction.guild.channels.cache.get("1121188127613128724").send({content: `${lineLink}`})
          interaction.reply("> **تم إرسال طلبك إلى المصممين، الرجاء الإنتظار ليتواصل معك أحدهم .**")
            interaction.message.delete()
    .then((reply) => {
    setTimeout(() => {
      interaction.deleteReply().catch(console.error); }, 5000); }) 
    db.delete(`talab_${interaction.member.id}`)
        }
        if(interaction.customId == "dev") {
                    let talab = db.get(`talab_${interaction.member.id}`)

let number = db.fetch(`OrderMsg_${interaction.guild.id}`)
            if(!number || number === null) number = 1;
db.add(`OrderMsg_${interaction.guild.id}`,1)
            const row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
            .setLabel("Delete")
            .setCustomId("del")
            .setStyle("DANGER") )
          let mon = new Discord.MessageEmbed()
          .setTitle("> **الطلب الجديد :                                                                  **")
          .setAuthor({name : `${interaction.member.user.username}` , iconURL : interaction.member.displayAvatarURL()})
          .setDescription(`**${talab}**`)
          .setColor(`${colorE}`)
          .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
          .setFooter({text : `${interaction.guild.name}` , iconURL : interaction.guild.iconURL()})
          interaction.guild.channels.cache.get("1121188124068954182").send({content: `<@&1121188023191732296>\n**صاحب الطلب : ${interaction.member}\nرقم الطلب : ${number}**`, embeds:[mon] , components:[row]})
          interaction.guild.channels.cache.get("1121188124068954182").send({content: `${lineLink}`})
          interaction.reply("> **تم إرسال طلبك إلى المبرمجين، الرجاء الإنتظار ليتواصل معك أحدهم .**")
            interaction.message.delete()
    .then((reply) => {
    setTimeout(() => {
      interaction.deleteReply().catch(console.error); }, 5000); })
          db.delete(`talab_${interaction.member.id}`) }
        if(interaction.customId == "can") {
          interaction.reply("> **تم إلغاء طلبك بنجاح .**")
          interaction.message.delete()
    .then((reply) => {
    setTimeout(() => {
      interaction.deleteReply().catch(console.error); }, 5000); }) }
        if(interaction.customId == "del") {
          if(interaction.member.roles.cache.some(r=>r.id == 1121187991763812435)) {
            interaction.message.delete()
    interaction.reply({ content: `**${emj.True} لقد تم حذف الطلب بنجاح .**`, ephemeral: true })
          }
        }
      }
    });

///////////
client.on("messageCreate" , message => {
      if(message.content.startsWith(prefix + "رتب") || message.content.startsWith(prefix + "معلومات")) {
let embed1 = new MessageEmbed() 
  .setTitle(`**${emj.Right} Na7la \`S\` Information・المعلومات**`)
        .setDescription(`**إختر من الأزرار التالية ما يناسبك.**`)
        .setColor(`${colorE}`)
.setImage(`https://cdn.discordapp.com/attachments/1113504839696126044/1242812458981134376/20240521_222753.jpg?ex=66659c4c&is=66644acc&hm=ed70a4b50e0fce45fccabcb1681a59c53d78abe18224c1db3059a6ec56eaaa48&`)
        let row1 = new Discord.MessageActionRow().addComponents(
          new Discord.MessageButton()
          .setLabel("رتب")
          .setCustomId("roles")
          .setStyle("SUCCESS"),
          new Discord.MessageButton()
          .setLabel("إعلانات")
          .setCustomId("ads")
          .setStyle("SUCCESS"),
          new Discord.MessageButton()
          .setLabel("معلومات")
          .setCustomId("info")
          .setStyle("SUCCESS"),
          new Discord.MessageButton()
          .setLabel("منشورات مميزة")
          .setCustomId("manshorat")
          .setStyle("SUCCESS"),
          new Discord.MessageButton()
          .setLabel("رومات خاصة")
          .setCustomId("rooms")
          .setStyle("SUCCESS"), )
        message.channel.send({ embeds: [embed1], components:[row1] }) 
      }
});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "roles") {
  const message = await interaction.channel.messages.fetch(interaction.message.id); 
  let embed2 = new MessageEmbed() 
        .setDescription(`**# ~ NA7LA S
~ NA7LA S
معلومات الرتب | # ~ NA7LA S
@🜲 || BEE

مميزاتها :emoji_72: :
:74: يمكن النشر في كل رومات البيع ما عدا ( تصاميم / برمجيات)

:74: نشر الصور بكل رومات البيع

:74: امكانية المنشن هير في كل رومات البيع

السـعـر : 250k :emoji:


@🜲 || HONEY

مميزاتها :emoji_72: :

:74: امكانية النشر في كل رومات البيع ما عدى ( ⁠تصاميم / برمجيات)

:74: امكانية المنشن في كل رومات البيع

:74: امكانية نشر الصور

السـعـر : 150k :emoji:

@🜲 || A ROSE

مميزاتها :emoji_72: :

:74: امكانية النشر في كل رومات البيع ماعدا (تصاميم / برمجيات)

:74: امكانية المنشن هير في كل رومات البيع

:74: لا يمكن نشر صور

السـعـر : 80k :emoji:

@🜲 || Flower

مميزاتها :emoji_72: :

:74: امكانية النشر في كل الرومات ماعدا ( ⁠تصاميم / برمجيات)

:74: عدم امكانية نشر صور

:74: عدم امكانية المنشن

السـعـر : 40k :emoji:

@🜲 || Designer S

مميزاتها :emoji_72: :

:74: امكانية النشر في روم (⁠تصاميم)

:74: مع امكانية المنشن هير بروم ( ⁠تصاميم )

:74: مع امكانية نشر صور بروم ( ⁠تصاميم )

السـعـر : 80k :emoji:

@🜲 || Developer S

مميزاتها :emoji_72: :

:74: امكانية النشر بروم (برمجيات)

:74: امكانية المنشن بروم (⁠برمجيات)

:74: امكانية نشر الصور بروم (برمجيات)

السـعـر : 80k :emoji:
:74: التحويل فقط لـ

@.gg/na7la ( 979266698689519618 )

:emoji_78: لا نتحمل مسؤولية التحويل إلى شخص آخر .`)

        .setColor(`${colorE}`)
  message.edit({ embeds: [embed2], components: [] })

  setTimeout(() => {
  interaction.channel.send(`**${emj.Dot} التحويل فقط لـ <@${bankid}> .**`); }, 500); 
}
});

//
client.on("interactionCreate" , async interaction => {
if(interaction.isButton()) {
if(interaction.customId == "ads") {
  let embed3 = new Discord.MessageEmbed() 
.setDescription(`معلومات الاعلانات :
**
<:74:1242783266348466197> # - NA7LA S : معلومات الاعلانات
**

# قسم حزمة الجولد :
**
<:74:1242783266348466197> منشن هير
<:emoji_79:1242799096725766154> السعر : 50k <:42:1242766803000754177> 


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

<:74:1242783266348466197> منشن ايفري ون
<:emoji_79:1242799096725766154> السعر : 100k <:42:1242766803000754177> 

**
<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 


# قسم حزمة السلفر :
**
<:74:1242783266348466197> قيفاوي في روم <#1210537674272931860> مع منشن ايفري ون
<:74:1242783266348466197> مدة القيف اوي 3 ايام
<:74:1242783266348466197> على 50k
<:emoji_79:1242799096725766154> السعر : 150k <:42:1242766803000754177> 

**
<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 


# قسم حزمه بلاتينيوم :
**
<:74:1242783266348466197> روم خاص لسيرفرك وقيف اوي 
<:74:1242783266348466197> مدة القيف اوي 5 ايام
<:74:1242783266348466197> على 100k
<:emoji_79:1242799096725766154> السعر : 200k <:42:1242766803000754177> 

**
<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 


# قسم حزمة بروكاست :
**

<:74:1242783266348466197> بروكاست للاونلاين ( يرسل لين يتبند )
<:emoji_79:1242799096725766154> السعر : 3m <:42:1242766803000754177> 


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 


<:74:1242783266348466197> بروكاست لكل الاونلاين ( ما يتبند )
<:emoji_79:1242799096725766154> السعر : 6m <:42:1242766803000754177> 

**
<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

# قسم حزمة الدايموند 
**
<:74:1242783266348466197> قيف اوي اول كتروجي فيرالسيرفر شرط دخول سيرفرك
<:74:1242783266348466197> مدة القيف اوي 7 ايام
<:74:1242783266348466197> على 500k
<:emoji_79:1242799096725766154> السعر : 1m <:42:1242766803000754177> 
**

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 
**

<:74:1242783266348466197> ملاحظات : لطلب إعلان يرجى التواصل مع الدعم الفني : <#996376383896957059> <:46:1242766808847482900> فقط.

التحويل فقط لـ <@979266698689519618> فقط .
أذا قمت بالتحويل لاحد غير الحساب المذكور أعلاه فلن يتم عمل الأعلان لك ولن نتحمل المسؤولية لخطأك .**`)
.setColor(`${colorE}`)
interaction.message.edit({ embeds: [embed3], components: [] })
  setTimeout(() => {
  interaction.channel.send(`**${emj.Dot} التحويل فقط لـ <@${bankid}> .**`); }, 500); 
}
}
});
//

//
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "info") {
const message = await interaction.channel.messages.fetch(interaction.message.id); 
  let embed3 = new MessageEmbed() 
.setDescription(`** <:74:1242783266348466197> إضافات | # - Na7la S

<:74:1242783266348466197> رتبة تراست او موثوق : <@&1028594799961444472> 

# مميزاتها :
<:74:1242783266348466197> تكون مميز بين البائعين
<:74:1242783266348466197> تتميز بـ الثقة

# شروطها :
<:74:1242783266348466197> تنشر 15 عملية ناجحة في <#1236645925598793830> 
<:74:1242783266348466197> تجيب 5 آراء عنك في <#1235865566238081024> 

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

<:74:1242783266348466197> <@&1135173094269534228> 
<:74:1242783266348466197> <@&1135173285596893244> 
<:74:1242783266348466197> <@&1135173388948738170> 

# مميزاتها :
<:74:1242783266348466197> تعطيك 3 فرص لكي لا تنسحب رتبتك البيع , بمعنى إنك حصلت على 3 تحذيرات فـ سوف نُزيل منك رتبة واحده من اللايف ويبقى معك اثنين فقط , وكل 3 تحذيرات سوف نُزيل لايف واحد .

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

# سـ3ـر الايفات :
<:74:1242783266348466197> ثلاث = 50k

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 
# معلومات إضافية :

<:74:1242783266348466197> لإزالة التحذيرات :

<:74:1242783266348466197> <@&996693208111251477> 
<:74:1242783266348466197> <@&996693069183332352> 

<:74:1242783266348466197> لإزالة وارن واحد = 25k

<:74:1242783266348466197> لنقل رتب البيع من حساب إلى آخر = 30k

<:emoji_78:1242783447689461822> ملاحظات : ماتقدر تطلب لايف واحده ! , يأتي ثلاثه مع بعض ( اللايفات ) , لشراء لايفات او لأستلام رتبة تراست او إزالة تحذير او نقل رتبة والخ.. يرجى التواصل مع <#996376383896957059> فقط .

<:74:1242783266348466197> __التحويل فقط لـ <@979266698689519618> 
إذا قُمت بالتحويل لأحد غير الحساب المذكور أعلاه فلن يتم تسليمك اي شي ولن نتحمل المسؤولية لخطأك .__**`)
.setColor(`${colorE}`)
message.edit({ embeds: [embed3], components: [] })
  setTimeout(() => {
  interaction.channel.send(`**${emj.Dot} التحويل فقط لـ <@${bankid}> .**`); }, 500); 
}
});

//
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "manshorat") {
const message = await interaction.channel.messages.fetch(interaction.message.id); 
  let embed3 = new MessageEmbed() 
.setDescription(`معلومات المنشورات :
**
<:74:1242783266348466197> # - NA7LA S : المنشورات المميزة

<:74:1242783266348466197> منشور هير ( للمتصلين )
<:emoji_79:1242799096725766154> السعر : 30k <:42:1242766803000754177> 

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

<:74:1242783266348466197> منشور ايفري ( للكل )
<:emoji_79:1242799096725766154> السعر : 60k <:42:1242766803000754177> 

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 
**

# ملاحظة <:emoji_78:1242783447689461822> 
**
لم يتم عمل اي منشور مخالف لقوانين الديسكورد و السيرفر  و قوانين البيع

<:74:1242783266348466197> للأستفسار الرجاء التوجه الى <:29:1242766737200644136> <#996376383896957059> <:46:1242766808847482900> 
**

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 
** <:74:1242783266348466197> التحويل فقط لـ

<@979266698689519618> ( 979266698689519618 ) 

<:emoji_78:1242783447689461822> لا نتحمل مسؤولية التحويل إلى شخص آخر .**`)
.setColor(`${colorE}`)
message.edit({ embeds: [embed3], components: []})
  setTimeout(() => {
  interaction.channel.send(`**${emj.Dot} التحويل فقط لـ <@${bankid}>**`); }, 500);
}
});

//
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "rooms") {
  const message = await interaction.channel.messages.fetch(interaction.message.id); 
  let fi = interaction.guild.channels.cache.filter(ch => ch.name.startsWith("〢↯・"))
  var f;
  if(fi.size < 10) {
    f = "مفتوح" }
  if(fi.size >= 10) {
    f = "مغلق" }
  let embed3 = new MessageEmbed() 
.setDescription(`**
<:74:1242783266348466197>  # - NA7LA S : الرومات الخاصة
**

**
<:74:1242783266348466197>  روم خاص لمدة يوم واحد

<:emoji_79:1242799096725766154> السعر = 20k <:42:1242766803000754177> 

<:74:1242783266348466197>  روم خاص لمدة اسبوع

<:emoji_79:1242799096725766154>  السعر : 140k <:42:1242766803000754177> 

<:74:1242783266348466197>   تجديد الروم الخاص لمدة اسبوع

<:emoji_79:1242799096725766154>  السعر :  120k <:42:1242766803000754177> 
**
<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

# قوانين الرومات الخاصة <:28:1242766492362342491> 
**
1 - يمنع عدم نشر في الروم الخاص بك لمدة يومين

2 - ممنوع ما تشفر الكلمات بالروم الخاص

3 - ممنوع تمنشن ايفري أكثر من مره او هير أكثر من المرات المسموحه لك

{ اذا لم تتبع القوانين سوف يتم سحب رومك الخاص ولا يمكنك تجديده الى في الاسبوع القادم }
**

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

# ملاحظة <:emoji_78:1242783447689461822> 
**
في حال تم اعداد الروم الخاص لن يتم استرداد الأموال

للأستفسار و الشراء توجه الى <#996376383896957059> <:46:1242766808847482900> 
**

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

**<:74:1242783266348466197> التحويل فقط لـ

<@979266698689519618> ( 979266698689519618 ) 

<:emoji_78:1242783447689461822>  لا نتحمل مسؤولية التحويل إلى شخص آخر .**

> ${emj.Dot} الرومات المتوفرة : ${fi.size} 
> ${emj.Dot} \`${f}\` **`)
.setColor(`${colorE}`)
message.edit({ embeds: [embed3], components: []})
  setTimeout(() => {
  interaction.channel.send(`**للشراء قم بكتابة الأمر \`$شراء\` .**`); }, 500); 
}
});

client.on("messageCreate" , message => {
  if(message.content == prefix + "rooms") {
    if(message.member.permissions.has("ADMINISTRATOR") || message.member.roles.cache.some(r=>r.id == 1186292596356681839)) {
    let embed = new Discord.MessageEmbed()
    .setAuthor({name:`${message.member.user.username}` , iconURL:`${message.member.user.displayAvatarURL()}`})
    .setDescription(`> **${emj.True} = ارجاع الرومات**\n\n> **${emj.False} = حذف الرومات**`)
    .setTimestamp()
    .setColor(`${colorE}`)
    .setFooter({text:`${message.guild.name}` , iconURL:`${message.guild.iconURL()}`})
    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
      .setEmoji(`${emj.True}`)
      .setStyle("SUCCESS")
      .setCustomId("create"),
      new Discord.MessageButton()
      .setEmoji(`${emj.False}`)
      .setStyle("SUCCESS")
      .setCustomId("delete") )
    message.reply({embeds:[embed] , components:[row]}).then(m=> {
      db.set(`m_${message.guild.id}` , m.id) 
    })
      }
  }
});

client.on("interactionCreate" , async interaction => {
  if(interaction.isButton()) {
    if(interaction.customId == "create") {
      let guild = interaction.guild
      let channel1 = guild.channels.cache.find(r=>r.id == 1235886930479026196)
      let message = db.get(`m_${interaction.guild.id}`)
      let m = interaction.channel.messages.cache.find(r=>r.id == message)
      m.edit({content:`**${emj.True} تم ارجاع الرومات**` , components:[] , embeds:[]})
      db.delete(`m_${interaction.guild.id}`)
const currentDate2 = moment().format('DD-MM-YYYY HH:mm:ss'); 
            channel1.send(`**${emj.Dot} تم إرجاع الرومات .\n${emj.Dot} المشرف المسؤول : ${interaction.member} .
${emj.Dot} بتاريخ : ${currentDate2} .\n @here**`)
await channel1.send(`${lineLink}`)
      let angel = guild.roles.cache.find(r=>r.name == "🜲 || BEE")
      let perfect = guild.roles.cache.find(r=>r.name == "🜲 || HONEY")
      let great = guild.roles.cache.find(r=>r.name == "🜲 || A ROSE")
      let special = guild.roles.cache.find(r=>r.name == "♔・↝ Discord Leader :")
      let normal = guild.roles.cache.find(r=>r.name == "🜲 || Flower")
      let designer = guild.roles.cache.find(r=>r.name
       == "🜲 || Designer S")
      let developer = guild.roles.cache.find(r=>r.name == "🜲 || Developer S")
      let staffs = guild.roles.cache.find(r=>r.name == "♛ || Staff S.")
      let discordstaff = guild.roles.cache.find(r=>r.id == "996364077817405531")
      let arab = guild.roles.cache.find(r=>r.name == "Member")
      let specialrole = guild.roles.cache.find(r=>r.name == "🜲 || NA7LA S")
      let arabs = guild.roles.cache.find(r=>r.id == "996365835465674792")
      let dealers = guild.roles.cache.find(r=>r.id == "1173940676619157536")
      guild.channels.create("৳・المنشورات・المميزة")
      guild.channels.create("৳・vips")
      guild.channels.create("৳・تصاميم")
      guild.channels.create("৳・برمجيات")
      guild.channels.create("৳・ديسكورد")
      guild.channels.create("৳・حسابات")
      //guild.channels.create("৳・عملات")
      guild.channels.create("৳・العاب")
      //guild.channels.create("❖・طرق")
      guild.channels.create("৳・ٱخرى")
      .then(m=> {

guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
     
guild.channels.cache.find(r=>r.name == "৳・vips").permissionOverwrites.edit(guild.roles.everyone , {
  SEND_MESSAGES:false,
  VIEW_CHANNEL:false
})

guild.channels.cache.find(r=>r.name == "৳・vips").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))

                guild.channels.cache.find(r=>r.name == "৳・vips").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })

                guild.channels.cache.find(r=>r.name == "৳・vips").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・vips").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

/////////////////////////////////////////////////////////////////////

guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })

        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(designer , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })

        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })

guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(developer , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })

                guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
        //////////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(perfect , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(great , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(special , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(normal , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:false })

                guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
        /////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
                                  guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(perfect , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(great , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(special , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(normal , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:false })

                guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
      ///////////////////////////////////////
        //guild.channels.cache.find(r=>r.name == "৳・عملات").permissionOverwrites.edit(guild.roles.everyone , {
          //SEND_MESSAGES:false,
          //VIEW_CHANNEL:false })
        //guild.channels.cache.find(r=>r.name == "৳・عملات").setParent(guild.channels.cache.find(r=>r.id == 1121188043836112968))
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(angel , {
          //SEND_MESSAGES:true,
          //ATTACH_FILES:true,
          //MENTION_EVERYONE:true  })
       //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(specialrole , {
          //SEND_MESSAGES:true,
          //ATTACH_FILES:true,
          //MENTION_EVERYONE:true  })
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(discordstaff , {
         // MANAGE_MESSAGES: true })
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(staffs , {
       //   SEND_MESSAGES:true,
        //  ATTACH_FILES:true,
         // MENTION_EVERYONE:true })
       // guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(arab , {
         // SEND_MESSAGES:false,
         // VIEW_CHANNEL:true  })
       // guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(perfect , {
         // SEND_MESSAGES:true,
          //ATTACH_FILES:true,
         // MENTION_EVERYONE:true })
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(great , {
         // SEND_MESSAGES:true,
         // ATTACH_FILES:false,
          //MENTION_EVERYONE:true })
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(special , {
          //SEND_MESSAGES:true,
         // ATTACH_FILES:false,
          //MENTION_EVERYONE:true })
       //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(normal , {
         // SEND_MESSAGES:true,
          //ATTACH_FILES:false,
          //MENTION_EVERYONE:false  })

               //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(arabs , {
          //SEND_MESSAGES:true,
         // ATTACH_FILES:true,
          //MENTION_EVERYONE:true
        //})

               //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(dealers , {
          //SEND_MESSAGES:true,
          //ATTACH_FILES:true,
         //MENTION_EVERYONE:true
        //})
        ////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・العاب").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true  })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(perfect , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(great , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(special , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(normal , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:false  })

                guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
        /////////////////////////////////////////
        //guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(guild.roles.everyone , {
          //SEND_MESSAGES:false,
          //VIEW_CHANNEL:false  })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").setParent(guild.channels.cache.find(r=>r.id == 1121188043836112968))
        //guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(angel , {
          //SEND_MESSAGES:true,
         // ATTACH_FILES:true,
         // MENTION_EVERYONE:true  })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(specialrole , {
          //SEND_MESSAGES:true,
        //  ATTACH_FILES:true,
        //  MENTION_EVERYONE:true })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(discordstaff , {
       //   MANAGE_MESSAGES: true })
        //guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(staffs , {
     //     SEND_MESSAGES:true,
     ///     ATTACH_FILES:true,
    //      MENTION_EVERYONE:true })
        //guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(arab , {
        //  SEND_MESSAGES:false,
      //    VIEW_CHANNEL:true })

       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(perfect , {
         // SEND_MESSAGES:true,
      //    ATTACH_FILES:true,
       //   MENTION_EVERYONE:true  })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(great , {
       //   SEND_MESSAGES:true,
       //   ATTACH_FILES:false,
         // MENTION_EVERYONE:true  })  
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(special , {
         // SEND_MESSAGES:true,
       //   ATTACH_FILES:false,
       //   MENTION_EVERYONE:true })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(normal , {
      //    SEND_MESSAGES:true,
      //    ATTACH_FILES:false,
      //    MENTION_EVERYONE:false        })

               // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(arabs , {
       //   SEND_MESSAGES:true,
     //     ATTACH_FILES:true,
    //      MENTION_EVERYONE:true
    //    })

               // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(dealers , {
     //     SEND_MESSAGES:true,
     //  ATTACH_FILES:true,
       //   MENTION_EVERYONE:true
     //   })
        ///////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false        })
       guild.channels.cache.find(r=>r.name == "৳・ٱخرى").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true       })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true       })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(perfect , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(great , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(special , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true       })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(normal , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:false        })
        guild.channels.cache.find(r=>r.name == "𐚱・الطلبات").permissionOverwrites.edit(arab , {
          VIEW_CHANNEL:true        })

              guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
       });
      }
    if(interaction.customId == "delete") {
      let guild = interaction.guild
      let channel2 = guild.channels.cache.find(r=>r.id == 1235886930479026196)
      let roomschannel12345 = 'ⵌ・فتح・غلق'
      let arab = guild.roles.cache.find(r=>r.name == "Member")
      const currentDate3 = moment().format('DD-MM-YYYY HH:mm:ss'); 
            channel2.send(`**${emj.Dot} تم حذف الرومات .\n${emj.Dot} المشرف المسؤول : ${interaction.member} .
${emj.Dot} بتاريخ : ${currentDate3} .**`)
await channel2.send(lineLink)
 interaction.guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة").delete()
        
interaction.guild.channels.cache.find(r=>r.name == "৳・vips").delete()
     interaction.guild.channels.cache.find(r=>r.name == "৳・برمجيات").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・ديسكورد").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・حسابات").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・تصاميم").delete()
      //interaction.guild.channels.cache.find(r=>r.name == "❖・عملات").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・العاب").delete()
      //interaction.guild.channels.cache.find(r=>r.name == "❖・طرق").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・ٱخرى").delete()


      interaction.message.edit({content:`**${emj.False} تم حذف الرومات**` , components:[] , embeds:[]})
      guild.channels.cache.find(r=>r.name == "𐚱・الطلبات").permissionOverwrites.edit(arab , {
          VIEW_CHANNEL:false })
      guild.channels.cache.forEach(async channel => {
          if(channel.name.startsWith("〢↯・")) {
      const messages = await channel.messages.fetch({ limit: 100 });

      messages.forEach(async (message) => {
       if (message.pinned) {
         return;
        }  
        await message.delete();
      });

            channel.permissionOverwrites.edit(guild.roles.cache.find(r=>r.name == "🜲 || Private S :") , {
              SEND_MESSAGES:false          
            })
          }      
      })
      db.delete(`m_${interaction.guild.id}`) 
    }
  }
});

          ///////////
const warnWork = `1167331563504156702`
const cooldown1 = 10000;

const cooldown2 = new Map();

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "تحذير")) {
  if(db.has(`inactive_${message.member.id}`)) return message.reply(`**عليك تسجيل نفسك بالاول : <#1168669813346930779>**`)
if (cooldown2.has(message.content)) {
      const timeLeft = cooldown1 - (Date.now() - cooldown2.get(message.content));
      if (timeLeft > 0) {
        return message.reply(`**${emj.Lift} يجب عليك إنتظار ${Math.ceil(timeLeft / 1000)} ثانية لإستخدام هذا الأمر ..
${emj.Dot} يجب التأكد من عدم تكرارك مخالفة شخص تمت مخالفته من قبل زميلك**`);
      }
    }
cooldown2.set(message.content, Date.now());
    if(message.content.startsWith(prefix + "تحذيرات")) return false;
    const wait = require('node:timers/promises').setTimeout;
    if (warnWork.includes(message.channel.id)) {
      const now = new Date()
    let madri = `(=)`
    let channel = message.guild.channels.cache.find(r => r.id == 1115272502516645928);
    let s1 = message.guild.roles.cache.find(r => r.name == "warn 50%");
    let s2 = message.guild.roles.cache.find(r => r.name == "warn 100%");

    let perfect = message.guild.roles.cache.find(r=>r.name == "🜲 || BEE")
    let gold = message.guild.roles.cache.find(r=>r.name == "🜲 || HONEY")
    let great = message.guild.roles.cache.find(r=>r.name == "🜲 || A ROSE")
    let epic = message.guild.roles.cache.find(r=>r.name == "🜲 || Flower")
    let normal = message.guild.roles.cache.find(r=>r.name == "🜲 || N7")
    let designer = message.guild.roles.cache.find(r=>r.name == "🜲 || Designer S")
    let developer = message.guild.roles.cache.find(r=>r.name == "🜲 || Developer S")
    let prv = message.guild.roles.cache.find(r=>r.name == "🜲 || Private S :")
    let special = message.guild.roles.cache.find(r=>r.name == "🜲 || N7 SUPERHERO")
    let rolesToCheck = ["🜲 || BEE" , "🜲 || HONEY" , "🜲 || A ROSE" , "🜲 || Flower" , "🜲 || N7" , "🜲 || Designer S" , "🜲 || Developer S" , "🜲 || Private S :" , "🜲 || N7 SUPERHERO"]
    let args = message.content.split(" ")
    let user = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id ==      args[1])
    let reason = message.content.split(" ").slice(2).join(" ")
    if(!user) return message.reply(`**${emj.False} يرجى وضع منشن الشخص أولاً !**`)
    const roles = user.roles.cache;
    const roleNames = Array.from(roles.values()).map(role => role.name);
    const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));
    if(rolesUserHas.length === 0) return message.reply(`**${emj.False} هذا الشخص لا يمتلك رتب بيع**`)
    if(!reason) return message.reply(`** ${emj.False} يرجى وضع السبب أولاً !**`)
    if(!message.attachments.size) return message.reply(`**${emj.False} يرجى وضع الدليل أولاً !**`)

    if(!user.roles.cache.some(r=>r.name == "warn 50%") && !reason.includes(`(=)`)) {
    message.reply(`**${emj.True} تم إعطاء التحذير لـ ${user} !**`)
    db.add(`weekwarns_${message.member.id}` , 1)
    db.add(`allwarns_${message.member.id}` , 1)
     const attachments = Array.from(message.attachments.values());
      const attachmentFiles = attachments.map((attachment) => attachment.url);
    channel.send({content:`**${emj.Dot} الشخص : ${user}\n\n${emj.Dot} الإداري : ${message.member}\n\n${emj.Dot} نوع التحذير : Warn 50%\n\n${emj.Dot} السبب : ${reason}\n\n${emj.Dot} الدليل :**` , files:attachmentFiles})
      const a = attachmentFiles.join(`\n`)
      channel.send(`${lineLink}`);
      const roles = user.roles.cache;
      const roleNames = Array.from(roles.values()).map(role => role.name);
      const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));

      user.roles.add([s1])

    }
    if(user.roles.cache.some(r=>r.name == "warn 50%") && !reason.includes(`(=)`)) {
      if(!user.roles.cache.some(r=>r.name == "warn 100%") && !reason.includes(`(=)`)) {
      message.reply(`**${emj.True} تم إعطاء التحذير لـ ${user} !**`)
    db.add(`weekwarns_${message.member.id}` , 1)
    db.add(`allwarns_${message.member.id}` , 1)
     const attachments = Array.from(message.attachments.values());
      const attachmentFiles = attachments.map((attachment) => attachment.url);
    channel.send({content:`**${emj.Dot} الشخص : ${user}\n\n${emj.Dot} الإداري : ${message.member}\n\n${emj.Dot} نوع التحذير : Warn 100%\n\n${emj.Dot} السبب : ${reason}\n\n${emj.Dot} الدليل :**` , files:attachmentFiles})
       channel.send(`${lineLink}`);
        const a = attachmentFiles.join(`\n`)
        const roles = user.roles.cache;
      const roleNames = Array.from(roles.values()).map(role => role.name);
      const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));

      user.roles.add([s2])

    }
    }
    if(user.roles.cache.some(r=>r.name == "warn 100%") && !reason.includes(`(=)`)) {
            user.roles.remove([s1,s2,perfect,gold,great,epic,normal,designer,developer,prv])
                message.reply(`**${emj.True} تم إعطاء التحذير لـ ${user} !**`)
    db.add(`weekwarns_${message.member.id}` , 1)
    db.add(`allwarns_${message.member.id}` , 1)
     const attachments = Array.from(message.attachments.values());
      const attachmentFiles = attachments.map((attachment) => attachment.url);
    channel.send({content:`**${emj.Dot} الشخص : ${user}\n\n${emj.Dot} الإداري : ${message.member}\n\n${emj.Dot} نوع التحذير : سحب رتبة\n\n${emj.Dot} السبب : ${reason}\n\n${emj.Dot} الدليل :**` , files:attachmentFiles})
      const a = attachmentFiles.join(`\n`)
      const roles = user.roles.cache;
      const roleNames = Array.from(roles.values()).map(role => role.name);
      const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));

      channel.send(`${lineLink}`);
    }
    if(reason.includes(`(=)`)) {
                message.reply(`**${emj.True} تم إعطاء التحذير لـ ${user} !**`)
    db.add(`weekwarns_${message.member.id}` , 1)
    db.add(`allwarns_${message.member.id}` , 1)
     const attachments = Array.from(message.attachments.values());
      const attachmentFiles = attachments.map((attachment) => attachment.url);
    channel.send({content:`**${emj.Dot} الشخص : ${user}\n\n${emj.Dot} الإداري : ${message.member}\n\n${emj.Dot} نوع التحذير : سحب رتبة\n\n${emj.Dot} السبب : ${reason}\n\n${emj.Dot} الدليل :**` , files:attachmentFiles})
      channel.send(`${lineLink}`);
      const a = attachmentFiles.join(`\n`)
      const roles = user.roles.cache;
      const roleNames = Array.from(roles.values()).map(role => role.name);
      const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));

              user.roles.remove([s1,s2,perfect,gold,great,epic,normal,designer,developer,prv,special])

    }
      }
  }
});



client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "warns") || message.content.startsWith(prefix + "تحذيرات")) {
    let user = message.mentions.members.first()
    if (user) {
      let member = message.guild.members.cache.find(u => u == user.id)
      var warns = db.get(`weekwarns_${user.id}`)
      var allwarns = db.get(`allwarns_${user.id}`)
      if(!warns) {
        warns = 0 }
      if(!allwarns) {
        allwarns = 0 }
      let embed2 = new Discord.MessageEmbed()
       .setTitle(`${member.user.tag}, Warns :`)
        .setDescription(`> **All Warns : \`${allwarns}\`**\n> **Week Warns : \`${warns}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed2] }) }
    if (!user) {
      var warns = db.get(`weekwarns_${message.member.id}`)
      var allwarns = db.get(`allwarns_${message.member.id}`)
      if(!warns) {
        warns = 0 }
      if(!allwarns) {
        allwarns = 0 }
      let embed4 = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Warns :`)
        .setDescription(`> **Week Warns : \`${warns}\`**\n> **All Warns : \`${allwarns}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed4] }) 
    }
  }
});

////////
client.on('messageCreate', async (message) => {
    if (message.content.startsWith('$repoints')) {
  if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
            try {
                const memberList = await message.guild.members.fetch();
                let usersData = [];
                memberList.forEach((member) => {
                    if (member.roles.cache.has('996364077817405531')) {
                        var points = db.get(`weekuser_${member.id}`);
                        var weekwarns = db.get(`weekwarns_${member.id}`);
                        var weekmute = db.get(`muteweek_${member.id}`);
                        points = parseInt(points) || 0;
                        weekwarns = parseInt(weekwarns) || 0;
                        weekmute = parseInt(weekmute) || 0;
                        if (points > 0 || weekwarns > 0 || weekmute > 0) {
                            usersData.push({ user: member.user, points, weekwarns, weekmute , total : points + weekwarns + weekmute}); }}});
                usersData.sort((a, b) => b.total - a.total);
                const embed = new MessageEmbed()
                    .setColor(`${colorE}`)
                    .setTitle('**Top 10 Week :**');
                const topUsers = usersData.slice(0, 10);
                topUsers.forEach((user, index) => {
                    embed.addField(`**#${index + 1} | **`, `**<@${user.user.id}> - ${user.points} Tickets - ${user.weekwarns} Warns - ${user.weekmute} Mutes - All Week : ${user.points + user.weekwarns + user.weekmute} **`); });
                const channel = message.guild.channels.cache.get('1113504839696126044');
                if (channel && channel.isText()) {
                    await channel.send({ embeds: [embed] });
                    await message.reply('**تم إعادة تعيين نقاط الأسبوع بنجاح.**'); }
                usersData.forEach((user) => {
                    if (user.user.id !== client.user.id) {
if(db.has(`feedback_${user.user.id}`)) {
db.delete(`feedback_${user.user.id}`)
}
                        if (user.points === 0 && user.weekwarns === 0 && user.weekmute === 0) {
                            db.delete(`weekuser_${user.user.id}`);
                            db.delete(`weekwarns_${user.user.id}`);
                            db.delete(`muteweek_${user.user.id}`); } else {
                            db.set(`muteweek_${user.user.id}`, 0);
                          db.set(`weekwarns_${user.user.id}`, 0);
                          db.set(`weekuser_${user.user.id}`, 0); } } }); } catch (error) {
                consol.error('حدث خطأ :', error); 
            }
        }
});

//////////////
client.on('messageCreate', async (message) => {
    if (message.content.startsWith('$top') || message.content.startsWith('$توب')) {
        try {
            const memberList = await message.guild.members.fetch();
            let usersData = [];
            memberList.forEach((member) => {
                if (member.roles.cache.has('996364077817405531')) {
                    var points = db.get(`alluser_${member.id}`);
                    var weekwarns = db.get(`allwarns_${member.id}`);
                    var weekmute = db.get(`muteall_${member.id}`);
                    points = parseInt(points) || 0;
                    weekwarns = parseInt(weekwarns) || 0;
                    weekmute = parseInt(weekmute) || 0;
                    if (points > 0 || weekwarns > 0 || weekmute > 0) {
                        usersData.push({ user: member.user, points, weekwarns, weekmute, totalPoints: points + weekwarns + weekmute });}}});
            usersData.sort((a, b) => b.totalPoints - a.totalPoints);
            const embed = new MessageEmbed()
                .setColor(`${colorE}`)
                .setTitle('**Top 10 Points :**');
            const topUsers = usersData.slice(0, 10);
            if (topUsers.length === 0) {
                embed.setDescription('**لا يوجد أعضاء يمتلكون نقاط .**'); } else {
                topUsers.forEach((user, index) => {
                    embed.addField(`**#${index + 1} | **`, `**<@${user.user.id}> - ${user.points} Tickets - ${user.weekwarns} Warns - ${user.weekmute} Mutes - All Top : ${user.points + user.weekwarns + user.weekmute} **`); }); }
let rowtp = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("All")
        .setCustomId("altop")
        .setStyle("SUCCESS")
        .setDisabled(true) )
  .addComponents(
      new Discord.MessageButton()
        .setLabel("Week")
        .setCustomId("wetop")
        .setStyle("SUCCESS")
        .setDisabled(false) )
            await message.channel.send({ embeds: [embed], components: [rowtp] })
        } catch (error) {
            console.error('حدث خطأ :', error); 
        }
    }
});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "wetop") {
const message = await interaction.channel.messages.fetch(interaction.message.id);
try {
            const memberList = await message.guild.members.fetch();
            let usersData = [];
            memberList.forEach((member) => {
                if (member.roles.cache.has('996364077817405531')) {
                    var points = db.get(`weekuser_${member.id}`);
                    var weekwarns = db.get(`weekwarns_${member.id}`);
                    var weekmute = db.get(`muteweek_${member.id}`);

                    points = parseInt(points) || 0;
                    weekwarns = parseInt(weekwarns) || 0;
                    weekmute = parseInt(weekmute) || 0;
                    if (points > 0 || weekwarns > 0 || weekmute > 0) {
                        usersData.push({ user: member.user, points, weekwarns, weekmute, totalPoints: points + weekwarns + weekmute });                   }                }});
            usersData.sort((a, b) => b.totalPoints - a.totalPoints);
            const embed = new MessageEmbed()
                .setColor(`${colorE}`)
                .setTitle('**Top 10 Week :**');
            const topUsers = usersData.slice(0, 10);
            if (topUsers.length === 0) {
                embed.setDescription('**لا يوجد أعضاء يمتلكون نقاط في هذا الإسبوع .**'); } else {
                topUsers.forEach((user, index) => {
                    embed.addField(`**#${index + 1} | **`, `**<@${user.user.id}> - ${user.points} Tickets - ${user.weekwarns} Warns - ${user.weekmute} Mutes - All Week : ${user.points + user.weekwarns + user.weekmute} **`); }); }
let rowtpreply = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("All")
        .setCustomId("altop")
        .setStyle("SUCCESS")
        .setDisabled(false) )
  .addComponents(
      new Discord.MessageButton()
        .setLabel("Week")
        .setCustomId("wetop")
        .setStyle("SUCCESS")
        .setDisabled(true) )
  await message.edit({ embeds: [embed], components: [rowtpreply] }); } catch (error) {
                console.error('حدث خطأ :', error); }       }    
})
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "altop") {
const message = await interaction.channel.messages.fetch(interaction.message.id);
try {
            const memberList = await message.guild.members.fetch();
            let usersData = [];
            memberList.forEach((member) => {
                if (member.roles.cache.has('996364077817405531')) {
                    var points = db.get(`alluser_${member.id}`);
                    var weekwarns = db.get(`allwarns_${member.id}`);
                    var weekmute = db.get(`muteall_${member.id}`);
                    points = parseInt(points) || 0;
                    weekwarns = parseInt(weekwarns) || 0;
                    weekmute = parseInt(weekmute) || 0;
                    if (points > 0 || weekwarns > 0 || weekmute > 0) {
                        usersData.push({ user: member.user, points, weekwarns, weekmute, totalPoints: points });                    }                }            });
            usersData.sort((a, b) => b.totalPoints - a.totalPoints);
            const embed = new MessageEmbed()
                .setColor(`${colorE}`)
                .setTitle('**Top 10 Points :**');
            const topUsers = usersData.slice(0, 10);
            if (topUsers.length === 0) {
                embed.setDescription('**لا يوجد أعضاء يمتلكون نقاط .**');
            } else {
                topUsers.forEach((user, index) => {
                    embed.addField(`**#${index + 1} | **`, `**<@${user.user.id}> - ${user.points} Tickets - ${user.weekwarns} Warns - ${user.weekmute} Mutes - All Points : ${user.points + user.weekwarns + user.weekmute} **`);                });            }
let rowtpreply = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("All")
        .setCustomId("altop")
        .setStyle("SUCCESS")
        .setDisabled(true)    )
  .addComponents(
      new Discord.MessageButton()
        .setLabel("Week")
        .setCustomId("wetop")
        .setStyle("SUCCESS")
        .setDisabled(false)    )              
  await message.edit({ embeds: [embed], components: [rowtpreply] });           
} catch (error) {
                console.error('حدث خطأ :', error);        
}      
}  

})

///////////
let messageCount = 0;
client.on('messageCreate', async (message) => {
    if (message.content.startsWith('$start')) {
      if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
        try {
            const memberList = await message.guild.members.fetch();
            memberList.forEach(async (member) => {
                if (member.roles.cache.has('996364077817405531')) { 
                    var points = db.get(`weekuser_${member.id}`)
                    var weekwarns = db.get(`weekwarns_${member.id}`)
                    var weekmute = db.get(`muteweek_${member.id}`) 
                    points = parseInt(points) || 0;
                    weekwarns = parseInt(weekwarns) || 0;
                    weekmute = parseInt(weekmute) || 0;
                    messageCount++;
                    var roleToAssign = "996364077817405531";
                    var roleToAssignHighStaff = "996364341462970388";
                    if (!member.roles.cache.some(r => r.id == 1001974960090251375)) {
                        if (points + weekwarns + weekmute >= 100) {
                            roleToAssign = "دبل ترقية";
                        } else if (points + weekwarns + weekmute >= 50 && points + weekwarns + weekmute <= 99) {
                            roleToAssign = "ترقية";
                        } else if (points + weekwarns + weekmute >= 15 && points + weekwarns + weekmute <= 49) {
                            roleToAssign = "سكب";
                        } else if (points + weekwarns + weekmute < 15) {
                            roleToAssign = "تخفيض";                        }                    }
                    if (member.roles.cache.some(r => r.id == 996364077817405531)) {
                        if (points + weekwarns + weekmute >= 130) {
                            roleToAssignHighStaff = "دبل ترقية";                        } else if (points + weekwarns + weekmute >= 90 && points + weekwarns + weekmute <= 100) {
                            roleToAssignHighStaff = "ترقية";
                        } else if (points + weekwarns + weekmute >= 20 && points + weekwarns + weekmute < 50) {
                            roleToAssignHighStaff = "سكب";                        }
                      else if (points + weekwarns + weekmute < 20) {
                            roleToAssignHighStaff = "تخفيض";                        }                   }
                    let replyMessage = `> **${emj.Lift} الإداري : <@${member.user.id}>**\n> **${emj.Lift} الإداري رقم : ${messageCount}**\n**${emj.Dot} عدد التكتات : ${points}\n${emj.Dot} عدد التحذيرات : ${weekwarns}\n${emj.Dot} عدد الميوتات : ${weekmute}\n${emj.Dot} مجموع النقاط الكلي : ${points + weekwarns + weekmute}**`;
                    if 
(member.roles.cache.some(r => r.id == 996364077817405531)) {
                        if (roleToAssign !== "996364341462970388") {
                            replyMessage += `\n**${emj.Dot} النتيجة : ${roleToAssign}**`;                       } }
                    if (member.roles.cache.some(r => r.id == 996364077817405531)) {
                        if (roleToAssignHighStaff !== "996364077817405531") {
                          replyMessage += ` ${emj.Lift} النتيجة : ${roleToAssignHighStaff}`;                   
                        }             
                    }

                    await message.channel.send(replyMessage);           
                }            
            });       
        } catch (error) {
            console.error('خطأ :', error);      
        }  
    }
});

////////////

client.on("messageCreate", async message => {
  const args = message.content.split(" ")
  const now = new Date()
  if(message.content.startsWith(prefix + 'sub')) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
    let prv = message.guild.roles.cache.find(r=>r.id == 1124855135395401738)
    let arab = message.guild.roles.cache.find(r=>r.name == "Member")
    let discordstaff = message.guild.roles.cache.find(r=>r.name == "♛ || Discord Staff :")
    let args = message.content.split(" ")
    let member = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
   if(!args[1]) return message.reply(`${emj.False} | **منشن شخص !**`)
   if(!member) return message.reply(`${emj.False} | **منشن شخص !**`)
       if(db.has(`prvuser_${member.id}`)) return message.reply(`${emj.False} | **هذا الشخص يمتلك بالفعل روم خاص**`)
    if(!args[2]) return message.reply(`${emj.False} | **حدد مدة الروم !**`)
    if(!args[2].endsWith("d")) {
    if(!args[2].endsWith("h")) {
    if(!args[2].endsWith("m")) {
      return message.reply(`${emj.False}** | حدد الوقت بالأيام - بالساعات أو بالدقائق**`)
    }}}
    if(isNaN(args[2][0])) return message.reply(`${emj.False} | **حدد وقت صحيح !**`)

  message.reply(`${emj.True} **| تم إنشاء روم خاص لـ ${member} لمدة \`${args[2]}\`**`)
member.roles.remove('1124855135395401738')
  let embed = new Discord.MessageEmbed()
  .setDescription(`**${emj.Right} Na7la \`S\` Private Rooms・الرومات الخاصه**\n\n> **${emj.Dot} صاحب الروم : <@${member.id}> **

> **${emj.Dot} صنع بواسطة : ${message.member} **

> **${emj.Dot} صنع في : <t:${Math.floor(now.getTime() / 1000)}:d> **

> **${emj.Dot} ينتهي في : <t:${Math.floor((now.getTime() + ms(args[2])) / 1000)}:R> **

> **${emj.Dot} مدة الروم : ${args[2]} **
`)
  .setColor(`${colorE}`)
  let mm = await message.guild.channels.create(`〢↯・${member.user.username}` , {type:"text"})
  .then(async m => {
  m.setParent(message.guild.channels.cache.find(r=>r.id == 996388001779298324))
  member.roles.add([prv]).catch(err=>{})
  db.set(`prvuser_${member.id}` , member.id)
  db.set(`prvroom_${m.id}` , member.id)
  db.set(`prv_${member.id}_${m.id}`, m.id)
  m.permissionOverwrites.edit(message.guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false
        })

    m.permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true
        })
    m.permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true,
        })
  m.permissionOverwrites.edit(member.id,{
    SEND_MESSAGES: true,
    MENTION_EVERYONE: true,
    ATTACH_FILES:true
  })

  m.send({content:`<@${member.id}>` , embeds:[embed]}).then(m=> {
    m.pin()
  })
  db.push(`room` , {
  server:message.guild.id,
  id:member.id,
  endsAt:Date.now() + ms(args[2]),
  channelid:m.id
  })
  });
  }
  }
  });

client.on('messageCreate', async (message) => {

if (message.author.bot) return;

if (!message.content.startsWith('$c')) return;

const args = message.content.slice('$c'.length).trim().split(' ');

const amount = args[0];

if (!amount) {

message.reply('يرجى إدخال المبلغ!');

return;

}

const userId = "1022493170598154311";

const embed = new EmbedBuilder()

    .setColor(0x0099FF)

    .setTitle('أمر تحويل')

.setDescription(`c ${userId} ${amount}`)

    .setFooter({ text: 'البوت' });

message.channel.send({ embeds: [embed] });

});


    //////////////////
    client.on("messageCreate" , async message => {
      if(message.content.startsWith(prefix + "ميوت") || message.content.startsWith(prefix + "mute")) {
          if(message.content.startsWith(prefix + "mutes")) return;
      if(message.content.startsWith(prefix + "ميوتات")) return;
          let ch = "1125856665548365865"
          if(ch.includes(message.channel.id)) {
          const guild = message.guild;
          const channel10 = await guild.channels.cache.find(r=>r.name == "♯・شات・الأونرز")
          const now = new Date();
          let args = message.content.split(" ")
          if(!args) return message.reply("**حدد الشخص !**")
          let user = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
          if(!user) return message.reply("**حدد الشخص !**")
          let role = message.guild.roles.cache.find(r=>r.name == "Muted")
          user.roles.add([role]).catch(err=>{})
          db.add(`muteweek_${message.member.id}` , 1)
          db.add(`muteall_${message.member.id}` , 1)

          message.reply(`**تم إسكات ${user} بنجاح !**`)

            let SpecialEmbedLog10 = new Discord.MessageEmbed()
            .setTitle(`**${emj.Right} Add Order Mute !**`)
            .setDescription(`> **${emj.Lift} تم إضافة ميوت لـ ${user} , المشرف المسؤول ${message.author} **
      **${emj.Dot} إيدي الشخص : ${user.id}
      ${emj.Dot} إيدي المشرف المسؤول : ${message.author.id} \n\n${emj.Dot} تاريخ إضافة الميوت : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
            .setColor(`${colorE}`)
            .setTimestamp()

         channel10.send({ embeds: [SpecialEmbedLog10] })
            db.set(`muted_${user.id}` , user.id)
          db.push(`mute` , {
          server: message.guild.id,
          id: user.id,
          endsAt: Date.now() + ms(`5h`),
          })
        }
      }
      });

      client.on("guildMemberAdd" , member => {
        if(db.has(`muted_${member.id}`)) {
          db.push(`mute` , {
            server: member.guild.id,
            id: member.id,
            endsAt: Date.now() + ms(`5h`),
            })
            member.roles.add([member.guild.roles.cache.find(r=>r.name == "Muted")])
        }
      });

      client.on("guildMemberRemove" , async member => {
        if(db.has(`muted_${member.id}`)) {
          if(db.has(`mute`)) {
            const data = await db.get(`mute`)
            for (const x of data) {
            if(x.id == member.id) {
            const index = data.indexOf(x);
            if (index !== -1) {
              data.splice(index, 1);
              await db.set('mute', data);
            }
        }
      }
          }
        }
      });

      async function mute() {
         if(db.has(`mute`)) {
         const data = await db.get(`mute`)
         for (const x of data) {
           let end = x.endsAt
           let g = await x.server
           if(end < new Date()) {
           const guild = await client.guilds.cache.get(g)
           const member = await guild.members.cache.get(x.id)
           const role = await guild.roles.cache.find(r=>r.name == "Muted")
           const channel = await guild.channels.cache.find(r=>r.name == "♯・شات・الأونرز")
           channel.send(`**لقد انتهت مدة الميوت للشخص ${member} .**`)
           member.roles.remove([role]).catch(err=>{})
           //db.delete(`muted_${member.id}`)
           const index = data.indexOf(x);
           if (index !== -1) {
             data.splice(index, 1);
             await db.set('mute', data);
           }

         }
      }
    }
    }
      setInterval(async () => {
        mute()
      },15000)

////////////


client.on('messageCreate', (message) => {
  if (message.content.startsWith('$discount') || message.content.startsWith('$تخفيض') || message.content.startsWith('تخفيض')) {
    const discountPercentage = message.content.split(" ")[1]
    if (isNaN(discountPercentage) || discountPercentage < 0 || discountPercentage > 100) return message.reply('**حدد نسبة بين 0 و 100 !**');
    const originalPrice = message.content.split(" ")[2]
    if (isNaN(originalPrice) || originalPrice <= 0) return message.reply('**حدد رقم للخصم !**');
    const discountAmount = (discountPercentage / 100) * originalPrice;
    const discountedPrice = originalPrice - discountAmount;
    message.reply(`**${emj.Dot} المبلغ الاساسي : ${originalPrice}**\n**${emj.Dot} نسبة الخصم : ${discountPercentage}%**\n${emj.Dot} **قيمة الخصم : ${discountAmount}**\n${emj.Dot} **المبلغ النهائي مع الخصم : ${discountedPrice}**`)
  }
});

/*
 client.on("ready" , () => { 

    const fs = require('fs');

  fs.readFile('database.json', 'utf8', (err, data) => {
    if (err) {
     console.error('Error reading the file:', err);
      return;
   }

   try {
    const dbObject = JSON.parse(data);

     const containsMessage = (key) => key.toLowerCase().startsWith("message");

      for (const key in dbObject) {
        if (containsMessage(key)) {
       delete dbObject[key];
       }
     }

    fs.writeFile('database.json', JSON.stringify(dbObject, null, 2), 'utf8', (err) => {
      if (err) {
         console.error('Error writing to the file:', err);
       } else {
         console.log('Keys containing "message" have been deleted.');
     }
     });
   } catch (error) {
     console.error('Error parsing JSON:', error);
   }
  });
 }) 

*/

let buttonwinner = false

  client.on("messageCreate" , async message => {
    if(message.content == prefix + "زر" || message.content == prefix + "button") {
      const wait = require('node:timers/promises').setTimeout;
      buttonwinner = false
      const embed = new Discord.MessageEmbed()
      .setTitle("**اسرع شخص يضغط الزر : ⚡**")
      .setDescription("**معكم 10 ثواني تضغطون الزر**\n**اسرع واحد يضغط الزر يفوز**")
      .setTimestamp()
      .setColor("333333")
      const row = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
        .setCustomId("r1")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r2")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r3")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r4")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r5")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
      )
      const row2 = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
        .setCustomId("r6")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r7")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r8")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r9")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r10")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
      )
      const row3 = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
        .setCustomId("r11")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r12")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r13")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r14")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r15")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
      )
      const row4 = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
        .setCustomId("r16")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r17")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r18")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r19")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r20")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
      )
      message.channel.send({components:[row,row2,row3,row4] , embeds:[embed]}).then(async m=> {
      await wait(3500)
      const all = [...row.components , ...row2.components , ...row3.components , ...row4.components]
      const r = Math.floor(Math.random() * all.length);
      const button = all[r]
      button.setStyle("SUCCESS")
      button.setDisabled(false)
      const embed2 = new Discord.MessageEmbed()
      .setTitle("**اسرع شخص يضغط الزر : ⚡**")
      .setDescription("**معكم 10 ثواني تضغطون الزر**\n**اضغط على الزر الأخضر 🟢**")
      .setTimestamp()
      .setColor("GREEN")
      m.edit({components:[row,row2,row3,row4] , embeds:[embed2]})
      const time = setTimeout(() => {
        button.setDisabled(true)
        button.setStyle("DANGER")
        const embed3 = new Discord.MessageEmbed()
        .setTitle("**اسرع شخص يضغط الزر : ⚡**")
        .setDescription("**انتهى الوقت**\n**🔴 لا يوجد اي فائز**")
        .setTimestamp()
         .setColor("WHITE")
        m.edit({components:[row,row2,row3,row4] , embeds:[embed3]})
      },10000)
      client.on("interactionCreate" , interaction => {
        if(interaction.isButton()) {
          if(interaction.customId == `${button.customId}` && buttonwinner == false) {
            buttonwinner = true
            button.setDisabled(true)
            const embed4 = new Discord.MessageEmbed()
            .setTitle("**اسرع شخص يضغط الزر : ⚡**")
            .setDescription(`**👑 | ${interaction.member}**`)
            .setTimestamp()
            .setColor("YELLOW")
            m.edit({components:[row,row2,row3,row4] , embeds:[embed4]})
            interaction.channel.send(`**⚡ | الفائز هو : ${interaction.member}**`)
            interaction.deferUpdate()
            clearTimeout(`${time}`)
          }
        }
      });

      })
    }
  });







client.on("messageCreate" , message => {
  if(!message.author.bot) {
  let channels = [
    "৳・vips","৳・برمجيات","৳・تصاميم","৳・ديسكورد","৳・حسابات","৳・العاب","৳・ٱخرى"
  ]
  if(!channels) return;
  if(channels.includes(message.channel.name)) {
    message.channel.send(`${lineLink}`)
  }
  }
});





client.on("messageCreate", async message => {
  const args = message.content.split(" ")
  const now = new Date()
  if(message.content.startsWith(prefix + 'renew')){
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
    let prv = message.guild.roles.cache.find(r=>r.id == 1124855135395401738)
   let member = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
   let channel = message.mentions.channels.first() || message.guild.channels.cache.find(r=>r.id == args[2])
   if(!args[1]) return message.reply(`${emj.False} | **منشن شخص !**`)
   if(!member) return message.reply(`${emj.False} | **منشن شخص !**`)
    if(!channel) return message.reply(`${emj.False} | **منشن الروم !**`)
    if(!args[2]) return message.reply(`${emj.False} | **منشن الروم !**`)

    if(!args[3]) return message.reply(`${emj.False} | **حدد مدة الروم !**`)
    if(!args[3].endsWith("d")) {
    if(!args[3].endsWith("h")) {
    if(!args[3].endsWith("m")) {
      return message.reply(`${emj.False}** | حدد الوقت بالأيام - بالساعات أو بالدقائق**`)
    }}}
    if(isNaN(args[3][0])) return message.reply(`${emj.False} | **حدد وقت صحيح !**`)

  if(!db.has(`enduser_${member.id}`)) return message.reply(`${emj.False} | **هذا الشخص لا يمتلك روم منتهي**`)
  if(!db.has(`endroom_${channel.id}`)) return message.reply(`${emj.False} | **هذا الروم ليس منتهي**`)

  message.reply(`${emj.True} **| تم تجديد الروم ${channel} لـ ${member} لمدة \`${args[3]}\`**`)
  db.set(`prvuser_${member.id}` , member.id)
  db.set(`prvroom_${channel.id}` , member.id)
  let embed = new Discord.MessageEmbed()
  .setDescription(`**${emj.Right} Na7la \`S\` Private Rooms・الرومات الخاصه**\n\n> **${emj.Dot} صاحب الروم : <@${member.id}> **

> **${emj.Dot} تم التجديد بواسطة : ${message.member} **

> **${emj.Dot} تم التجديد في : <t:${Math.floor(now.getTime() / 1000)}:d> **

> **${emj.Dot} ينتهي في : <t:${Math.floor((now.getTime() + ms(args[3])) / 1000)}:R> **

> **${emj.Dot} مدة الروم : ${args[3]} **
`)
  .setColor(`${colorE}`)
channel.bulkDelete(100)
  member.roles.add([prv]).catch(err=>{})
  db.delete(`enduser_${member.id}`)
  db.delete(`endroom_${channel.id}`)
  channel.permissionOverwrites.edit(member.id , {
    SEND_MESSAGES:true
  })
  channel.send({content:`<@${member.id}>` , embeds:[embed]}).then(m=> {
    m.pin()
  })
  db.push(`room` , {
    server:message.guild.id,
    id:member.id,
    endsAt:Date.now() + ms(args[3]),
    channelid:channel.id
  })
  }
  }
  });

    client.on("messageCreate" , async message => {
    const args = message.content.split(" ")
    if(message.content.startsWith(prefix + 'close')) {
      let prv = message.guild.roles.cache.find(r=>r.id == 996364341462970388)
      if (message.member.roles.cache.some(r=> r.id == 1124855135395401738)) {
      let member = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
      let channel = message.mentions.channels.first() || message.guild.channels.cache.find(r=>r.id == args[2])
      if(!args[1]) return message.reply(`${emj.False} | **منشن شخص !**`)
      if(!member) return message.reply(`${emj.False} | **منشن شخص !**`)
      if(!channel) return message.reply(`${emj.False} | **منشن الروم !**`)
      if(!args[2]) return message.reply(`${emj.False} | **منشن الروم !**`)
      if(!db.has(`prvuser_${member.id}`)) return message.reply(`${emj.False} | **هذا الشخص ليس ليده روم خاص**`)
    await message.reply(`${emj.True} | **تم حذف الروم ${channel.name} للشخص ${member} .**`)
    await channel.delete()
    await member.roles.remove([prv])
    if(db.has(`enduser_${member.id}`)) {
      await db.delete(`enduser_${member.id}`)
    }
    if(db.has(`endroom_${channel.id}`)) {
      await db.delete(`endroom_${channel.id}`)
    }
    if(db.has(`prvuser_${member.id}`)) {
      await db.delete(`prvuser_${member.id}`)
    }
    if(db.has(`prvroom_${channel.id}`)) {
      await db.delete(`prvroom_${channel.id}`)
    }
    if(db.has(`prv_${member.id}_${channel.id}`)) {
      await db.delete(`prv_${member.id}_${channel.id}`)
    }
    if(db.has(`room`)) {
      const data = await db.get(`room`)
    for (const x of data) {
      if(x.id == member.id) {
      if(x.channelid == channel.id) {
    const index = data.indexOf(x);
    if (index !== -1) {
      data.splice(index, 1);
      await db.set('room', data);
    }
    }  
    }
    }
  }
    }
  }
    });

client.on("channelDelete" , async channel => {
  if(db.has(`prvroom_${channel.id}`)) {
    let member = channel.guild.members.cache.find(r=>r.id == db.get(`prvroom_${channel.id}`))
     if(db.has(`enduser_${member.id}`)) {
      await db.delete(`enduser_${member.id}`)
    }
    if(db.has(`endroom_${channel.id}`)) {
      await db.delete(`endroom_${channel.id}`)
    }
    if(db.has(`prvuser_${member.id}`)) {
      await db.delete(`prvuser_${member.id}`)
    }
    if(db.has(`prvroom_${channel.id}`)) {
      await db.delete(`prvroom_${channel.id}`)
    }
    if(db.has(`room`)) {
      const data = await db.get(`room`)
    for (const x of data) {
      if(x.id == member.id) {
      if(x.channelid == channel.id) {
    const index = data.indexOf(x);
    if (index !== -1) {
      data.splice(index, 1);
      await db.set('room', data);
    }
    }  
    }
    }
  }
  }
});





client.on('channelCreate', (channel) => {
  if (channel.name.startsWith("ticket-")) {
    let filter = m => m.member.roles.cache.some(r=>r.id == "996364077817405531")
    const collector = channel.createMessageCollector({filter , time:60000 , max:1})
    collector.on('collect', async message => {
        if(message.member.bot) return;
          message.reply(`**سياتبع معك التكت الاداري : ${message.member} <:50:1242766050144292864>

${emj.Warn} يرجى عدم الازعاج بالمنشن او السبام **`)
      })
  }
});

client.on("messageCreate" , message => {
  if(message.content == prefix + "bots") {
    if(message.member.permissions.has("ADMINISTRATOR")) {
    message.guild.members.cache.forEach(member => {
      if(member.user.bot) {
        message.channel.send(`<@${member.id}>`)
      }
    })
  }
  }
})

let mn = '1001642483278688347';/// ايدي رول الي تتمنشن في روم المنتجات

let br = '1001641510359547974';/// ايدي رول الي تتمنشن في روم البروجكتات

let ta = '1001641277852483695'; /// ايدي رول الي تتمنشن في روم التصاميم

const targetRoleId = '996364077817405531'; /// ايدي الرول الي تحذف الطلبات
const logChannelId = ''; /// لوق التصاميم
const brmjeatID = ''; /// لوق برمجيات
const logmntgatID = ''; /// لوق منتجات

client.on('messageCreate', async (message) => {
  if (message.content === '!sendEmbed') {
    const embed = new MessageEmbed()
      .setDescription(`** N7 Talabat - طلـبات نحلة

<:74:1242783266348466197> ما هو نوع طلبك؟ 

<:74:1242783266348466197> لطلب منتجات مثل :

<:29:1242766737200644136> حسابات , نيترو , فيزا , العاب , طرق , الخ... , الرجاء الضغط على منتجات


<:74:1242783266348466197> لطلب تصاميم مثل : 

<:29:1242766737200644136> صور سيرفر , افتار , بنر , لوقو قناة , إلخ.... , الرجاء الضغط على تصاميم

<:74:1242783266348466197> لطلب برمجة مثل : 

<:29:1242766737200644136> بروجكتات , مواقع , برمجة , حل ايرورات , صنع اكواد , إلخ..... , الرجاء الضغط على برمجيات

<:emoji_79:1242799096725766154> الرجاء الألتزام ب <#1235870246116528128> قبل أرسال طلبك.
**`)
      .setColor('15FFAF')
      .setImage('https://cdn.discordapp.com/attachments/1113504839696126044/1242782719583191162/20240521_222832.jpg?ex=664f171a&is=664dc59a&hm=b266b3caa5ff6087822d4f61111c764df7d082b33aad9f9dc1346dd753c2a358&');/// رابط الصوره الي تبيها

    const button = new MessageButton()
      .setCustomId('design')
      .setLabel('تصاميم')
      .setStyle('SUCCESS')
      .setEmoji('<:59:1242766285704790136>');

    const button1 = new MessageButton()
      .setCustomId('myButton1')
      .setLabel('برمجيات')
      .setStyle('SUCCESS')
      .setEmoji('<:60:1242766334341677116>');

    const button2 = new MessageButton()
      .setCustomId('myButton2')
      .setLabel('منتجات')
      .setStyle('SUCCESS')
      .setEmoji('<:60:1242766334341677116>');

    const row = new MessageActionRow().addComponents(button , button1 , button2);

    await message.channel.send({ embeds: [embed], components: [row] });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const customId = interaction.customId;

  if (customId === 'design') {
    const addOwnerModal = new Modal()
      .setCustomId('designmodal')
      .setTitle('اضف طلبك');
    const ownerIdInput = new TextInputComponent()
      .setCustomId('designtext')
      .setLabel('الطلب اكتبه هنا')

      .setMaxLength(4000)
      .setStyle(`PARAGRAPH`)
      .setRequired(true)
  
    
    


    const modalRow = new MessageActionRow().addComponents(ownerIdInput);

   addOwnerModal.addComponents(modalRow);


 await interaction.showModal(addOwnerModal);
  } else if (customId === 'deleteButton') {
    if (interaction.member.roles.cache.has(targetRoleId)) {
      await interaction.message.delete();
       const logChannel = interaction.guild.channels.cache.get(logChannelId);
      if (logChannel) {
        const deletedBy = interaction.user.toString();
        const embed = new MessageEmbed()
          .setTitle('تصاميم')
          .setDescription(`الرسالة تم حذفها بواسطة: ${deletedBy}`)
          .setTimestamp();
        await logChannel.send({ embeds: [embed] });
      }
    } else {
      await interaction.reply({ content: 'ليس لديك الإذن الكافي لحذف الرسالة.', ephemeral: true });
    }
  }
});

client.on('interactionCreate', async (i) => {
  if (!i.isModalSubmit()) return;
  if (i.customId === 'designmodal') {
    const myButton = i.fields.getTextInputValue('designtext');
    const user = i.user;
	const design_orders = await db.get("design_orders");
      if(!design_orders) {
         db.set('design_orders', 1);
      } else {
         db.add("design_orders", 1);
}

      
    let er = db.get('er');
	if(!er){
        await db.add('er', 1)
    } else {
       er++;
    await db.set('er', er);
}
      console.log(await db.get("er"))
   

    const mention = user.toString();

    const sl = `<@&${ta}>`;
    const channel = await client.channels.fetch('1235870809432657972'); // روم تصاميم

    const embed = new MessageEmbed()
      .setTitle('تصاميم')
      .setDescription(`**الطلب : ${myButton}\n\nطلب من: ${mention}\n\n الطلب رقم : ${design_orders}**`);

    const deleteButton = new MessageButton()
      .setCustomId('deleteButton')
      .setLabel('حذف الطلب')
      .setStyle('DANGER');

    await channel.send({ content: `${sl}\n`, embeds: [embed], components: [new MessageActionRow().addComponents(deleteButton)] });
      channel.send({content: `https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=665af161&is=66599fe1&hm=61e62a687bfbfa96c7576f2417821c138125815e34a9b65c917bdf02edae229d&`});

    await i.reply({ content: 'تم ارسال الطلب', ephemeral: true });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const customId = interaction.customId;

  if (customId === 'myButton1') {
    const addOwnerModal = new Modal()
      .setCustomId('myButton1')
      .setTitle('اضف طلبك');
    const ownerIdInput = new TextInputComponent()
      .setCustomId('myButton1')
      .setLabel('الطلب اكتبه هنا')
      .setMaxLength(4000)
      .setStyle(`PARAGRAPH`)
      .setRequired(true);

    const modalRow = new MessageActionRow().addComponents(ownerIdInput);

    addOwnerModal.addComponents(modalRow);

    await interaction.showModal(addOwnerModal);
  } else if (customId === 'del') {
    if (interaction.member.roles.cache.has(targetRo
                                           
                                           
const { Client, Intents , MessageEmbed  , MessageActionRow , MessageButton , MessageSelectMenu , TextInputComponent  , Modal , Permissions} = require('discord.js');
const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES] });
const { token, prefix , categoryIda , transcriptRoomId , requiredRole1, requiredRole2 , requiredRole3 , rolePricesWarn , idprobot, idbank} = require('./config.json'); 
const db = require('pro.db');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const probot = require("probot-tax");

const { formatDistanceToNow } = require('date-fns');
const ms = require('ms');
const moment = require('moment-timezone');
const config = require ('./config.json');



const discordTranscripts = require('discord-html-transcripts');

client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});




 


const warnWorkChannelId = "";//روم ال يوصل فيها تحذيرات
const cooldownTime = 1000;

const rolesToCheckIds = [ //ايديات الرتب البيع 
    "", // ✧・〡Private S
  "", // ✧・〡Mythic S
  "", // ✧・〡Special S
  "", // ✧・〡Great S
  "", // ✧・〡Angel S
  "", // ✧・〡Designer S
  "", // ✧・〡Developer S
  "", // ♛・〡Everest S
  "" ,// ♛・〡VIP S
    "" // ✧・〡Sel $
];

const warnRoles = {
  "S.warn 1": "", // اسم الرتبة والايدي حق تحذيرات
  "S.warn 2": "" // اسم الرتبة والايدي حق التحذيرات 
};


client.on("messageCreate", async (message) => {
  if (!message.content.startsWith(prefix + "تحذير")) return;

  if (!message.member.roles.cache.has(config.DiscordStaff)) {
    return message.reply("**احد مزعلك عشان تعطيه تحذير وانت مو من طاقم ؟**");
  }
  if (cooldowns.has(message.author.id)) {
    const timeLeft = cooldowns.get(message.author.id) - Date.now();
    if (timeLeft > 0) {
      return message.reply(`يجب عليك إنتظار ${Math.ceil(timeLeft / 1000)} ثانية لاستخدام هذا الأمر.`);
    }
  }
  cooldowns.set(message.author.id, Date.now() + cooldownTime);

  const args = message.content.split(" ");
  const user = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
  const reason = args.slice(2).join(" ");

  if (!user) return message.reply("يرجى منشن الشخص أولاً!");
  if (!reason && message.attachments.size === 0) return message.reply("يرجى تقديم السبب وإرفاق الدليل.");

  const userRoles = user.roles.cache.map(role => role.id);
  const hasRolesToCheck = rolesToCheckIds.some(roleId => userRoles.includes(roleId));

  const warnChannel = message.guild.channels.cache.get('');//روم التحذيرات
  const anotherchannel = message.guild.channels.cache.get('')//اللوق تحذيرات
  
  const attachmentFiles = message.attachments.map(attachment => attachment.url);

  if (!hasRolesToCheck) {
    return message.reply("هذا الشخص ليس لديه رتب يمكن تحذيره منها.");
  }

  let warnType;
  if (userRoles.includes(warnRoles["S.warn 2"])) {
    warnType = "S.warn 3";
    await removeRoles(user, message, warnChannel, warnType, reason, attachmentFiles);
  } else if (userRoles.includes(warnRoles["S.warn 1"])) {
    warnType = "S.warn 2";
    await addWarnRole(user, warnType, message, warnChannel, reason, attachmentFiles);
  } else {
    warnType = "S.warn 1";
    await addWarnRole(user, warnType, message, warnChannel, reason, attachmentFiles);
  }
       await anotherchannel.send({
      content: `**الشخص: ${user}\n\n* الإداري: ${message.member}\n\n* نوع التحذير: ${warnType}\n\n* السبب: ${reason}\n\n* الدليل:**`,
      files: attachmentFiles
    });
    await anotherchannel.send(config.lineLink);
});

async function addWarnRole(user, warnType, message, warnChannel, reason, attachmentFiles, anotherchannel) {
  const warnRole = warnRoles[warnType === "S.warn 1" ? "S.warn 1" : "S.warn 2"];
  try {
    await user.roles.add(warnRole);
    await message.reply(`تم إعطاء التحذير بنسبة ${warnType} لـ ${user} بنجاح.`);
    await message.channel.send(config.lineLink);
    await warnChannel.send({
      content: `**الشخص: ${user}\n\n* الإداري: ${message.member}\n\n* نوع التحذير: ${warnType}\n\n* السبب: ${reason}\n\n* الدليل:**`,
      files: attachmentFiles
    });
    await warnChannel.send(config.lineLink);
   
  } catch (error) {
    console.error("Error adding warn role:", error);
  }
}

async function removeRoles(user, message, warnChannel, warnType, reason, attachmentFiles) {
  const rolesToRemove = rolesToCheckIds.concat(Object.values(warnRoles));

  try {
    await user.roles.remove(rolesToRemove);
    await message.reply(`تم سحب جميع الرتب من ${user} بنجاح.`);
    await warnChannel.send({
      content: `**الشخص: ${user}\n\n* الإداري: ${message.member}\n\n* نوع التحذير: ${warnType}\n\n* السبب: ${reason}\n* الدليل:**`,
      files: attachmentFiles
    });
    await warnChannel.send(config.lineLink);
  } catch (error) {
    console.error("Error removing roles:", error);
  }
}












client.on('messageCreate', async (message) => {
    if (!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();
    const mentionedUser = message.mentions.users.first();
      let roleIds = [
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
            '',
          
        ];//رتب الي تعطيها بالطريقة r حق الادارة


    if (command === 'r' && mentionedUser) {
        const roles = roleIds.map((id, index) => {
            const role = message.guild.roles.cache.get(id);
            return {
                name: `${index + 1}. ${role ? role.name : 'Unknown Role'}`,
                value: role ? role.id : null,
            };
        }).filter(role => role.value !== null);

        if (!roles.length) return message.reply('No roles found in this server.');

        const embed = new MessageEmbed()
            .setTitle('Available Roles')
            .setDescription(roles.map(role => role.name).join('\n'))
            .setColor('BLUE');

        await message.reply({ embeds: [embed] });

        const filter = response => {
            return response.author.id === message.author.id && !isNaN(response.content) && response.content > 0 && response.content <= roles.length;
        };

        message.channel.awaitMessages({ filter, max: 1, time: 60000, errors: ['time'] })
            .then(async collected => {
                const selectedRole = roles[parseInt(collected.first().content) - 1];
                const member = message.guild.members.cache.get(mentionedUser.id);
                const role = message.guild.roles.cache.get(selectedRole.value);

                if (!member) return message.reply('User not found in this server.');

                await member.roles.add(role);
                await message.reply(`${member.displayName} has been given the role: ${role.name}`);
            })
            .catch(() => {
                message.reply('You did not select any role in time.');
            });
    }
});



client.on('messageCreate', message => {
    if (message.content.startsWith(prefix + 'ticket')) {
        if (message.author.bot) return;
        

        let ticketSetup = new MessageEmbed()
            .setColor('DARK_BLUE')
            .setAuthor(message.guild.name, message.guild.iconURL())
            .setThumbnail(message.guild.iconURL())
            .setTitle('> Na7la ``S`` Support・ الدعم الفني')
            .setDescription('> **~ Na7la S /n الدعم الفني /n يمكنك اختيار الدعم الفني لأكثر من سبب منهم : /n شراء رتبة - روم خاص - اعلان الخ... /n يمكنك الأستفسار عن اسباب التحذير الخ... /n ألأسباب الي تاخذ تحذير عليها : /n تشهير شخص في الدعم الفني /n تشهير سيرفرات من الاعلانات /n السب والشتم والقذف /n أي مخالفه تأتي من أي شخص سواء ان كان عليا - اداري الخ... /n سيتم تحذيره مهما حصل . /n #N7S_OWNERS**')

      

              
        const row = new MessageActionRow()
        .addComponents(
            new MessageButton()
                .setCustomId('ticket_button')
                .setLabel('🎫 فـتـح تـذكره')
                .setStyle('PRIMARY')
        );


        message.channel.send({ embeds: [ticketSetup] , components: [row] })
            .catch(err => console.error('Error sending embed:', err));
    }
});


client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'ticket_button') {
        
        const row1 = new MessageActionRow()
        .addComponents(
            new MessageSelectMenu()
            .setCustomId('select')
            .setPlaceholder('اختر نوع التذكرة')
            .addOptions([
                {
                    label: 'الدعم الفني',
                   
                    value: 'support',
                },
            ]),
        );



        const embed1 = new MessageEmbed()
        .setColor('DARK_BLUE')
        .setTitle('> يُرجى منك اختيار نوع التذكرة حسب المشكلة التي تواجهك')
        .setThumbnail(interaction.guild.iconURL())
       

        interaction.reply({embeds: [embed1] , components : [row1]  , ephemeral : true})




    }
});



function getUserIdFromChannelTopic(topic) {
    if (!topic) return null; 
    const topicParts = topic.split('|'); 
    if (topicParts.length !== 2) return null; 
    return topicParts[1].trim(); // 
}










client.on('interactionCreate', async interaction => {
    if (!interaction.isSelectMenu()) return;
    if (interaction.customId === 'select') {
        const selectedValue = interaction.values[0];
        const categoryId = categoryIda; // 
        const guild = interaction.guild;
        const userId = interaction.user.id;

        let channelOptions = {
            type: 'GUILD_TEXT',
            parent: categoryId,
            permissionOverwrites: [
                {
                    id: guild.roles.everyone.id,
                    deny: ['VIEW_CHANNEL'],
                },
                {
                    id: interaction.user.id,
                    allow: ['VIEW_CHANNEL'],
                },
                {
                    id: requiredRole1, 
                    allow: ['VIEW_CHANNEL'],
                },
                {
                    
                    id: requiredRole2, 
                    allow: ['VIEW_CHANNEL'],
                },
                {
                       
                    id: requiredRole3, 
                    allow: ['VIEW_CHANNEL'],
                }

            ],
        };

        let channelName, embedMessage, components;

        switch (selectedValue) {
            case 'support':
                channelName = `Support-${interaction.user.username}`;
                embedMessage = new MessageEmbed()
                    .setColor('DARK_BLUE')
                    .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                    .setThumbnail(interaction.guild.iconURL())
                    .setDescription(`**اهلا بك في تذكرة الدعم الفني الخاصة بـ سيرفر Na7la 

                        - من خلال الدعم يمكنك حل جميع مشاكلك التي تواجهك بالسيرفر 
                        
                        - لـ شراء ' رتب - اعلانات - منشورات - رومات خاصة ' :
                         " يمكنك الاختيار من القائمة الموضحة بالاسفل " 
                        
                        - سوف نأتي اليك باقرب وقت ممكن , يرجى منك عدم الازعاج بالمنشن**`);

                components = [
                    new MessageActionRow().addComponents(
                        new MessageButton()
                            .setCustomId('close_ticket')
                            .setLabel('قفل التذكرة')
                            .setStyle('DANGER'),
                        new MessageButton()
                            .setCustomId('claim_ticket')
                            .setLabel('استلام التذكرة')
                            .setStyle('SECONDARY'),
                        new MessageButton()
                            .setCustomId('escalate_ticket')
                            .setLabel('مساعد الادارة')
                            .setStyle('SECONDARY'),

                              
                    ),
                    new MessageActionRow().addComponents(
                        new MessageSelectMenu()
                            .setCustomId('select2')
                            .setPlaceholder('اختر ما تريد شرائه...')
                            .addOptions([
                                {
                                    label: 'الرتب',
                                    description: 'لـ شراء الرتب العامة او إزالة التحذيرات او نقل الرتب',
                                    value: 'Roles',
                                },
                                {
                                    label: 'المنشورات المميزة',
                                    description: 'لـ شراء منشور مميز',
                                    value: 'posts',
                                },
                                {
                                    label: 'الأعلانات',
                                    description: 'لـ شراء إعلان لي سيرفرك',
                                    value: 'ads',
                                },
                                {
                                    label: 'الرومات الخاصة',
                                    description: 'لـ شراء روم خاص لنشر منتجاتك',
                                    value: 'rooms',
                                },

                          
                            ])
                    )
                ];
                break;

            }
        await interaction.reply({ content: '**جاري انشاء التذكره...**', ephemeral: true });

        guild.channels.create(channelName, channelOptions)
            .then(channel => {
            
                interaction.editReply({ content: `**تم فتح تذكرتك : ${channel}**`, ephemeral: true });
                if (components && embedMessage) {
                    channel.send({ content: `${interaction.user} || <@&${requiredRole1}> <@&${requiredRole2}>`, embeds: [embedMessage], components: components })
                        .catch(error => {
                            console.error('Error sending message with components:', error);
                        });
                } else {
                    channel.send({ content: `${interaction.user} || <@&${requiredRole2}>` })
                        .catch(error => {
                            console.error('Error sending message without components:', error);
                        });
                }
            })
            .catch(error => {
                console.error('Error creating channel:', error);
                interaction.editReply('An error occurred while creating the channel.');
            });
    }
});



client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'close_ticket') {
        const confirmationMessage = await interaction.channel.send({
            content: `> ${interaction.user} هل أنت متاكد من انك تريد اغلاق التذكرة ؟`,
            components: [
                new MessageActionRow().addComponents(
                    new MessageButton()
                        .setCustomId('confirm_close')
                        .setLabel('تأكيد')
                        .setStyle('DANGER'),
                    new MessageButton()
                        .setCustomId('cancel_close')
                        .setLabel('الغاء')
                        .setStyle('SECONDARY')
                )
            ]
        });

        const filter = i => i.customId === 'confirm_close' || i.customId === 'cancel_close';
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 15000 });
         
        collector.on('collect', async i => {
            if (i.customId === 'confirm_close') {
                const channelToDelete = i.channel;
                 
                 setTimeout(() => {
                     i.reply('**جاري حذف التذكرة...**');
}, 3000)

                // Get the user ID from the channel's topic or other means
                const userId = getUserIdFromChannelTopic(channelToDelete.topic); // Implement this function

           
                // Implement transcript creation and sending to a specific channel
                const attachment = await discordTranscripts.createTranscript(channelToDelete);
                const transcriptChannel = i.guild.channels.cache.get(transcriptRoomId);
                transcriptChannel.send({ content: `**Transcript for ticket deleted by ${i.user.username}** :`, files: [attachment] });

                channelToDelete.delete()
                    .then(() => {
                        console.log(`Ticket channel ${channelToDelete.name} deleted.`);
                    })
                    .catch(error => {
                        console.error('Error deleting channel:', error);
                        i.reply('An error occurred while deleting the ticket.');
                    });
            } else if (i.customId === 'cancel_close') {
                await i.update({ content: 'تم الغاء قفل التذكرة .', components: [] });
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                confirmationMessage.edit({ content: 'انتهى الوقت , أعد مره اخرى .', components: [] });
            }
        });
    }
});









client.on('interactionCreate', async interaction => {

    if (!interaction.isButton()) return;
    if(interaction.customId === 'claim_ticket') {




        const userId = interaction.user.id;
        const user = interaction.guild.members.cache.get(userId); 
         const requiredRole = requiredRole1
         const requiredRole0 = requiredRole2
           const requiredRole00 = requiredRole3
        
         if (!user.roles.cache.has(requiredRole || requiredRole0 || requiredRole00)) {
            await interaction.reply({ content: 'هنهزر يسطا ؟؟', ephemeral: true });
            return;
        }
        let userPoints = db.get(`points_${userId}`) || 0;
        userPoints++;
        db.set(`points_${userId}`, userPoints);

        const embed = new MessageEmbed()
        .setDescription(`**تم استلام تذكرة ${interaction.channel} من قبل الاداري ${interaction.user}**`)
                .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                .setThumbnail(interaction.guild.iconURL())
        .setColor('DARK_BLUE')
 

        await interaction.reply({embeds : [embed]});



    }


})










client.on('interactionCreate', async interaction => {
    if (!interaction.isSelectMenu()) return;

    if (interaction.customId === 'select2') {
        const selectedValue = interaction.values[0];

        let embedMessage, components;

        switch (selectedValue) {
            case 'Roles':
                embedMessage = new MessageEmbed()
                    .setColor('DARK_BLUE')
                    .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                    .setDescription('** يُرجى منك تحديد نوع الرتب المراد شرائها**');

                components = [
                    new MessageActionRow().addComponents(
                        new MessageButton()
                            .setCustomId('Roles')
                            .setLabel('الرتب ')
                            .setStyle('SECONDARY'),
                        new MessageButton()
                            .setCustomId('delete')
                            .setLabel('إزالة التحذيرات')
                            .setStyle('SECONDARY'),
                        new MessageButton()
                            .setCustomId('transfRole')
                            .setLabel('نقل الرتب')
                            .setStyle('SECONDARY')
                    )
                ];

                await interaction.reply({ embeds: [embedMessage], components });
                break;


                case 'posts':  

                embedMessage = new MessageEmbed()
                .setColor('DARK_BLUE')
                .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                .setThumbnail(interaction.guild.iconURL())
                .setDescription(`معلومات المنشورات :

<:74:1242783266348466197> # - NA7LA S : المنشورات المميزة

<:74:1242783266348466197> منشور هير ( للمتصلين )
<:emoji_79:1242799096725766154> السعر : 100k :42:

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> منشور ايفري ( للكل )
<:emoji_79:1242799096725766154> السعر : 200k :42:


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

ملاحظة <:emoji_78:1242783447689461822>

لم يتم عمل اي منشور مخالف لقوانين الديسكورد و السيرفر و قوانين البيع

<:74:1242783266348466197> للأستفسار الرجاء التوجه الى <:29:1242766737200644136> ⁠⌬・الدعم・الفني :46:


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>
<:74:1242783266348466197> التحويل فقط لـ

<@979266698689519618> ( 979266698689519618 )

:emoji_78: لا نتحمل مسؤولية التحويل إلى شخص آخر . <:emoji_78:1242783447689461822>`);
                    
                components = [


                    new MessageActionRow().addComponents(
                        new MessageSelectMenu()
                            .setCustomId('select3')
                            .setPlaceholder('Select Type Ticket ..')
                            .addOptions([
                                {
                                    label: 'منشن هير',
                                    value: 'here',
                                },
                                {
                                    label: 'منشن ايفري ون',
                                    value: 'every',
                                },
                                
                            ])
                    )
        
                    

                ]
              await  interaction.reply({embeds : [embedMessage] , components })
              break;

                case 'ads' :

              embedMessage = new MessageEmbed()
              .setColor('DARK_BLUE')
              .setAuthor(interaction.guild.name, interaction.guild.iconURL())
              .setThumbnail(interaction.guild.iconURL())
              .setDescription(`معلومات الاعلانات :

<:74:1242783266348466197> # - NA7LA S : معلومات الاعلانات


قسم حزمة الجولد :

<:74:1242783266348466197> منشن هير
<:emoji_79:1242799096725766154> السعر : 100k :42:


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> منشن ايفري ون
<:emoji_79:1242799096725766154> السعر : 200k :42:


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


قسم حزمة السلفر :

:74: قيفاوي في روم ⁠૱・هدايا・الإعلانات مع منشن ايفري ون
<:74:1242783266348466197> قيفاوي في روم ⁠૱・هدايا・الإعلانات مع منشن ايفري ون
<:74:1242783266348466197> على 100k
<:emoji_79:1242799096725766154> السعر : 400k :42:


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


قسم حزمه بلاتينيوم :

<:74:1242783266348466197> روم خاص لسيرفرك وقيف اوي
<:74:1242783266348466197> مدة القيف اوي 3 ايام
<:74:1242783266348466197> على 500k
<:emoji_79:1242799096725766154> السعر : 1m :42:


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>
قسم حزمة بروكاست :


<:74:1242783266348466197> بروكاست للاونلاين

<:emoji_79:1242799096725766154> السعر : 10$ :42:



<:74:1242783266348466197> بروكاست للكل

<:emoji_79:1242799096725766154> السعر : 25$ :42:


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

قسم حزمة الدايموند

<:74:1242783266348466197> قيف اوي اول كتروجي في السيرفر شرط دخول سيرفرك
<:74:1242783266348466197> مدة القيف اوي 7 ايام
<:74:1242783266348466197> على 5m
<:74:1242783266348466197> 3 منشن افري
<:emoji_79:1242799096725766154> السعر : 10$ :42:


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


<:74:1242783266348466197> ملاحظات : لطلب إعلان يرجى التواصل مع الدعم الفني: ⁠⌬・الدعم・الفني <:46:1242766808847482900> فقط.

التحويل فقط لـ <@979266698689519618> فقط .
أذا قمت بالتحويل لاحد غير الحساب المذكور أعلاه فلن يتم عمل الأعلان لك ولن نتحمل المسؤولية لخطأك .`)
              components = [


                new MessageActionRow().addComponents(
                    new MessageSelectMenu()
                        .setCustomId('select4')
                        .setPlaceholder('Select Type Ticket ..')
                        .addOptions([
                            {
                                label: 'Mention Here',
                                value: 'MentionHere',
                            },
                            {
                                label: 'Mention Everyone',
                                value: 'MentionEveryone',
                            },
                            {
                                label: 'Mention Everyone + Giveways',
                                value: 'MentionEveryoneGiveways',
                            },
                            {
                                label: 'Mention Here + Giveways',
                                value: 'MentionHereGiveways',
                            },
                            {
                                label: 'Mention Everyone + First room for 3d + Giveways',
                                value: 'MMM1',
                            },
                            {
                                label: 'Mention Everyone + First room for 7d + Giveways',
                                value: 'MMM2',
                            }

                            
                        ])



                )


                
    
                

          ]
              await  interaction.reply({embeds : [embedMessage] , components })
              
              break;



            case 'rooms'  :

            embedMessage = new MessageEmbed()
            .setColor('DARK_BLUE')
            .setAuthor(interaction.guild.name, interaction.guild.iconURL())
            .setThumbnail(interaction.guild.iconURL())
            .setDescription(`~ NA7LA S

<:74:1242783266348466197> روم خاص لمدة يوم واحد

<:emoji_79:1242799096725766154> السعر = 50k :42:

<:74:1242783266348466197> روم خاص لمدة اسبوع

<:emoji_79:1242799096725766154> السعر : 250k :42:

<:74:1242783266348466197> تجديد الروم الخاص لمدة اسبوع

<:emoji_79:1242799096725766154> السعر : 200k :42:

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

قوانين الرومات الخاصة <:28:1242766492362342491>

عدم النشر في الروم لمدة يومين يؤدي لحذف الروم

ممنوع ما تشفر الكلمات بالروم الخاص

ممنوع تمنشن ايفري أكثر من مره او هير أكثر من المرات المسموحه لك

يمنع نشر روابط

{ اذا لم تتبع القوانين سوف يتم سحب رومك الخاص ولا يمكنك تجديده الى في الاسبوع القادم }


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

ملاحظة <:emoji_78:1242783447689461822>

في حال تم اعداد الروم الخاص لن يتم استرداد الأموال

للأستفسار و الشراء توجه الى ⁠⌬・الدعم・الفني <:46:1242766808847482900>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> التحويل فقط لـ

<@979266698689519618> ( 979266698689519618 )

<:emoji_78:1242783447689461822> لا نتحمل مسؤولية التحويل إلى شخص آخر`)


components = [
    new MessageActionRow().addComponents(
        new MessageButton()
        .setCustomId(`buy`)
            .setLabel('شراء الروم')
            .setStyle('SECONDARY')
    )
];
await  interaction.reply({embeds : [embedMessage] , components })

                
        }
    }
});
































client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'delete') {
        const userId = interaction.user.id;
        const member = await interaction.guild.members.fetch(userId);

        let rolesFound = [];
        let totalPrice = 0;

        for (let roleId in rolePricesWarn) {
            if (member.roles.cache.has(roleId)) {
                rolesFound.push(roleId);
                totalPrice += rolePricesWarn[roleId];
            }
        }

        if (rolesFound.length > 0) {
            await informUser(interaction, rolesFound, totalPrice);
        } else {
            await interaction.reply({ content: 'ليس لديك اي تحذير', ephemeral: true });
        }
    }
});

async function informUser(interaction, rolesFound, totalPrice) {


    const tax = Math.floor(totalPrice * (20 / 19) + 1);

    let embedMessage = new MessageEmbed()
        .setThumbnail(interaction.guild.iconURL())
        .setAuthor(interaction.guild.name, interaction.guild.iconURL())
        .setFooter(interaction.guild.name, interaction.guild.iconURL())
        .setTitle(`انت تمتلك${rolesFound.length} تحذير `)
        .setDescription(`اذا كنت تريد حذف التحذيرات  قم بالضغط على الزر في الاسفل:\n#credit ${idbank} ${tax}`)
        .setColor('DARK_BLUE');

    let components = [
        new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId(`confirmDelete:${rolesFound.join(',')}:${totalPrice}`)
                .setLabel('Confirm Delete')
                .setStyle('DANGER')
        )
    ];

    await interaction.reply({ embeds: [embedMessage], components });
}

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId.startsWith('confirmDelete')) {
        const [, roleIds, totalPrice] = interaction.customId.split(':');
        const userId = interaction.user.id;
        const member = await interaction.guild.members.fetch(userId);
        const tax = Math.floor(totalPrice * (20 / 19) + 1);

        let embedMessage = new MessageEmbed()
            .setThumbnail(interaction.guild.iconURL())
            .setAuthor(interaction.guild.name, interaction.guild.iconURL())
            .setFooter(interaction.guild.name, interaction.guild.iconURL())
            .setTitle(`Remove Warnings || 👑`)
            .setDescription(`الرجاء التحويل الي <@${idbank}>\n#credit ${idbank} ${tax}`)
            .setColor('DARK_BLUE');

        await interaction.update({ embeds: [embedMessage], components: [] });

        const filter = (response) => response.content === `**:moneybag: | ${interaction.user.username}, has transferred \`$${totalPrice}\` to <@!${idbank}> **` && response.author.id === idprobot;

        const collector = interaction.channel.createMessageCollector({ filter, time: 30000 });

        collector.on("collect", async (response) => {
            embedMessage.setDescription(`تم تأكديد عملية التحويل`);
            await interaction.editReply({ embeds: [embedMessage], components: [] });
            let embed = new MessageEmbed()
             .setThumbnail(interaction.guild.iconURL())
            .setAuthor(interaction.guild.name, interaction.guild.iconURL())
            .setFooter(interaction.guild.name, interaction.guild.iconURL())
            .setTitle(`تم الشراء`)
            .setDescription(`**
المنتج: ازاله تحذيرات

المشتري: ${member}
**`)
            .setColor('DARK_BLUE');
            member.send({embeds: [embed]})
            for (let roleId of roleIds.split(',')) {
                if (member.roles.cache.has(roleId)) {
                    await member.roles.remove(roleId);
                }
            }
            collector.stop();
        });

        collector.on("end", async (collected) => {
            if (collected.size === 0) {
                embedMessage.setDescription(`لا تقم بالتحويل انتهى الوقت${interaction.user}`);
                await interaction.editReply({ embeds: [embedMessage], components: [] });
            }
        });
    }
});

client.on('interactionCreate', async interaction => {
    
    if (!interaction.isButton()) return;
    if(interaction.customId === 'Roles') {

        const embedMessage = new MessageEmbed()
        .setColor('DARK_BLUE')
        .setAuthor(interaction.guild.name, interaction.guild.iconURL())
        .setDescription('** اختر رتبة من القائمة أدناه:**');

    const components = [
        new MessageActionRow().addComponents(
            new MessageSelectMenu()
                .setCustomId('roleSelect')
                .setPlaceholder('اختر رتبة')
                .addOptions([
                    {
                        label: 'الرتب العامة',
                        Description : 'لشراء الرتب العامة',
                        value : 'role1'
                    
                    },
                    {
                        label: 'الرتب النادرة',
                        Description:  'لشراء الرتب العامة' ,
                        value: 'role3',
                    }
                   
                ])
        )
    ];

    await interaction.update({ embeds: [embedMessage], components });

    }

})




client.on('interactionCreate', async interaction => {

    if (!interaction.isSelectMenu()) return;

    if (interaction.customId === 'roleSelect') {

        const selectedValue = interaction.values[0];

        let embedMessage, components;

        switch (selectedValue) {

            case 'role1':
                embedMessage = new MessageEmbed()
                    .setColor('DARK_BLUE')
                    .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                    .setDescription(`معلومات الرتب | # ~ NA7LA S
<@&996368935211503616>

مميزاتها <:emoji:1054764721267556382> :
<:74:1242783266348466197> يمكن النشر في كل رومات البيع ما عدا ( تصاميم / برمجيات)

<:74:1242783266348466197> نشر الصور بكل رومات البيع

<:74:1242783266348466197> امكانية المنشن هير في كل رومات البيع

السـعـر : 250k <:emoji:1054764721267556382>


<@&996382617198927873>

مميزاتها <:emoji:1054764721267556382> :

<:74:1242783266348466197> امكانية النشر في كل رومات البيع ما عدى ( ⁠تصاميم / برمجيات)

<:74:1242783266348466197> امكانية المنشن في كل رومات البيع

<:74:1242783266348466197> امكانية نشر الصور

السـعـر : 150k <:emoji:1054764721267556382>

<@&996382760564445184>

مميزاتها <:emoji:1054764721267556382> :

<:74:1242783266348466197> امكانية النشر في كل رومات البيع ماعدا (تصاميم / برمجيات)

<:74:1242783266348466197> امكانية المنشن هير في كل رومات البيع

<:74:1242783266348466197> لا يمكن نشر صور

السـعـر : 80k <:emoji:1054764721267556382>

<@&996382954521624666>

مميزاتها <:emoji:1054764721267556382> :

<:74:1242783266348466197> امكانية النشر في كل الرومات ماعدا ( ⁠تصاميم / برمجيات)

<:74:1242783266348466197> عدم امكانية نشر صور

<:74:1242783266348466197> عدم امكانية المنشن

السـعـر : 40k <:emoji:1054764721267556382>

<@&997259592176246835>

مميزاتها <:emoji:1054764721267556382> :

<:74:1242783266348466197> امكانية النشر في روم (⁠تصاميم)

<:74:1242783266348466197> مع امكانية المنشن هير بروم ( ⁠تصاميم )

<:74:1242783266348466197> مع امكانية نشر صور بروم ( ⁠تصاميم )

السـعـر : 80k <:emoji:1054764721267556382>

<@&997260131962204262>

مميزاتها <:emoji_72:1242783131510116401>  :

<:74:1242783266348466197> امكانية النشر بروم (برمجيات)

<:74:1242783266348466197> امكانية المنشن بروم (⁠برمجيات)

<:74:1242783266348466197> امكانية نشر الصور بروم (برمجيات)

السـعـر : 80k :emoji~1:
<:74:1242783266348466197> التحويل فقط لـ

@.gg/na7la ( 979266698689519618 )

<:emoji_78:1242783447689461822> لا نتحمل مسؤولية التحويل إلى شخص آخر .`)
                    .setFooter(interaction.guild.name, interaction.guild.iconURL())

                     components = [
                        new MessageActionRow().addComponents(
                            new MessageSelectMenu()
                                .setCustomId('roleSelect')
                                .setPlaceholder('اختر رتبة')
                                .addOptions([
                                    {
                                        label: 'BEE S',
                                      
                                        value: 'Angel',
                                    },
                                    {
                                        label: 'HONEY S',
                                        
                                        value: 'Sepcial ',
                                    },
                                    {
                                        label: 'A ROSE S',
                                        
                                        value: 'FLOWER S',
                                    },
                                    {
                                        
                                        label: 'Developer S',
                                        
                                        value: 'Developer',
                                    },
                                    {
                                        label: 'Designer S',
                                        
                                        value: 'Designer',
                                    },//اسماء الرتب فوق
                                

                                    
                                ])
                        )
                    ];






                  //  interaction.update({embeds : [embedMessage] , components : [components]})
                    await interaction.update({ embeds: [embedMessage], components });
                    break;
                    

                    case 'role3' : 
                    embedMessage = new MessageEmbed()
                    .setColor('DARK_BLUE')
                    .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                    .setFooter(interaction.guild.name, interaction.guild.iconURL())
                    .setDescription(`~ NA7LA S | الرتب المميزة
<:74:1242783266348466197> # - NA7LA S : الرتب النادرة

<:74:1242783266348466197> اسم الرتبة النادرة : N7
رتبة بلمنشن : <@&996365835465674792>
<:74:1242783266348466197> السعر : 500,000

المميزات :


<:74:1242783266348466197> تقدر تكتب ف كل الرومات
<:74:1242783266348466197> تقدر تكتب ف رومات البرمجة و التصميم
<:74:1242783266348466197> لون اصفر
<:74:1242783266348466197> (منشور مميز (هير
<:74:1242783266348466197> vip تقدر تنشر كل يوم مره افري ون ف الروم

:73::73::73:

<:74:1242783266348466197> اسم الرتبه النادرة : N7 SUPERHERO
<:74:1242783266348466197> رتبة بلمنشن : <@&1173940676619157536>
<:74:1242783266348466197> السعر : 1,000,000

المميزات :

<:74:1242783266348466197> تقدر اكتب ف كل الرومات
<:74:1242783266348466197> تقدر تكتب ف رومات البرمجة و التصميم
<:74:1242783266348466197> تقدر تنزل منشور مميز كل يوم منشورين هير و ايفري
<:74:1242783266348466197> لون بنفسجي مميز
<:74:1242783266348466197> vip تقدر تنشر كل يوم مرتين افري ون ف الروم

:73::73::73:
<:74:1242783266348466197> ملاحظات :
التحويل فقط ل <@979266698689519618> فقط
أذا قمت بالتحويل لاحد غير الحساب المذكور أعلاه فلن يتم استلامك الرتبة النادرة ولن نتحمل المسؤولية لخطأك .`)

                    components = [
                       new MessageActionRow().addComponents(
                           new MessageSelectMenu()
                               .setCustomId('roleSelect1')
                               .setPlaceholder('اختر رتبة')
                               .addOptions([
                                   {
                                       label: '🜲 || N7 SUPERHERO',
                                     
                                       value: 'Towers',
                                   },
                                   {
                                       label: '🜲 || N7',
                                       
                                       value: 'Dragon',
                                   },
                             //اسماء الرتب النادرة                                                                                                                                        
                               ])
                       )
                   ];

                   await interaction.update({ embeds: [embedMessage], components });



                    







                        





















                    

        }

        

    }

})






    
async function post(interaction, roleName,  rolePrice , channelId) {
    const userId = interaction.user.id;
    const member = await interaction.guild.members.fetch(userId);
 
    const tax = Math.floor(rolePrice * (20 / 19) + 1);


    embedMessage = new MessageEmbed()
        .setThumbnail(interaction.guild.iconURL())
        .setAuthor(interaction.guild.name, interaction.guild.iconURL())
        .setFooter(interaction.guild.name, interaction.guild.iconURL())
        .setTitle(`عملية شراء منشور ${roleName} || 👑`)
        .setDescription(`قم بالتحويل ل <@${idbank}>\n#credit ${idbank} ${tax}`)
        .setColor('DARK_BLUE');

    components = [
        new MessageActionRow().addComponents(
            new MessageButton()
            .setCustomId(`copy:${roleName}:${rolePrice}`)
                .setLabel('نسخ التحويل ')
                .setStyle('SECONDARY')
        )
    ];

    await interaction.update({ embeds: [embedMessage], components });

    const filter = (response) => {
        const expectedContent = `**:moneybag: | ${interaction.user.username}, has transferred \`$${rolePrice}\` to <@!${idbank}> **`;
        console.log(expectedContent)
        console.log(`Received message: ${response.content}`);
        return response.content.includes(expectedContent) && response.author.id === idprobot;
    };
    
    
    const collector = interaction.channel.createMessageCollector({
        filter,
        time: 30000,
    });

    collector.on("collect", async (response) => {
           let embed = new MessageEmbed()
             .setThumbnail(interaction.guild.iconURL())
            .setAuthor(interaction.guild.name, interaction.guild.iconURL())
            .setFooter(interaction.guild.name, interaction.guild.iconURL())
            .setTitle(`تم الشراء`)
            .setDescription(`**
المنتج: منشور

المشتري: ${interaction.user}

السعر: ${rolePrice}
**`)
            .setColor('DARK_BLUE');
            interaction.user.send({embeds: [embed]})
        embedMessage.setDescription(`
            عملية شراء منشور 🜲 || ${roleName} :
            > - يمكنك نشر المنشور الان 🜲 || ${roleName} : بسعر ${rolePrice} بنجاح
          
        `);


        let components = [
            new MessageActionRow().addComponents(
                new MessageButton()
                    .setCustomId('modal1')
                    .setLabel('نشر المنشور ')
                    .setStyle('SECONDARY')
            )
        ];
        await interaction.editReply({ embeds: [embedMessage], components });
        
        collector.stop();
    });

    collector.on("end", async (collected) => {
        if (collected.size === 0) {
            embedMessage.setDescription(`لقد انتهى الوقت، لا تقم بالتحويل  ${interaction.user}`);
            await interaction.editReply({ embeds: [embedMessage], components: [] });
        }
    });


    
    client.on('interactionCreate', async interaction => {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'modal1') {

            const modal1 = new Modal()
			.setCustomId('a2')
			.setTitle('انشر منشورك');
	
		
		const here1 = new TextInputComponent()
			.setCustomId('here1')
			.setLabel("قم بكتابة المنشور")
	
			.setStyle('PARAGRAPH');
		
		
		const secondActionRow = new MessageActionRow().addComponents(here1);

		modal1.addComponents(secondActionRow);
		
		await interaction.showModal(modal1);
        }

    })


    client.on('interactionCreate', async interaction => {
        if (!interaction.isModalSubmit()) return;
        if (interaction.customId === 'a2') {


            const here = interaction.fields.getTextInputValue('here1');

        const channel = await client.channels.fetch(channelId);

          
            embedMessage.setDescription(` تم نشر المنشور بنجاح في ${channel} `)
              await interaction.update({ embeds: [embedMessage], components: [] });  
	    
        channel.send({content : ` ${here} \n @${roleName} \n \n تواصل مع ${interaction.user} للشراء `})

        }
    });


}

async function pos(interaction, roleName, rolePrice, categoryId) {
    const userId = interaction.user.id;
    const member = await interaction.guild.members.fetch(userId);

    const tax = Math.floor(rolePrice * (20 / 19) + 1);

    // Check if user already has a room


    // Limit total number of rooms
    const totalRooms = interaction.guild.channels.cache.filter(channel => channel.type === 'GUILD_TEXT' && channel.parentId === categoryId).size;
    if (totalRooms >= 15) {
        await interaction.reply({ content: 'تم الوصول إلى الحد الأقصى لعدد الغرف. لا يمكن إنشاء مزيد من الغرف حاليًا.', ephemeral: true });
        return;
    }

    const embedMessage = new MessageEmbed()
        .setThumbnail(interaction.guild.iconURL())
        .setAuthor(interaction.guild.name, interaction.guild.iconURL())
        .setFooter(interaction.guild.name, interaction.guild.iconURL())
        .setTitle(`عملية شراء روم خاص ${roleName} || 👑`)
        .setDescription(`قم بالتحويل ل <@${idbank}>\n#credit ${idbank} ${tax}`)
        .setColor('DARK_BLUE');

    const components = [
        new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId(`copy:${roleName}:${rolePrice}`)
                .setLabel('نسخ التحويل ')
                .setStyle('SECONDARY')
        )
    ];

    await interaction.update({ embeds: [embedMessage], components });

    const filter = (response) => {
        const expectedContent = `قام بتحويل`;
        console.log(`Received message: ${response.content}`);
        return response.content.includes(expectedContent) && response.author.id === idprobot;
    };
    
    
    const collector = interaction.channel.createMessageCollector({
        filter,
        time: 30000,
    });

    collector.on("collect", async (response) => {
          let embed = new MessageEmbed()
             .setThumbnail(interaction.guild.iconURL())
            .setAuthor(interaction.guild.name, interaction.guild.iconURL())
            .setFooter(interaction.guild.name, interaction.guild.iconURL())
            .setTitle(`تم الشراء`)
            .setDescription(`**
المنتج: روم

المشتري: ${interaction.user}

السعر: ${rolePrice}
**`)
            .setColor('DARK_BLUE');
            interaction.user.send({embeds: [embed]})
        embedMessage.setDescription(`
            عملية شراء روم خاص 🜲 || ${roleName} :
          > تم تسليمك الروم 🜲 || ${roleName} : بسعر ${rolePrice} بنجاح
           

                  ** اضغط على الزر في الاسفل لنشر روم وتسميته**


        `);

        let components = [
            new MessageActionRow().addComponents(
                new MessageButton()
                    .setCustomId('modal2')
                    .setLabel('نشر الروم الخاص ')
                    .setStyle('SECONDARY')
            )
        ];
        await interaction.editReply({ embeds: [embedMessage], components });

        collector.stop();
    });

    collector.on("end", async (collected) => {
        if (collected.size === 0) {
            embedMessage.setDescription(`لقد انتهى الوقت، لا تقم بالتحويل  ${interaction.user}`);
            await interaction.editReply({ embeds: [embedMessage], components: [] });
        }
    });

    client.on('interactionCreate', async interaction => {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'modal2') {
            const modal2 = new Modal()
                .setCustomId('a1')
                .setTitle('انشر منشورك');

            const here2 = new TextInputComponent()
                .setCustomId('here2')
                .setLabel("قم بكتابة المنشور")
                .setStyle('PARAGRAPH');

            const secondActionRow = new MessageActionRow().addComponents(here2);

            modal2.addComponents(secondActionRow);

            await interaction.showModal(modal2);
        }
    });

    client.on('interactionCreate', async interaction => {
        if (interaction.isModalSubmit() && interaction.customId === 'a1') {
            const here = interaction.fields.getTextInputValue('here2');
            const creationDate = new Date();
            const deletionDate = new Date(creationDate.getTime() + 7 * 24 * 60 * 60 * 1000);
            try {
                const categoryChannel = await client.channels.fetch(categoryId);
                if (!categoryChannel || categoryChannel.type !== 'GUILD_CATEGORY') {
                    throw new Error('Category not found or not a category channel');
                }

                const newChannel = await interaction.guild.channels.create(interaction.user.displayName, {
                    type: 'GUILD_TEXT',
                    parent: categoryId,
                    topic: 'This channel will be deleted in one week',
                    reason: 'User created a new channel via modal',
                    permissionOverwrites: [
                        {
                            id: interaction.guild.id,
                            allow: [Permissions.FLAGS.VIEW_CHANNEL],
                            deny: [Permissions.FLAGS.SEND_MESSAGES],
                        },
                        {
                            id: userId,
                            allow: [Permissions.FLAGS.SEND_MESSAGES],
                        },
                    ],
                });

                const embed = new MessageEmbed()
                    .setTitle('روم خاص جديد')
                    .setDescription(`**مالك الروم:** <@${interaction.user.id}>\n**تاريخ إنشاء الروم:** <t:${Math.floor(creationDate / 1000)}:R>\n**تاريخ إنتهاء الروم:** <t:${Math.floor(deletionDate / 1000)}:R>`)
                    .setColor('DARK_BLUE')
                    .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                    .setThumbnail(interaction.guild.iconURL());

                const renameButton = new MessageButton()
                    .setCustomId('rename_channel')
                    .setLabel('Rename Channel')
                    .setStyle('SECONDARY');

                const buttonRow = new MessageActionRow().addComponents(renameButton);

                await newChannel.send({ content: `نشر شي مخالف لقوانين البيع وعليه تحذير = تحذير | عليه سحب = حذف الروم
تحذيرين = حذف الروم `, embeds: [embed], components: [buttonRow] });

                await interaction.reply({ content: `تم نشر المنشور بنجاح في ${newChannel}`, ephemeral: true });

                setTimeout(async () => {
                    await newChannel.delete();
                }, 7 * 24 * 60 * 60 * 1000);

            } catch (error) {
                console.error('Error creating or sending message to the new channel:', error);
                await interaction.reply({ content: 'حدث خطأ أثناء محاولة إنشاء ونشر المنشور في القناة الجديدة. يرجى المحاولة مرة أخرى.', ephemeral: true });
            }
        }
    });

    client.on('interactionCreate', async interaction => {
        if (interaction.isButton() && interaction.customId === 'rename_channel') {
            const channel = interaction.channel;

            if (channel.permissionsFor(interaction.user).has(Permissions.FLAGS.MANAGE_CHANNELS) || channel.permissionsFor(interaction.user).has(Permissions.FLAGS.SEND_MESSAGES)) {
                const modal = new Modal()
                    .setCustomId('renameChannelModal')
                    .setTitle('Rename Channel');

                const newNameInput = new TextInputComponent()
                    .setCustomId('newChannelName')
                    .setLabel('New Channel Name')
                    .setStyle('SHORT');

                const actionRow = new MessageActionRow().addComponents(newNameInput);

                modal.addComponents(actionRow);

                await interaction.showModal(modal);
            } else {
                await interaction.reply({ content: 'ليس لديك صلاحية لتغير اسم هذا الروم الخاص', ephemeral: true });
            }
        }

        if (interaction.isModalSubmit() && interaction.customId === 'renameChannelModal') {
            const newChannelName = interaction.fields.getTextInputValue('newChannelName');
            const channel = interaction.channel;

            if (channel.permissionsFor(interaction.user).has(Permissions.FLAGS.MANAGE_CHANNELS) || channel.permissionsFor(interaction.user).has(Permissions.FLAGS.SEND_MESSAGES)) {
                await channel.setName(newChannelName);
                await interaction.reply({ content: `تم تغير اسم الروم الجديد الي : ${newChannelName}`, ephemeral: true });
            } else {
                await interaction.reply({ content: 'ليس لديك صلاحية لتغير اسم هذا الروم الخاص', ephemeral: true });
            }
        }

    });

}


async function ads(interaction, roleName, rolePrice, deleteTime) {
    const userId = interaction.user.id;
    const member = await interaction.guild.members.fetch(userId);

    const tax = Math.floor(rolePrice * (20 / 19) + 1);

    if (deleteTime < 1) deleteTime = 300; 

    let embedMessage = new MessageEmbed()
        .setThumbnail(interaction.guild.iconURL())
        .setAuthor(interaction.guild.name, interaction.guild.iconURL())
        .setFooter(interaction.guild.name, interaction.guild.iconURL())
        .setTitle(`عملية شراء إعلان ${roleName} || 👑`)
        .setDescription(`قم بالتحويل ل <@${idbank}>\n#credit ${idbank} ${tax}`)
        .setColor('DARK_BLUE');

    let components = [
        new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId(`copy:${roleName}:${rolePrice}`)
                .setLabel('نسخ التحويل ')
                .setStyle('SECONDARY')
        )
    ];

    await interaction.update({ embeds: [embedMessage], components });

    const filter = (response) => {
        const expectedContent = `**:moneybag: | ${interaction.user.username}, has transferred \`$${rolePrice}\` to <@!${idbank}> **`;
        console.log(`Received message: ${response.content}`);
        return response.content.includes(expectedContent) && response.author.id === idprobot;
    };
    
    
    const collector = interaction.channel.createMessageCollector({
        filter,
        time: 30000,
    });

    collector.on("collect", async (response) => {
        embedMessage.setDescription(`**⏬ اضغط على الزر الذي في الاسفل لي نشر إعلانك **`);


        let components = [
            new MessageActionRow().addComponents(
                new MessageButton()
                    .setCustomId('modal3')
                    .setLabel('نشر الإعلان ')
                    .setStyle('SECONDARY')
            )
        ];
        await interaction.editReply({ embeds: [embedMessage], components });
          let embed = new MessageEmbed()
             .setThumbnail(interaction.guild.iconURL())
            .setAuthor(interaction.guild.name, interaction.guild.iconURL())
            .setFooter(interaction.guild.name, interaction.guild.iconURL())
            .setTitle(`تم الشراء`)
            .setDescription(`**
المنتج: اعلان

المشتري: ${interaction.user}

السعر: ${rolePrice}
**`)
            .setColor('DARK_BLUE');
            interaction.user.send({embeds: [embed]})
        collector.stop();
    });

    collector.on("end", async (collected) => {
        if (collected.size === 0) {
            embedMessage.setDescription(`لقد انتهى الوقت، لا تقم بالتحويل ${interaction.user}`);
            await interaction.editReply({ embeds: [embedMessage], components: [] });
        }
    });

    client.on('interactionCreate', async interaction => {
        if (!interaction.isButton()) return;

        if (interaction.customId === 'modal3') {
            const modal3 = new Modal()
                .setCustomId('a13')
                .setTitle('انشر منشورك');

            const roomname = new TextInputComponent()
                .setCustomId('roomname')
                .setLabel("اسم الروم")
                .setStyle('SHORT');

            const here2 = new TextInputComponent()
                .setCustomId('here3')
                .setLabel("قم بكتابة المنشور")
                .setStyle('PARAGRAPH');

            const firstActionRow = new MessageActionRow().addComponents(roomname);
            const secondActionRow = new MessageActionRow().addComponents(here2);

            modal3.addComponents(firstActionRow, secondActionRow);

            await interaction.showModal(modal3);
        }
    });

    client.on('interactionCreate', async interaction => {
        if (interaction.isModalSubmit() && interaction.customId === 'a13') {
            const here = interaction.fields.getTextInputValue('here3');
            const roomname = interaction.fields.getTextInputValue('roomname');

            try {
                const newChannel = await interaction.guild.channels.create(roomname, {
                    type: 'GUILD_TEXT',
                    position: 0, // Position at the top of the channel list
                    permissionOverwrites: [
                        {
                            id: interaction.guild.id,
                            allow: [Permissions.FLAGS.VIEW_CHANNEL],
                            deny: [Permissions.FLAGS.SEND_MESSAGES],
                        },
                        {
                            id: userId,
                            allow: [Permissions.FLAGS.SEND_MESSAGES],
                        },
                    ],
                });

                await newChannel.send({ content: `@everyone ${here}` });

                await interaction.reply({ content: `تم نشر المنشور بنجاح في ${newChannel}`, ephemeral: true });

                setTimeout(async () => {
                    await newChannel.delete();
                }, deleteTime * 1000);

            } catch (error) {
                console.error('Error creating or sending message to the new channel:', error);
                await interaction.reply({ content: 'حدث خطأ أثناء محاولة إنشاء ونشر المنشور في القناة الجديدة. يرجى المحاولة مرة أخرى.', ephemeral: true });
            }
        }
    });
}















// الرومات الخاصة
client.on('interactionCreate', async interaction => {

    if (!interaction.isButton()) return;

    if (interaction.customId === 'buy') {

        await pos(interaction, 'here', 50000, '996388001779298324');//سعر الروم الخاص وايدي الكاتجوري 


    }
})




// المنشورات المميرزة
client.on('interactionCreate', async interaction => {

    if (!interaction.isSelectMenu()) return;

    if (interaction.customId === 'select3') {

        const selectedValue = interaction.values[0];

        let embedMessage, components;

        switch (selectedValue) {
            case 'here':

            post(interaction , 'here' , 100000 , '1262287540635963423')//سعر المنشور الهير مع ايدي الروم منشورات المميرة

            break;

            case 'every' :

            post(interaction , 'everyone' , 200000 , '1262287540635963423')//سعر المنشور ايفري مع ايدي الروم منشورات المميرة



        }

        
    }

})


// الإعلانات
client.on('interactionCreate', async interaction => {

    if (!interaction.isSelectMenu()) return;

    if (interaction.customId === 'select4') {

        const selectedValue = interaction.values[0];

        let embedMessage, components;

        switch (selectedValue) {

            case 'MentionHereGiveways' :

            post(interaction , 'here' , 100000 , '1110183189982482553' )//سعر الاعلان الهير مع روم اعلانات

            break ;
            case 'MentionEveryoneGiveways' :

            post(interaction , 'everyone' , 200000 , '1110183189982482553' )//نفس الحكاية بس ايفري

            break ;
            case 'MentionEveryone' :

            post(interaction , 'everyone' , 400000  , '1210537674272931860')

            break ;

            case 'MentionHere' :

            post(interaction , 'here' , 1000000 , '' )

            break ;

            case 'MMM1' :

            ads(interaction , 'everyone' , 150000 , 259200 )

            break ;
            case 'MMM2' :

            ads(interaction , 'everyone' , 250000 ,  604800)

            break;


        }

        
    }

})


const imageToSend = 'https://media.discordapp.net/attachments/1252693866172252284/1258972922656329738/babaa625c10844ef.png?ex=6689fd67&is=6688abe7&hm=681bce38fdf06a517f90bbf231c048b4c3f233b018ddd8990890fcc4d057ddb1&=&format=webp&quality=lossless&width=1440&height=240';//رابط الخط

const channelsToMonitor = [
    '',
    '',
    '',
    '',  
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    '',
    ''
];//رومات الي ترسل الخط التلقائي

client.on('messageCreate', async message => {
    // Ignore bot messages and DMs
    if (message.author.bot || message.channel.type === 'dm') return;

    // Check if the message was sent in one of the specified channels
    if (channelsToMonitor.includes(message.channel.id)) {
        // Send the image
        message.channel.send({ content: imageToSend }).catch(err => {
            console.log(`Error sending image in channel ${message.channel.id}: ${err.message}`);
        });
    }
});









client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'transfRole') {
        const userId = interaction.user.id;
        const member = await interaction.guild.members.fetch(userId);

        let roleIds = [
            '1211710662481543268',
            '1173940676619157536',
            '996365835465674792',
            '996368935211503616',
            '996382617198927873',
            '996382760564445184',
            '996382954521624666',
            '997259592176246835',
            '997260131962204262',          
        ];//ايديات الرتب البيع حق نقل 

        let rolesFound = roleIds.filter(roleId => member.roles.cache.has(roleId));

        console.log(`Roles found: ${rolesFound.join(', ')}`); // Debug output

        if (rolesFound.length > 0) {
            const roleMentions = rolesFound.map(roleId => `<@&${roleId}>`).join(', ');

            let embedMessage = new MessageEmbed()
                .setColor('DARK_BLUE')
                .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                .setThumbnail(interaction.guild.iconURL())
                .setDescription(`رتب البيع اللي تمتلكها: ${roleMentions}`);

            let components = [
                new MessageActionRow().addComponents(
                    new MessageButton()
                        .setCustomId('ttf')
                        .setLabel('نقل')
                        .setStyle('SECONDARY'),
                )
            ];

            await interaction.update({ embeds: [embedMessage], components });
        } else {
            console.log('No roles found for sale.'); // Debug output
            await interaction.reply({ content: 'You do not have any roles for sale.', ephemeral: true });
        }
    }
});









client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'ttf') {
        let embedMessage = new MessageEmbed()
            .setColor('DARK_BLUE')
            .setAuthor(interaction.guild.name, interaction.guild.iconURL())
            .setThumbnail(interaction.guild.iconURL())
            .setDescription('**قم بي إرسال ايدي اليوزر الذي تريد التحويل له**');

        await interaction.update({ embeds: [embedMessage], components: [] });

        const filter = m => m.author.id === interaction.user.id;
        const collector = interaction.channel.createMessageCollector(filter, { max: 1, time: 60000 });

        collector.on('collect', async message => {
            const targetUserId = message.content.trim();

            const targetMember = await interaction.guild.members.fetch(targetUserId).catch(() => null);
            if (!targetMember) {
                return interaction.reply({ content: 'لم استطع العثور على الحساب يرجى ادخال الحساب بشكل صحيح', ephemeral: true });
            }
            let roleIds = [
            '1211710662481543268',
            '1173940676619157536',
            '996365835465674792',
            '996368935211503616',
            '996382617198927873',
            '996382760564445184',
            '996382954521624666',
            '997259592176246835',
            '997260131962204262', 
              
            ];//نفس الحكاية
    
            let rolesFound = roleIds.filter(roleId => interaction.member.roles.cache.has(roleId));

            try {
                // Transfer roles
                for (let roleId of rolesFound) {
                    await targetMember.roles.add(roleId);
                    await interaction.member.roles.remove(roleId);
                }

                // Confirmation messages
                const roleMentions = rolesFound.map(roleId => `<@&${roleId}>`).join(', ');

                const confirmationEmbed = new MessageEmbed()
                    .setColor('DARK_BLUE')
                    .setAuthor(interaction.guild.name, interaction.guild.iconURL())
                    .setThumbnail(interaction.guild.iconURL())
                    .setDescription(`الرتب ${roleMentions}تم نقلها للحساب  <@${targetMember.user.id}>.`);

                await interaction.editReply({ embeds: [confirmationEmbed] });
            } catch (error) {
                console.error('Error transferring roles:', error);
                await interaction.editReply({ content: 'Failed to transfer roles. Please try again later.', ephemeral: true });
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                interaction.editReply({ content: 'No user ID provided. Interaction cancelled.', ephemeral: true });
            }
        });
    }
});
















































client.on('interactionCreate', async interaction => {
    if (interaction.isSelectMenu() && interaction.customId === 'roleSelect1') {
        const selectedValue = interaction.values[0];

        let embedMessage, components;
													
        switch (selectedValue) {
            case 'Towers':
                await handleRoleSelection(interaction, 'N7 SUPERHERO', '1173940676619157536', 1000000);//سعر الرتبة والايدي والاسم
                break;
            case 'Dragon':
                await handleRoleSelection(interaction, 'N7', '996365835465674792', 500000);//نفسه
                break;


        }
     
    }

   
});


client.on('interactionCreate', async interaction => {
    if (interaction.isSelectMenu() && interaction.customId === 'roleSelect') {
        const selectedValue = interaction.values[0];

        let embedMessage, components;

        switch (selectedValue) {
            case 'Angel': // هذي تكون نفس value فوق
                await handleRoleSelection(interaction, 'BEE', '', 250000);//رتب العامة
                break;
            case 'Sepcial':
                await handleRoleSelection(interaction, 'HONEY', '', 150000);//
                break;
            case 'Perfect':
                await handleRoleSelection(interaction, 'A ROSE', '', 80000);//
                break;
            case 'Demon' :    
            await handleRoleSelection(interaction, 'FLOWER', '', 40000);//
            break;

            case 'Graet' :    
            await handleRoleSelection(interaction, 'DESIGNER', '', 80000);//
            break;

            case 'Developer' :    
            await handleRoleSelection(interaction, 'DEVLOPER', '', 80000);//
            break;
          



        }
    }

});

async function handleRoleSelection(interaction, roleName, roleId, rolePrice) {
    const userId = interaction.user.id;
    const member = await interaction.guild.members.fetch(userId);

    const tax = Math.floor(rolePrice * (20 / 19) + 1);

    if (member.roles.cache.has(roleId)) {
        await interaction.reply({ content: `لديك هذه الرتبة بالفعل`, ephemeral: true });
        return;
    }

    const embedMessage = new MessageEmbed()
        .setThumbnail(interaction.guild.iconURL())
        .setAuthor(interaction.guild.name, interaction.guild.iconURL())
        .setFooter(interaction.guild.name, interaction.guild.iconURL())
        .setTitle(`عملية شراء رتبة ${roleName} || 👑`)
        .setDescription(`قم بالتحويل ل <@${idbank}>\n \n \` #credit ${idbank} ${tax}`)
        .setColor('DARK_BLUE');

    const components = [
        new MessageActionRow().addComponents(
            new MessageButton()
                .setCustomId(`copy:${roleName}:${rolePrice}`)
                .setLabel('نسخ التحويل ')
                .setStyle('SECONDARY')
        )
    ];

    await interaction.update({ embeds: [embedMessage], components });

    const filter = (response) => 
        response.content.includes(`has transferred \`$${rolePrice}\` to <@!${idbank}>`) &&
        response.author.id === idprobot;

    const collector = interaction.channel.createMessageCollector({
        filter,
        time: 30000,
    });

    collector.on("collect", async (response) => {
          let embed = new MessageEmbed()
             .setThumbnail(interaction.guild.iconURL())
            .setAuthor(interaction.guild.name, interaction.guild.iconURL())
            .setFooter(interaction.guild.name, interaction.guild.iconURL())
            .setTitle(`تم الشراء`)
            .setDescription(`**
المنتج: رتبه

المشتري: ${interaction.user}

السعر: ${rolePrice}
**`)
            .setColor('DARK_BLUE');
            interaction.user.send({embeds: [embed]})
        embedMessage.setDescription(`
            عملية شراء رتبة 🜲  ||   ${roleName} :
            :Owner: - تم تسليمك رتبة 🜲  ||  ${roleName} : بسعر ${rolePrice} بنجاح
        `);
        await interaction.editReply({ embeds: [embedMessage], components: [] });
        await member.roles.add(roleId);
        collector.stop();
    });

    collector.on("end", async (collected) => {
        if (collected.size === 0) {
            embedMessage.setDescription(`لقد انتهى الوقت، لا تقم بالتحويل  ${interaction.user}`);
            await interaction.editReply({ embeds: [embedMessage], components: [] });
        }
    });
}












client.on('messageCreate', async message => {
    if (message.author.bot) return; 

    if (message.content.toLowerCase() === '!leaderboard') {
        const leaderboard = getLeaderboard();
        const embed = generateLeaderboardEmbed(leaderboard);
        message.channel.send({ embeds: [embed] });
    }

  
    if (message.content.toLowerCase() === '!points') {
        const userId = message.author.id;
        const userPoints = db.get(`points_${userId}`) || 0;
        message.reply(`You have ${userPoints} points.`);
    }
});


function getLeaderboard() {
    const allUsers = db.all().filter(data => data.ID.startsWith('points_'));
    const sortedUsers = allUsers.sort((a, b) => b.data - a.data); 
    return sortedUsers.slice(0, 10); 
}


function generateLeaderboardEmbed(leaderboard) {
    const embed = new MessageEmbed()
        .setTitle('Leaderboard')
        .setColor('DARK_BLUE');

    leaderboard.forEach((user, index) => {
        const userId = user.ID.split('_')[1]; 
        const userName = client.users.cache.get(userId)?.username || 'Unknown User'; 
        const userPoints = user.data || 0; 
        embed.addField(`${index + 1}. ${userName}`, `Points: ${userPoints}`, true);
    });

    return embed;
}








client.on('interactionCreate', async interaction => {
    if (interaction.isButton() && interaction.customId.startsWith('copy')) {
        const [, roleName, rolePrice] = interaction.customId.split(':');
        const price = parseInt(rolePrice, 10); 
        const tax = Math.floor(price * (20 / 19) + 1);
        await interaction.reply({ content: `**#credit ${idbank}  ${tax} **`, ephemeral: true });
    }
});






client.on('interactionCreate', async interaction => {
    if (interaction.isButton() && interaction.customId.startsWith('escalate_ticket')) {
        const selectMenu = new MessageSelectMenu()
            .setCustomId('ticket_action')
            .setPlaceholder('Select an action')
            .addOptions([
                {
                    label: 'اصافة عضو للتذكرة',
                    description: 'لإضافة شخص في تذكرة ',
                    value: 'add_member',
                },
                {
                    label: 'تغير اسم تذكرة',
                    description: 'لتغير اسم تذكرة لإسم جديد',
                    value: 'rename_channel',
                },
                {
                    label: 'حذف شخص من تذكرة',
                    description: 'لإزالة الشخص من التذكرة',
                    value: 'delete_user',
                }
            ]);

        const row = new MessageActionRow().addComponents(selectMenu);

        await interaction.reply({ content: 'Select an action for the ticket:', components: [row], ephemeral: true });
    } else if (interaction.isSelectMenu() && interaction.customId === 'ticket_action') {
        const selectedAction = interaction.values[0];
        let modal;

        switch (selectedAction) {
            case 'add_member':
                modal = new Modal()
                    .setCustomId('add_member_modal')
                    .setTitle('Add Member')
                    .addComponents(
                        new MessageActionRow().addComponents(
                            new TextInputComponent()
                                .setCustomId('member_id')
                                .setLabel("Member ID")
                                .setStyle('SHORT')
                        )
                    );
                break;
            case 'rename_channel':
                modal = new Modal()
                    .setCustomId('rename_channel_modal')
                    .setTitle('Rename Channel')
                    .addComponents(
                        new MessageActionRow().addComponents(
                            new TextInputComponent()
                                .setCustomId('new_channel_name')
                                .setLabel("New Channel Name")
                                .setStyle('SHORT')
                        )
                    );
                break;
            case 'delete_user':
                modal = new Modal()
                    .setCustomId('delete_user_modal')
                    .setTitle('Delete User from Ticket')
                    .addComponents(
                        new MessageActionRow().addComponents(
                            new TextInputComponent()
                                .setCustomId('delete_member_id')
                                .setLabel("Member ID")
                                .setStyle('SHORT')
                        )
                    );
                break;
        }

        await interaction.showModal(modal);
    } else if (interaction.isModalSubmit()) {
        if (interaction.customId === 'add_member_modal') {
            const memberId = interaction.fields.getTextInputValue('member_id');
            const channel = interaction.channel;

            try {
                const member = await interaction.guild.members.fetch(memberId);
                await channel.permissionOverwrites.create(member, { VIEW_CHANNEL: true, SEND_MESSAGES: true });
                await interaction.reply({ content: `Successfully added ${member.user.tag} to the ticket.`, ephemeral: true });
            } catch (error) {
                console.error(error);
                await interaction.reply({ content: 'Failed to add the member. Please ensure the ID is correct.', ephemeral: true });
            }
        } else if (interaction.customId === 'rename_channel_modal') {
            const newChannelName = interaction.fields.getTextInputValue('new_channel_name');
            const channel = interaction.channel;

            try {
                await channel.setName(newChannelName);
                await interaction.reply({ content: `Successfully renamed the channel to ${newChannelName}.`, ephemeral: true });
            } catch (error) {
                console.error(error);
                await interaction.reply({ content: 'Failed to rename the channel. Please try again.', ephemeral: true });
            }
        } else if (interaction.customId === 'delete_user_modal') {
            const memberId = interaction.fields.getTextInputValue('delete_member_id');
            const channel = interaction.channel;

            try {
                const member = await interaction.guild.members.fetch(memberId);
                await channel.permissionOverwrites.delete(member);
                await interaction.reply({ content: `Successfully removed ${member.user.tag} from the ticket.`, ephemeral: true });
            } catch (error) {
                console.error(error);
                await interaction.reply({ content: 'Failed to remove the member. Please ensure the ID is correct.', ephemeral: true });
            }
        }
    }
});





const slashCommands = [
    {
        name: 'setchannel',
        description: 'Set a specific channel for message sending',
        options: [
            {
                name: 'channel',
                type: 7, // Correct type for CHANNEL
                description: 'The channel to set',
                required: true,
            }
        ]
    },
    {
        name: 'disablechannel',
        description: 'Disable the currently set channel',
    },
    {
        name: 'changechannel',
        description: 'Change the channel for message sending',
        options: [
            {
                name: 'channel',
                type: 7, // Correct type for CHANNEL
                description: 'The new channel to set',
                required: true,
            }
        ]
    }
];

client.once('ready', async () => {
    const rest = new REST({ version: '9' }).setToken(token);
    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: slashCommands },
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
});