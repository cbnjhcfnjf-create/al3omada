const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('Hello World!'));

app.listen(port, () => console.log(`Example app`));

const emj = require('./emj.json');


const moment = require("moment")
const ms = require("ms")
const { Client, Intents, MessageEmbed, Interaction, MessageButton, MessageActionRow, Modal, WebhookClient, createEmbed, MessageSelectMenu, Collection, Permissions, TextInputComponent, MessageFlags, EmbedBuilder, joinVoiceChannel, loadImage, createCanvas } = require("discord.js");
const Discord = require('discord.js');
const client = new Client({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_MEMBERS, 32767]
});
client.setMaxListeners(0)

client.login("MTMyODcxMjMyMzM4MDE1NDM3OQ.G9lm6p.SPna9GWxgPQiHNKvgvc1__hUczEi3BM1YjoY4w");

client.on("ready", () => {
  console.log(`Logged in as  ${client.user.username}`)
  client.user.setActivity(`# ~ Everest System`, { type: 'PLAYING' })
  client.user.setStatus("idle")
});

client.on("guildCreate", (guild) => { 
 if(guild.id !== "1241129866422653019")return guild.leave();   
});
const db = require("pro.db")
const { Database } = require('st.db');
const db2 = new Database("m5drat.json"); 
const probot = require("probot-tax");
const MeetRole = "1241129866422653021" 
const staffManagerRole = "1241129866515185669"
const discorsLeader = "1241129866708127836"
const OfficialRole = "1241129866515185668"
const ticketManagerRole = '1241129866515185669'
const adsManagerRole = '1241129866708127836'
const RolesRole = "1241129866603008113"
const discordStaff = "1241129866515185669"
const UnderTestRole = "1206870979771367434"
const developerId = "816916374945005568"
const bankid = "1022493170598154311"
const spinbank = "1022493170598154311"
const manshoratRoom = '1241129867848716407'
const roomschannel12345 = ''
const adsroom = '૱・اعلانات・المنشن'
const prefix = "$"
const lineLink = "https://i.postimg.cc/65q9MdQM/line.png"
const logChannelID = "1248689753151246427"
const colorE = "c1e1f3"
const posts = "1241129867848716407"


client.on('messageCreate', async mesg => {
if(mesg.content == prefix + `اظهار`) {
if(!mesg.member.roles.cache.find((role) => role.id=== '1241129866708127836')) //ايدي رول الي يقدر يتحكم
return mesg.reply(`You Dont Have Premissions`);
let men = mesg.guild.roles.cache.find(role => role.id === '1241129866469048367', '1241129866469048369'); //ايدي رول الممبر
if(!men) return;
    let everyone = mesg.guild.roles.cache.find(pu7 => pu7.name === '@everyone');

mesg.channel.permissionOverwrites.create(men,{'VIEW_CHANNEL': true});
mesg.channel.permissionOverwrites.create(everyone,{'VIEW_CHANNEL': true});
mesg.reply({content: `**تم اظهار الروم بنجاح ${emj.True}**`});

client.on('ready', () => {

    setInterval( async () => {

    client.channels.fetch("1241129866720448530") 

     .then((channel) => { 

      const VoiceConnection = joinVoiceChannel({

       channelId: channel.id, 

       guildId: channel.guild.id, 

       adapterCreator: channel.guild.voiceAdapterCreator 

       });

    }).catch((error) => { return; });

    }, 1000)

});
}});
client.on('messageCreate', async mesg => {
if(mesg.content == prefix + `اخفاء`) {
if(!mesg.member.roles.cache.find((role) => role.id=== '1241129866708127836')) //ايدي رول الي يقدر يتحكم
return mesg.reply(`You Dont Have Premissions`);
let men = mesg.guild.roles.cache.find(role => role.id === '1241129866469048367', '1241129866469048369'); //ايدي رول الممبر
if(!men) return;
    let everyone = mesg.guild.roles.cache.find(pu7 => pu7.name === '@everyone');

mesg.channel.permissionOverwrites.create(men,{'VIEW_CHANNEL': false});
mesg.channel.permissionOverwrites.create(everyone,{'VIEW_CHANNEL': false});
mesg.reply({content: `**تم اخفاء الروم بنجاح ${emj.True}**`});

}})
client.once('ready', () => {
    console.log('Bot Is Online 🟢');

    const myServerId = "1241129866422653019"; // Replace with your server's ID

    client.guilds.cache.forEach(guild => {
        if (guild.id !== myServerId) {
            guild.leave()
                .then(() => console.log(`Left ${guild.name}`))
                .catch(err => console.error(`Error leaving ${guild.name}`, err));
        }
    });
});
client.on("messageCreate", message => {
  if (message.content.startsWith(prefix + "اعلان")) {
    if (message.member.roles.cache.some(r=> r.id == discorsLeader)) {

if(message.content.startsWith(prefix + "اعلانات")) return false;
  
member = message.mentions.members.first()
      if (!member) return message.reply("** يرجى منشن صاحب الاعلان أولاً !**")
manshor = message.content.split(" ").slice(2).join(" ");
  if (!manshor) return message.reply("** يرجى وضع الاعلان أولاً !**")

let embed = new Discord.MessageEmbed()
      .setTitle(`** إختر نوع المنشن :**`)
      .setDescription(`** يرجى إختيار نوع المشنن المناسب : \`here\` أو \`everyone\`\nالاعلان :\n\`${manshor}\`**`)
      .setColor(" c1e1f3")
  let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("here")
        .setCustomId("adhere")
        .setStyle("SECONDARY")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("everyone")
        .setCustomId("adeve")
        .setStyle("SECONDARY")
    )

  message.reply({ embeds: [embed], components: [row] })
            }}});

client.on("interactionCreate", async interaction => {
  if (!interaction.isButton()) return;

 if (interaction.customId === "adhere") {
    if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
    const message = await interaction.channel.messages.fetch(interaction.message.id); 

const heremanshor = `@here\n${manshor}`

    
let embed2 = new Discord.MessageEmbed()
      .setTitle(`** هل انت متأكد من إرسال الاعلان ؟**`)
  .setDescription(`** يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n الاعلان :\n\`${heremanshor}**`)
      .setColor(" c1e1f3")
  let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("adhcompleteid")
        .setStyle("SUCCESS")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("adhcancelid")
        .setStyle("DANGER")
    )
    
    message.edit({ embeds: [embed2], components: [row2] });
      } else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    }
  } else if (interaction.customId === "adeve") {
    if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
    const message = await interaction.channel.messages.fetch(interaction.message.id); 

const evemanshor = `@everyone\n${manshor}`

    
let embed2 = new Discord.MessageEmbed()
      .setTitle(`** هل انت متأكد من إرسال الاعلان ؟**`)
  .setDescription(`** يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n الاعلان :\n\`${evemanshor}**`)
      .setColor(" c1e1f3")
  let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("adecompleteid")
        .setStyle("SUCCESS")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("adecancelid")
        .setStyle("DANGER")
    )
    
    message.edit({ embeds: [embed2], components: [row2] });
      } else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    }
  }
});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "adhcancelid") {
if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
  
let embed3 = new Discord.MessageEmbed()
  .setColor(` c1e1f3`)
  .setDescription(`** تم إلغاء إرسال هذا الاعلان .
 بواسطة :
${interaction.member}
**`)

message.edit({ embeds: [embed3], components: [] });
} else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
}
}});
client.on('messageCreate', async (message) => {

if (message.author.bot) return;

if (!message.content.startsWith('تحويل')) return;

const args = message.content.slice('تحويل'.length).trim().split(' ');

const amount = args[0];

const bankId = "1022493170598154311";

const taxRate = 0.05264; // ضريبة 5%

let numericAmount = 0;

if (amount.endsWith('k')) {

numericAmount = parseFloat(amount.slice(0, -1)) * 1000;

} else if (amount.endsWith('m')) {

numericAmount = parseFloat(amount.slice(0, -1)) * 1000000;

} else {

numericAmount = parseFloat(amount);

}

if (!numericAmount ||!bankId) {

message.reply('يرجى إدخال المبلغ');

return;

}

const tax = numericAmount * taxRate;

const total = numericAmount + tax;

message.channel.send(`c ${bankId} ${total}`);

});
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "adecancelid") {
if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
  
let embed3 = new Discord.MessageEmbed()
  .setColor(`15FFAF`)
  .setDescription(`** تم إلغاء إرسال هذا الاعلان .
 بواسطة :
${interaction.member}
**`)

message.edit({ embeds: [embed3], components: [] });
} else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
}
}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "adhcompleteid") {
if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const adChannel = client.channels.cache.get('1241129867848716407');
  const adLog = interaction.guild.channels.cache.get('1124686893821476906');

  const memhere = `${member}`
  const manshorhere = `@here\n${manshor}\nاعلان مدفوع فقط تبي مثله حياك <#1241129868515610808>`
  
let embed5 = new Discord.MessageEmbed()
  .setColor(`15FFAF`)
  .setDescription(`** تم إرسال هذا الاعلان إلى ${adChannel}
 بواسطة :
${interaction.member}
**`)

message.edit({ embeds: [embed5], components: [] });

  await adChannel.send(`${manshorhere}`);
await adChannel.send(`${lineLink}`)

await adLog.send(`** الاعلان :\n\`${manshor}\`\n المنشن :\nhere\n المشرف المسؤول :\n${interaction.member}\n صاحب الاعلان :\n${memhere}\n تاريخ الاعلان : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await adLog.send(`${lineLink}`)
  
} else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
}
}});
client.on('messageCreate', async (message) => {

    if (message.content.startsWith('$ايفكت')) {

        const args = message.content.split(' ');

        const imurl = args[1]; // URL للصورة المرسلة

        if (!imageUrl) {

            return message.reply('يرجى إرسال رابط الصورة.');

        }

        try {

            const baseImage = await loadImage(imurl);

            const frameImage = await loadImage('https://media.discordapp.net/attachments/1276098685255548960/1278622866727763968/3F4ACCD4-86E5-473D-93CF-2EB80E36249F.png');

            const canvas = createCanvas(baseImage.width, baseImage.height);

            const ctx = canvas.getContext('2d');

            // رسم الصورة الأساسية

            ctx.drawImage(baseImage, 0, 0, baseImage.width, baseImage.height);

            // رسم الإطار فوق الصورة

            ctx.drawImage(frameImage, 0, 0, baseImage.width, baseImage.height);

            const buffer = canvas.toBuffer('image/png');

            const attachment = { files: [{ attachment: buffer, name: 'devmuslim.png' }] };

            await message.channel.send({ files: attachment.files });

        } catch (error) {

            console.error(error);

            message.reply('حدث خطأ أثناء معالجة الصور.');

        }

    }

});
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "adecompleteid") {
if (interaction.member.roles.cache.some((role) => role.id === discorsLeader) || interaction.member.permissions.has('ADMINISTRATOR')) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const adChannel2 = client.channels.cache.get('1241129867848716407');
  const adLog2 = interaction.guild.channels.cache.get('1124686893821476906');

  const memeve = `${member}`
  const manshoreve = `@everyone\n${manshor}\nاعلان مدفوع فقط تبي مثله حياك <#1241129868515610808>`
  
let embed5 = new Discord.MessageEmbed()
  .setColor(` c1e1f3`)
  .setDescription(`** تم إرسال هذا الاعلان إلي ${adChannel2}
 بواسطة :
${interaction.member}
**`)

message.edit({ embeds: [embed5], components: [] });

  await adChannel2.send(`${manshoreve}`);
await adChannel2.send(`${lineLink}`)

await adLog2.send(`** الاعلان :\n\`${manshor}\`\n المنشن :\neveryone\n المشرف المسؤول :\n${interaction.member}\n صاحب الاعلان :\n${memeve}\n تاريخ الاعلان : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await adLog2.send(`${lineLink}`)
  
} else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
}
}});
client.on('messageCreate', (message) => {
let probot = ["282859044593598464"]
if(!probot.includes(message.author.id)) return;
  if (message.content.toLowerCase().includes('قام بتحويل') && message.channel.id === '1235936661821587557') {
    message.channel.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`);
  }
});

const replace = [
  {
    word: "متوفر",
    replace: "مت9فر"
  },
   {
    word: "بيع",
    replace: "بي3"
  },
   {
    word: "شوب",
    replace: "ش9ب"
  },
   {
    word: "ديسكورد",
    replace: "ديس_ورد"
   },
  {
    word: "تبادل",
    replace: "تبا1دل"
 },
{
  word: "توكن",
    replace: "ت9كن"
   },
  {
    word: "بوست",
    replace: "ب9ست"
   },
  {
    word: "توكنات",
    replace: "ت9كنات"
   },
  {
    word: "بوستات",
    replace: "ب9ستات"
   },
  {
    word: "حساب",
    replace: "حس1ب"
   },
  {
    word: "حسابات",
    replace: "حس1ب1ت"
   },
  {
word: "نتفيلكس",
    replace:"ن$$فيلكس"
  },
{
  word: "اون",
    replace: "ا9ن"
   },
  {
    word: "متوفر",
    replace: "مت9فر"
  },
   {
    word: "بيع",
    replace: "بي3"
  },
   {
    word: "شوب",
    replace: "ش9ب"
  }, 
   {
    word: "ديسكورد",
    replace: "ديس_ورد"
  },
   {
    word: "للبيع",
    replace: "للـب-ع"
  }, 
   {
    word: "حساب",
    replace: "7ساب"
  },
   {
    word: "سعر",
    replace: "س3ر"
  },
   {
    word: "شحن",
    replace: "شـ7ن"
  }, 
   {
    word: "فيزا",
   replace: "فـيز-"
  },
   {
    word: "سيرفر",
    replace: "سيرفr"
  },
   {
    word: "شراء",
    replace: "شـrاء"
   },
   {
    word: "نيترو",
    replace: "نيتر9"
   },
    { word: "كردت",
     replace: "كرد3"
     },
   {
     word: "ثمن",
      replace: "ثم3"
       },

]
  
client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "تشفير")) {
  if(!message.member.permissions.has("ADMINISTRATOR")) return;
    const embed = new MessageEmbed()
    .setTitle("تشفير منشورك")
    .setDescription("** لتشفير منشورك يرجى الضغط على تشفير منشورك ووضع منشورك ويتم تشفيره مباشر وقم بنسخه فقط .**")
    .setColor("c1e1f3")
    .setImage("https://cdn.discordapp.com/attachments/1243164449951715389/1328728572151595110/eb72b0323a4ca3e5.png?ex=678913ea&is=6787c26a&hm=9565b36d1451969199ebffb59fbee4c16aa59f3d992fc564805bf4eab79364d9&")
    .setThumbnail(message.guild.iconURL())
    
      const row = new MessageActionRow()
        .addComponents(
            new MessageButton()
            .setStyle("SUCCESS")
            .setLabel("تشفير")
            .setCustomId('replace')
            
          
        )
    message.channel.send({embeds: [embed], components: [row]})
  }
})


client.on("interactionCreate", async i => {
  if (!i.isButton()) return;
  if (i.customId == "replace") {
            const modal = new Modal()
            .setTitle('تشفير')
            .setCustomId('rep')

   const replacer = new TextInputComponent()
            .setCustomId('replacetext')
            .setLabel(`قم بكتابة منشورك الذي تريد تشفيره`)
            .setMaxLength(2000)
            .setRequired(true)
            .setStyle("PARAGRAPH")
    
       const rows = [replacer].map(
                (component) => new MessageActionRow().addComponents(component)
            )
            modal.addComponents(...rows);
            i.showModal(modal);
        
  }
  
})

client.on("interactionCreate", async i => {
  if (!i.isModalSubmit()) return;
  if (i.customId == "rep") {
let text = i.fields.getTextInputValue('replacetext');
    let replaced = false;

    replace.forEach(t => {
      const regex = new RegExp(t.word, 'g');
      if (regex.test(text)) {
        text = text.replace(regex, t.replace);
        replaced = true;
      }
    });


    if (replace) {
i.reply({content: `\`تم بنجاح تشفير منشورك :\`\n\n ${text}`, ephemeral: true})
    } else {
      i.reply({content: "**عذرا حدث خطأ ما منشور غير صالح برجاء تاكد من منشورك ومحاولة مره اخرى.**", ephemeral: true})
    }
  }
  
})

client.on("messageCreate", async message => {
if (message.author.bot) return;
if (!message.channel.guild) return;
if (message.content.startsWith(prefix + 'say')) {
    if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("** 😕 You don't have permissions **"); 
}
if(!message.guild.me.permissions.has('ADMINISTRATOR')) {
  return message.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position. **`);
}
let args = message.content.split(' ').slice(2).join(' ')
let argss = message.content.split(' ')
        let channel = message.mentions.channels.first() || message.guild.channels.cache.get(argss[1])
        let attach = message.attachments.first()
        if (!channel) return message.channel.send('** 😕 Please mention channel or id **');
        if (!args) return message.channel.send('** ❌ Please select a message **');
        message.delete()
      if (!attach) {
        channel.send({content: `${args}`});
} else {
        channel.send({content: `${args}`, files: [attach]});
}
    }
});



client.on('messageCreate', async msg => {
  if(msg.content.startsWith(prefix + "تقديم")){
    if(!msg.member.permissions.has(`ADMINISTRATOR`))return;
    let row = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setStyle('PRIMARY')
      .setLabel(`اضغط للتقديم`)
      .setEmoji('<:Evsupport:1326656228847521833>')
      .setCustomId('submit-order')
    )
    msg.channel.send({embeds: [
      new MessageEmbed()
      .setTitle('تقديم الإدارة')
       .setImage('https://cdn.discordapp.com/attachments/1243164449951715389/1326572084305854464/36ad8547b8069f61.png?ex=67892487&is=6787d307&hm=6b6829406352796ccc668eae676f3e5d65d0c04a90fd92a681aab33092efb530&')
      .setThumbnail(msg.guild.iconURL())
      .setDescription(`** Everest S Staff Apply・تقديم الإدارة**
 
**
> اسمك، عمرك،  :
> بلدك :
> هل كنت إداري في سيرفر شوب (أذكره) 
> هل لديك خبرة سابقة بالشوبات 
> عدد ساعات تفاعلك اليومية 
يُرجى الإجابة على الاسئلة أعلاه ⬆️⬆️ .

مُلاحظة هامة : الشعار غير مطلوب، فقط رابط السيرفر في البايو. **

**#Everest_Owners**`)
      .setColor(' c1e1f3')
    ], components: [row]})
  }
})
client.on('interactionCreate', async interaction => {
  if(!interaction.isButton())return;
  if(interaction.customId === "submit-order"){
   
    const modal = new Modal() 
	.setCustomId('modal-submit')
	.setTitle('تقديم للاداره')
    const name = new TextInputComponent() 
    .setCustomId("name")
      .setLabel("اسمك وعمرك")
      .setStyle("SHORT")
      .setRequired(true);
    const age = new TextInputComponent() 
      .setCustomId("age")
      .setLabel("بلدك")
      .setStyle("SHORT")
      .setRequired(true);
      const place = new TextInputComponent() 
      .setCustomId('place')
      .setLabel('هل لديك خبرات سابقه باشوبات')
      .setStyle('SHORT') 
      .setRequired(true);
       const discordd = new TextInputComponent() 
      .setCustomId('discord')
	  .setLabel('هل كنت إداري في سيرفر شوب (اذكره)')
	  .setStyle('SHORT') 
	  .setRequired(true);
      const admin = new TextInputComponent() 
      .setCustomId('admin')
	  .setLabel('عدد ساعات تفاعلك اليومية')
	  .setStyle('SHORT') 
	  .setRequired(true)
      
    const row = new MessageActionRow().addComponents(name)
    const row2 = new MessageActionRow().addComponents(age)
    const row3 = new MessageActionRow().addComponents(place)
    const row4 = new MessageActionRow().addComponents(discordd)
    const row5 = new MessageActionRow().addComponents(admin)
      modal.addComponents(row, row2, row3, row4, row5) 
      
       await interaction.showModal(modal)

			
}

    
})

client.on('interactionCreate', async (modal) => {
if (!modal.isModalSubmit()) return;
	if (modal.customId == 'modal-submit') {
   
    const name = modal.fields.getTextInputValue('name');
    const age = modal.fields.getTextInputValue('age');
    const place = modal.fields.getTextInputValue('place');
    const discord = modal.fields.getTextInputValue('discord');
    const admin = modal.fields.getTextInputValue('admin');
    const embed = new MessageEmbed()
    .addFields(
      {name: 'الاسم و العمر', value: name},
      {name: 'بلدك', value: age},
      {name: 'هل لديك خبرات سابقة باشوبات', value: place},
      {name: 'هل كنت إداري في سيرفر شوب (اذكره)', value: discord},
     {name: 'عدد ساعات تفاعلك اليومية', value: admin}
    )
    .setColor('c1e1f3')
    .setThumbnail(modal.guild.iconURL())
    .setTitle(`تقديم اداره لدي ${modal.user.username}`)
    let channel = modal.guild.channels.cache.get('1326928258557546617')
    let row = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setLabel('قبول')
      .setEmoji('<:Evshield:1326656187869036646>')
      .setStyle('SUCCESS')
      .setCustomId(`accept-submit_${modal.user.id}`),
      new MessageButton()
      .setLabel('رفض')
      .setEmoji('<:Everror:1326655804337557526>')
      .setStyle('DANGER')
      .setCustomId(`declin-submit_${modal.user.id}`)
    )
    
    channel.send({content: `<@${modal.user.id}>`, embeds: [embed], components: [row]})
    modal.reply({content: `** تم ارسال تقديمك**`, ephemeral: true})
  }

})

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;
  let customId = interaction.customId;
  let acceptAnddeclinRole = interaction.guild.roles.cache.get("1241129866708127836");
  let accepedRole = interaction.guild.roles.cache.get("1241129866515185669", "1241129866708127836");
  if (customId.split("_")[0] == "accept-submit") {
    const member = customId.split("_")[1];
    const summiter = interaction.guild.members.cache.get(member);
    if (!interaction.member.roles.cache.has(acceptAnddeclinRole.id))
      return interaction.reply("انت لست مسؤول القبول");
    let embed = new MessageEmbed()
      .setAuthor(
        interaction.guild.name,
        interaction.guild.iconURL({ dynamic: true })
      )
      .setDescription(`تم قبول ${summiter}\n الاداري: ${interaction.member}`)
      .setColor("GREEN");
    summiter.roles.add(accepedRole.id).then(async () => {
        const acceptedEmbed = new MessageEmbed().setDescription(`**مرحبا ، لقد تم قبولك مبدئياَ في سيرفر Everest S
      يرجى فتح تكت <#1241129868515610808> تعليم لكي يتم تعليمك و اختبارك 
      نتمنى لك حظا موفقاً🌹.**`)
       summiter.send({embeds: [acceptedEmbed]}).catch(e => {
        return interaction.reply(`error with sending congrats for submiting ${summiter}`)
      })
    }).catch(e => {
      return interaction.reply(`error with give role for ${summiter}`)
    })
    interaction.reply({ embeds: [embed] });
      interaction.message.edit({components: []})
  } else if(customId.split("_")[0] == "declin-submit") {
    let member = customId.split("_")[1];
    const summiter = interaction.guild.members.cache.get(member);
    if (!interaction.member.roles.cache.has(acceptAnddeclinRole.id))
    return interaction.reply("انت لست مسؤول القبول");
    let embed = new MessageEmbed()
      .setAuthor(
        interaction.guild.name,
        interaction.guild.iconURL({ dynamic: true })
      )
      .setDescription(`تم رفض ${summiter}\n الاداري: ${interaction.member}`)
      .setColor("RED");
      const declinedEmbed = new MessageEmbed().setDescription(`**مرحبا ، نعتذر لقد تم رفضك في سيرفر Everest S
      بلتوفيق لك**`)
    await interaction.reply({ embeds: [embed] });
      interaction.message.edit({components: []})
        summiter.send({embeds: [declinedEmbed]}).catch(e => {
         interaction.reply(`error with sending sorry for submiting ${summiter}`)
      })
  }
});

const logChannelId2 = '1326928258557546617';
const logWheelSpin = (userId, commandAuthorId, prize, wheelType) => {
  const currentDate = new Date().toLocaleString();
  // إعداد رسالة الإيمبد
  const logEmbed = new MessageEmbed()
    .setColor('#15FFAF')
    .setTitle('Wheel Spin Log')
    .addFields(
      { name: 'التاريخ', value: currentDate, inline: true },
      { name: 'ايدي الشخص', value: userId, inline: true },
      { name: 'ايدي المشرف', value: commandAuthorId, inline: true },
      { name: 'الجائزة', value: prize, inline: true },
      { name: 'نوع العجلة', value: wheelType, inline: true },  
    );

  // إرسال رسالة الإيمبد إلى القناة المحددة
  const logChannel = client.channels.cache.get(logChannelId2);
  if (logChannel) {
    logChannel.send({ embeds: [logEmbed] });
  } else {
    console.error('[ERROR] - تعذر العثور على قناة اللوج. تحقق من إعدادات logChannelId2.');
  }
};
// إعداد زر الـ Spin
const perms = '996364077817405531';

// Your existing code for initializing the client and other imports...

client.on('messageCreate', (message) => {
  if (message.content === '$spin') {
    if (message.member.roles.cache.some((role) => role.name === 'Spin') || message.member.roles.cache.some(r => r.id == perms)) {
      const button = new MessageButton()
        .setStyle('SUCCESS')
        .setLabel('Spin')
        .setCustomId('spin_button');
      const row = new MessageActionRow().addComponents(button);
      const embed = new MessageEmbed()
        .setColor('15FFAF')
        .setTitle(`**  Na7la \`S\` Wheel Of Luck・عجلة الحظ**`)
        .setDescription('> ** إضغط على الزر Spin لتدوير العجلة .**');
      message.channel.send({ embeds: [embed], components: [row] });
    } else {
      message.author.send({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    }
  }
});

client.on('interactionCreate', async (interaction) => {
    if(!interaction.isButton()) return;
  if (interaction.customId == "spin_button") {
    if (interaction.member.roles.cache.some((role) => role.name === 'Member') || interaction.member.roles.cache.some(r => r.id == perms)) {
      const prizes = [
        { name: '<@&996368935211503616>', chance: 0.5 },
        { name: '<@&996382617198927873>', chance: 0.5 },
        { name: '<@&997259592176246835>', chance: 0.5 },
        { name: '<@&997260131962204262>', chance: 0.5 },
          
        { name: '120k', chance: 0.1 },
        { name: '150k', chance: 0.1 },
        { name: 'حظ اوفر', chance: 0.5 },
        { name: 'منشن هير', chance: 0.3 },
        { name: 'منشن ايفري', chance: 0.1 },
        
      ];
      const totalChance = prizes.reduce((acc, prize) => acc + prize.chance, 0);
      const random = Math.random() * totalChance;
      let selectedPrize = null;
      let cumulativeChance = 0;

      for (const prize of prizes) {
        cumulativeChance += prize.chance;
        if (random < cumulativeChance) {
          selectedPrize = prize;
          break;
        }
      }

      // Call the logWheelSpin function to log information
      logWheelSpin(interaction.user.id, interaction.member.user.id, selectedPrize.name, 'Spin');

      // Defer the reply before sending the interaction
      await interaction.deferReply();

      // Mention the user who clicked the button in the follow-up message
      if (selectedPrize) {
        await interaction.followUp(`** ${emj .Give} مبروك ! ${interaction.user} لقد ربحت : ${selectedPrize.name}**`);
      } else {
        await interaction.followUp(`**لف مرة أخري ${interaction.user} مجانا **`);
      }

      // Delete the original message
      await interaction.message.delete();
    } else {
      await interaction.reply({ content: `** لا يمكنك إستخام هذا الزر .**`, ephemeral: true });
    }
  }
});

// إعداد زر الـ VIP Spin
        
client.on('messageCreate', (message) => {
  if (message.content === '$vipspin') {
    if (message.member.roles.cache.some((role) => role.name === 'Spin') || message.member.roles.cache.some(r => r.id == perms)) {
      const button = new MessageButton()
        .setStyle('SUCCESS')
        .setLabel('VIP Spin')
        .setCustomId('spin_button1');
      const row = new MessageActionRow().addComponents(button);
      const embed = new MessageEmbed()
        .setColor('15FFAF')
        .setTitle(`**  Na7la \`S\` VIP Wheel Of Luck・عجلة الحظ**`)
        .setDescription('> ** إضغط على الزر VIP Spin لتدوير العجلة .**');
      message.channel.send({ embeds: [embed], components: [row] });
    } else {
      message.author.send({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    } 
  }
});

// استجابة الزر الـ VIP Spin
client.on('interactionCreate', async (interaction) => {
  if(!interaction.isButton()) return;
  if (interaction.customId == "spin_button1") {
    if (interaction.member.roles.cache.some((role) => role.name === 'Member') || interaction.member.roles.cache.some(r => r.id == perms)) {
      const prizes = [
        { name: '<@&996365835465674792>', chance: 0.3 },
        { name: '<@&1173940676619157536>', chance: 0.1 },
      
        { name: 'حظ اوفر', chance: 0.5 },
        { name: 'لف مرة اخرى', chance: 0.5 },
        { name: '500k', chance: 0.1 },
        { name: 'اعلان سلفر', chance: 0.3 },
        { name: 'اعلان بلاتنيوم', chance: 0.1 },
        { name: 'طلب بروم اونرز', chance: 0.1 },
      ];
      const totalChance = prizes.reduce((acc, prize) => acc + prize.chance, 0);
      const random = Math.random() * totalChance;
      let selectedPrize = null;
      let cumulativeChance = 0;

      for (const prize of prizes) {
        cumulativeChance += prize.chance;
        if (random < cumulativeChance) {
          selectedPrize = prize;
          break;
        }
      }

      // دعوة وظيفة اللوج لتسجيل المعلومات
      logWheelSpin(interaction.user.id, interaction.member.user.id, selectedPrize.name, 'VIP Spin');

      await interaction.deferReply();

      if (selectedPrize) {
        await interaction.followUp(`** ${emj.Give} مبروك ! لقد ربحت : ${selectedPrize.name}**`);
      } else {
        await interaction.followUp('** لف مرة أخري مجانا**');
      }

      // Delete the original message
      await interaction.message.delete();
    } else {
      await interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });
    }
  }
});

/// الطلبات



      

      
      
   

    

    

  
      
    
 


 		



client.on("ready" , () => {
  const guild1 = "996135517320134776"
  const guild = client.guilds.cache.get(guild1)
  var commands
    if(guild) {
      commands = guild.commands
    } else {
      commands = client.application.commands
    }
      commands.create({
        name:"embed",
        description:"Make Your Own Embed !",
        options:[
          {
            name:`title`,
            description:"Specfiy The Title For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:true
          },
          {
            name:`description`,
            description:"Specfiy The Description For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:true
          },
          {
            name:`color`,
            description:"Specfiy The Color In Large letters For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:true
          },
          {
            name:`image`,
            description:"Specfiy The Link Of Image For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:false
          },
          {
            name:`thumbnail`,
            description:"Specfiy The Link Of Thumbnail For The Embed",
            type:Discord.Constants.ApplicationCommandOptionTypes.STRING,
            required:false
          }
        ]
    })
  commands.create({
         name:"abdo",
        description:"تبي تشوف سلطان ؟!"
  })
      commands.create({
         name:"set-embed",
        description:"set embed channel to send",
          options: [{
            name: "channel",
            description:"Specfiy The Channel For The Embed",
            type: 7,
            channel_types: [0],
            required:true
          }]
  })
    commands.create({
         name:"set-line",
        description:"set line of channel to send",
          options: [{
            name: "channel",
            description:"Specfiy The Channel for auto line",
            type: 7,
            channel_types: [0],
            required:true
          }]
  })
    commands.create({
         name:"set-emoji",
        	description:"set emoji of channel to react",
          options: [{
            name: "emoji",
            description:"Specfiy The emoji for auto react",
            type: 3,
            required:true
          },
          {
            name: "channel",
            description:"Specfiy The Channel for auto react",
            type: 7,
            channel_types: [0],
            required:true
            }]
  })
  });


  client.on("interactionCreate" , interaction => {
    if(!interaction.isCommand()) return;
    if(interaction.commandName == "$embed") {
      let title = interaction.options.getString('title');
      let description = interaction.options.getString('description');
      let color = interaction.options.getString('color');
      let image = interaction.options.getString('image');
      let thumb = interaction.options.getString('thumbnail')
      let embed = new Discord.MessageEmbed()
      .setTitle(`${title}`)
      .setColor(`${color}`)
      .setDescription(`${description}`)
      if(image) {
        embed.setImage(`${image}`)
      }
      if(thumb) {
        embed.setThumbnail(`${thumb}`)
      }
      interaction.reply({content : `**تم انشاء الايمبيد !**` , ephemeral:true})
      interaction.channel.send({embeds:[embed]}).catch(err => {})
    }
  });

  client.on("interactionCreate" , interaction => {
   if(!interaction.isCommand()) return;
    if(interaction.commandName == "abdo") {
      let embed = new Discord.MessageEmbed()
      .setTitle("**😱**")
      .setDescription("**لا تستطيع مقاومة الجمال**")
      .setImage("https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/FullMoon2010.jpg/1200px-FullMoon2010.jpg")
      .setColor("BLACK")
      interaction.reply({embeds:[embed]})
    }
  });

  client.on("interactionCreate" , interaction => {
      if(!interaction.isCommand()) return;
    if(interaction.commandName == "set-embed") {
        let channel = interaction.options.getChannel("channel");
    	let data = db.get(`embed_${interaction.guild.id}`)
         if(data && data.includes(channel.id)){
            let index = data.indexOf(channel.id)
            data.splice(index, 1)
            db.set(`embed_${interaction.guild.id}`, data)
            return interaction.reply(`تم ازالة الامبد تلقائي من الشات ${channel}`)
}
      if(!interaction.member.permissions.has("ADMINISTRATOR")) return interaction.reply({content: "روح نام حبيبي", ephemeral: true});
        db.push(`embed_${interaction.guild.id}`, channel.id);
      interaction.reply({content: `تم الاعداد بنجاح`});
    }
  });

client.on("messageCreate" , message => {
if(message.author.bot) return;
   if(!db.has(`embed_${message.guild.id}`)) return;
    let data = db.get(`embed_${message.guild.id}`)
if(data.includes(message.channel.id)) {
    message.delete()
let embed = new Discord.MessageEmbed()
      .setTitle("**Embed Created**")
	  .setAuthor(message.member.user.username, message.member.user.avatarURL({dynamic: true}))
      .setDescription(`${message.content}`)
      .setColor(`${colorE}`)
	  .setTimestamp()
	  .setFooter(message.guild.name, message.guild.iconURL({dynamic: true}))
	if(message.attachments.size > 0){
        embed.setImage(`${message.attachments.first()?.url}`)
	}
    message.channel.send({embeds: [embed]})
}
})

  client.on("interactionCreate" , interaction => {
      if(!interaction.isCommand()) return;
    if(interaction.commandName == "set-line") {
        let channel = interaction.options.getChannel("channel");
    	let data = db.get(`line_${interaction.guild.id}`)
        if(data && data.includes(channel.id)){
            let index = data.indexOf(channel.id)
            data.splice(index, 1)
            db.set(`line_${interaction.guild.id}`, data)
            return interaction.reply(`تم ازالة خط تلقائي من الشات ${channel}`)
}
      if(!interaction.member.permissions.has("ADMINISTRATOR")) return interaction.reply({content: "روح نام حبيبي", ephemeral: true});
        db.push(`line_${interaction.guild.id}`, channel.id);
      interaction.reply({content: `تم اضافة خط تلقائي الى الشات ${channel}`});
    }
  });

client.on("messageCreate" , message => {
if(message.author.bot) return;
   if(!db.has(`line_${message.guild.id}`)) return;
    let data = db.get(`line_${message.guild.id}`)
if(data.includes(message.channel.id)) {
     message.channel.send(`${lineLink}`)
    
}
})

client.on("interactionCreate" , interaction => {
      if(!interaction.isCommand()) return;
    if(interaction.commandName == "set-emoji") {
        let channel = interaction.options.getChannel("channel");
        let emoji = interaction.options.getString("emoji");
    	let data = db.get(`emoji_${channel.id}`)
         /*if(data && data..includes(emoji)){
            let index = data.indexOf(emoji)
            data.splice(index, 1)
            db.set(`emoji_${interaction.guild.id}`, data)
            return interaction.reply(`تم ازالة الايموجي تلقائي من الشات ${channel}`)
}*/
      if(!interaction.member.permissions.has("ADMINISTRATOR")) return interaction.reply({content: "روح نام حبيبي", ephemeral: true});
        db.push(`emoji_${channel.id}`, emoji);
      interaction.reply({content: `تم اضافة اوتو رياكشن الى الشات ${channel}`});
    }
  });

client.on("messageCreate" , message => {
if(message.author.bot) return;
   if(!db.has(`emoji_${message.channel.id}`)) return;
    let data = db.get(`emoji_${message.channel.id}`)
if(data && data.length > 0) {
    data.forEach(d => {
         message.react(d)
    })
}
})

client.on("messageCreate" , message => {
if(message.author.bot) return;
if(message.channel.name.startsWith("〢↯・")) {
  message.channel.send(`${lineLink}`)
}
})


//////////

//////////



///////////////

client.on('messageCreate', async message => {
if (message.content.startsWith(prefix + 'تقيم') || message.content.startsWith(prefix + 'تقييم')) {
if(message.content.startsWith(prefix + "تقيمات")) return false;
if(message.content.startsWith(prefix + "تقييمات")) return false;
const now = new Date();
const args = message.content.split(" ")
const user = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
if(!user) return message.reply("**منشن الإداري أولاً !**")
const titlefeed = message.content.split(" ").slice(2).join(" ")
if (!titlefeed) return message.reply("**يرجى وضع محتوى التقييم أولاً .**")
if(user.id === message.member.id) return message.reply("**لا تستطيع تقييم نفسك !**")
if(!user.roles.cache.some(r=>r.id == 1241129866515185668)) return message.reply("**هذا الشخص ليس اداري !**")
const feedbackData = db.get(`feedback_${user.id}`);
if(feedbackData) {
for (const entry of feedbackData) {
  const memberId = entry.member;
  if(memberId == message.member.id) return message.reply("**لا يمكنك تقييم الشخص اكثر من مرة !**")}}
const FeedBackLog = await message.client.channels.fetch("1128638873166155846");

 let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
      .setLabel("⭐ 1")
      .setCustomId("s1")
      .setStyle("SECONDARY"),
            new Discord.MessageButton()
      .setLabel("⭐ 2")
      .setCustomId("s2")
      .setStyle("SECONDARY"),
            new Discord.MessageButton()
      .setLabel("⭐ 3")
      .setCustomId("s3")
      .setStyle("SECONDARY"),
            new Discord.MessageButton()
      .setLabel("⭐ 4")
      .setCustomId("s4")
      .setStyle("SECONDARY"),
            new Discord.MessageButton()
      .setLabel("⭐ 5")
      .setCustomId("s5")
      .setStyle("SECONDARY"),
    )

message.reply({content:`** الاداري : ${user}**\n** تقييمك : ${titlefeed}**\n** يرجى اختيار عدد النجوم التي تعطيها للاداري عبر الازرار في الاسفل**` , components:[row]}).then(m => {

db.set(`temp_${m.id}` , message.member.id)
db.set(`tempuser_${message.member.id}` , user.id)
db.set(`tempfeedback_${message.member.id}` , titlefeed)
})

}
});

client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {
  if(interaction.customId == "s1") {
  if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})
  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 1**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:1 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)


  }
  }
});
client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {

    if(interaction.customId == "s2") {
        if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})

  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 2**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:2 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)


  }
    }
});
client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {

    if(interaction.customId == "s3") {
       if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})

  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 3**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:3 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)



  }
    }
});
client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {

    if(interaction.customId == "s4") {
        if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})

  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 4**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:4 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)

      }
}

});
  client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {

    if(interaction.customId == "s5") {
       if(!db.has(`tempuser_${interaction.member.id}`)) return interaction.reply({content:"**لا يمكنك استخدام هذا الامر !**" , ephemeral:true})
  let titlefeed = db.get(`tempfeedback_${interaction.member.id}`)
  let user = interaction.guild.members.cache.find(r=>r.id == db.get(`tempuser_${interaction.member.id}`))
           interaction.message.edit({content:`**تم تقييم ${user} بعدد نجوم 5**` , components:[]})
    db.push(`feedback_${user.id}` , {member:interaction.member.id , stars:5 , title:titlefeed})

    db.delete(`temp_${interaction.message.id}`)
    db.delete(`tempuser_${interaction.member.id}`)
    db.delete(`tempfeedback_${interaction.member.id}`)


  }

  }
})

client.on("messageCreate" , async message => {
if(message.content.startsWith(prefix + "تقييمات")) {
    const args = message.content.split(" ")
    const member = message.mentions.members.first() ||     message.guild.members.cache.find(r=>r.id == args[1])
    if(!member) return message.reply("**منشن الإداري أولاً !**")
    if(!db.has(`feedback_${member.id}`)) return message.reply("**هذا الشخص ليس لديه تقييمات !**")
    if(!member.roles.cache.some(r=>r.id == "1241129866515185668")) return message.reply("**هذا الشخص ليس اداري !**")
    const feedbackData = db.get(`feedback_${member.id}`); 
let usersData = [];
    for (const entry of feedbackData) {
      var stars = entry.stars;
      var title = entry.title;
      var memberId = entry.member;
      var star1 = "⭐";
      var star2 = "⭐⭐";
      var star3 = "⭐⭐⭐";
      var star4 = "⭐⭐⭐⭐";
      var star5 = "⭐⭐⭐⭐⭐";
      usersData.push({ user: memberId, stars, title });
    }
    usersData.sort((a, b) => b.stars - a.stars);
    const embed = new MessageEmbed()
      .setColor(`${colorE}`)
      .setDescription(`**${member} Reviews :**`);
    const topUsers = usersData.slice(0, 20);
    topUsers.forEach((user, index) => {
      var starsString = "";
      if (user.stars == 1) {
        starsString = star1;
      } else if (user.stars == 2) {
        starsString = star2;
      } else if (user.stars == 3) {
        starsString = star3;
      } else if (user.stars == 4) {
        starsString = star4;
      } else if (user.stars == 5) {
        starsString = star5;
      }
      embed.addField(`**#${index + 1} | **`, `**المقيم : <@${user.user}>\n- عدد النجوم : ${starsString}\n- التقييم : ${user.title}**\n`);});
message.reply({embeds:[embed]})}});

///////////////

//////////////





let sug = ["1241129869417644092"]; 
client.on("messageCreate",async (message) => {
        let args = message.content.split(",");
  if (message.author.bot) return;
if(sug.includes(message.channel.id)) {
    message.delete()
    const embed = new Discord.MessageEmbed()
.setAuthor({name: message.author.tag,iconURL: 
 message.author.avatarURL({dynamic:true})})
.setColor(`#15FFAF`)
.setThumbnail(message.guild.iconURL({ dynamic: false }))
.setDescription(`> **${args}**`)
.setTimestamp()
let attachm = message.attachments.first()
if (attachm) {
    embed.setImage(attachm.proxyURL)
}  
message.channel.send({ embeds: [embed] }).then(msg => {
 msg.react('<:emoji_75:1242783380437991424>').then(() => {   
  
 msg.react('<:emoji_76:1242783398997524521>')
})
message.channel.send(lineLink)
})
.catch(console.error) 
}
});  





///////////////
client.on('messageCreate', async message => {
if (message.content.startsWith('$رول') && message.member.roles.cache.has(RolesRole) || message.content.startsWith('$role') && message.member.roles.cache.has(RolesRole)) {
 if(message.content.startsWith(prefix + "رولات")) return false;
  const args = message.content.split(' ');
    const user = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
    if (!user) return message.reply("**منشن الشخص أولاً أو ضع الإيدي !**")
    if(!args) return message.reply("**منشن الشخص أولاً أو ضع الإيدي !**")
    
    let row = new MessageActionRow()
    .addComponents(
				 new MessageSelectMenu()
        .setCustomId('menu-select1')
          .setPlaceholder("Rare Roles | رتب نادرة")
       	  .addOptions([
						{
					label: 'Everest S',
              	    value: '1241129866481635477',
						},
						{
					label: 'Alone S',
					value: '1241129866481635475',
						},
              			{
              		label: 'Super S',
              		value: '1241129866481635476',
              			}
					]))
     
  
      let row2 = new MessageActionRow()
    .addComponents(
           new MessageSelectMenu()
          .setPlaceholder("Roles | رولات شوب")
          .setCustomId('menu-select2')
          .setMaxValues(5)
          .addOptions(
             [{  
              label: 'Myithic S',
              value: '1241129866481635474',
            },
            {
              label: 'Private S',
              value: '1318611389102948463',
            },
            {
              label: 'Special S',
              value: '1241129866481635473',
            },
            {
              label: 'Great S',
              value: '1241129866481635472',
            },
            {
              label: 'Demon S',
              value: '1241129866481635471',
            },
            {
              label: 'Designer S',
              value: '1241129866481635470',
                },
              {
                label: 'Delevoper S',
                value: '1241129866481635469',
            },
            { label: 'Sel $',
             value: '1241129866469048369',
             }]))
          
          let row3 = new MessageActionRow()
    .addComponents(
           new MessageSelectMenu()
          .setPlaceholder("Warns | تحذيرات")
          .setCustomId('menu-select3')
          .setMaxValues(2)
          .addOptions(
            [{
              label: 'Wran 1',
              value: '1241129866469048360',
            },
            {
              label: 'warn 2',
              value: '1241129866422653028',
            },
            {
              label: 'warn 3',
              value: '1241129866422653027',
            }])
       )
          let row4 = new MessageActionRow()
    .addComponents(
      new MessageButton()
		.setCustomId('cancelRole')
		.setLabel('الغاء عملية')
		.setStyle('DANGER')
    )
    let m = await message.reply({ content: `** يرجى تحديد نوع الرتبة :**`, components: [row, row2, row3, row4] })
  db.set(`giverole_${m.id}` , user.id)}});
/*
client.on("interactionCreate" , interaction => {
  if(interaction.customId == "menu-select") {
      if (interaction.values[0] === 'specialR') {
          if (!interaction.member.roles.cache.has(RolesRole)) return;
let row1 = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setPlaceholder("Select Role ..")
          .setCustomId('menu-select1')
          .setMaxValues(5)
          .addOptions([
               {
              label: '🜲 || NA7LA S',
              value: '1211710662481543268',
              },
              {
              label: '🜲 || N7 SUPERHERO',
              value: '1173940676619157536'
              },
              {
               
              label: '🜲 || N7',
              value: '996365835465674792'
              }
          ]))
        interaction.message.edit({ content: `**${emj.Dot} يرجى تحديد الرتبة :**`, components: [row1] })
interaction.deferUpdate() 
      }

        if (interaction.values[0] === 'sellR') {
if (!interaction.member.roles.cache.has(RolesRole)) return;
let row1 = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setPlaceholder("Select Role ..")
          .setCustomId('menu-select2')
          .setMaxValues(5)
          .addOptions([
             {  
              label: '🜲 || BEE',
              value: '996368935211503616'
            },
            {
              label: '🜲 || HONEY',
              value: '996382617198927873'
            },
            {
              label: '🜲 || A ROSE',
              value: '996382760564445184'
            },
            {
              label: '🜲 || Flower',
              value: '996382954521624666'
            },
            {
              label: '🜲 || Designer S',
              value: '997259592176246835'
            },
            {
              label: '🜲 || Developer S',
              value: '997260131962204262'
            }]) )
        interaction.message.edit({ content: `**${emj.Dot} يرجى تحديد الرتبة :**`, components: [row1] })
        interaction.deferUpdate() 
  }

if (interaction.values[0] === 'otherR') {
if (interaction.member.roles.cache.has(RolesRole)) {
let row1 = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setPlaceholder("Select Role ..")
          .setCustomId('menu-select3')
          .setMaxValues(2)
          .addOptions([
            {
              label: '🜲 || Trust S',
              value: '1028594799961444472'
            },
            {
              label: 'warn 100%',
              value: '996693069183332352'
            },
            {
              label: 'warn 50%',
              value: '996693208111251477'
            }, ]) )
        interaction.message.edit({ content: `**${emj.Dot} يرجى تحديد الرتبة :**`, components: [row1] })
  interaction.deferUpdate() }}}});
*/
client.on("interactionCreate" , async interaction => {
  if(interaction.isSelectMenu()) {
    if(interaction.customId == "menu-select1" || interaction.customId == "menu-select2" || interaction.customId == "menu-select3") {
      if (interaction.member.roles.cache.has(RolesRole)) {
      let rolesAdded = [];
      let rolesRemoved = [];
      let u = db.get(`giverole_${interaction.message.id}`)
      let member = interaction.guild.members.cache.find(r=>r.id == u)
      let roles = interaction.values;
      for (const r of roles) {
        var s;
        const role = interaction.guild.roles.cache.find(ro=>ro.id == r)
        if(role) {
    if(member.roles.cache.some(ro=>ro.id == r)) {
          await member.roles.remove([role])
          rolesRemoved.push(role.name.replace(/\|\|/g, '')); } else {
          await member.roles.add([role])
          rolesAdded.push(role.name.replace(/\|\|/g, '')); }}}
      let message = `** تم تحديث رتب ${member}**\n`;
    if (rolesAdded.length > 0) {
      message += `> ** الرتب التي تم اضافتها : ${rolesAdded.join(' , ')}**\n`; }
    if (rolesRemoved.length > 0) {
      message += `> ** الرتب التي تم ازالتها : ${rolesRemoved.join(' , ')}**\n`; }
 interaction.message.edit({content:`${message}` , components:[]})
      interaction.deferUpdate()
        db.delete(`giverole_${interaction.message.id}`) }} 
  }});

client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {
    if(interaction.customId == "cancelRole" && interaction.member.roles.cache.has(RolesRole)) {
      interaction.message.edit({ content:`** لقد تم الغاء العملية **`, components:[]})
    }
  }
});

///////////////
client.on("messageCreate", async message => {
if(message.author.bot || !message.guild) return;
    if (message.content.startsWith(prefix + 'embed') || (message.content.startsWith(prefix + 'e'))) {
      if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
if(!message.guild.me.permissions.has('ADMINISTRATOR')) {
  return message.reply("**للأسف انا لا امتلك صلاحية `ADMINISTRATOR`**");
}
      await message.channel.sendTyping();
let args = message.content.split(' ').slice(1).join(' ')
if (!args) return message.reply('**يرجى وضع النص أولاً .**')
message.delete();
const embed = new Discord.MessageEmbed()
    .setDescription(`${args}`) 
   .setColor(`${colorE}`) 
let attach = message.attachments.first();
if (attach) {
    embed.setImage(attach.proxyURL) }
message.channel.send({embeds: [embed]}); }})

///////////////

let manshor;
let member;

client.on("messageCreate", message => {
  if (message.content.startsWith(prefix + "منشور")) {
if (message.member.roles.cache.has('1241129866708127834') || message.member.permissions.has("ADMINISTRATOR")) {

if(message.content.startsWith(prefix + "منشورات")) return false;

member = message.mentions.members.first()
      if (!member) return message.reply(`**${emj.False} يرجى منشن صاحب المنشور أولاً !**`)
manshor = message.content.split(" ").slice(2).join(" ");
  if (!manshor) return message.reply(`**${emj.False} يرجى وضع المنشور أولاً !**`)

let embed = new Discord.MessageEmbed()
      .setTitle(`**${emj.Lift} إختر نوع المنشن :**`)
      .setDescription(`**${emj.Dot} يرجى إختيار نوع المشنن المناسب : \`here\` أو \`everyone\`\n${emj.Dot} المنشور :\n\`${manshor}\`**`)
      .setColor(`${colorE}`)
  let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("here")
        .setCustomId("menthere")
        .setStyle("SECONDARY")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("everyone")
        .setCustomId("menteve")
        .setStyle("SECONDARY")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("no mention")
        .setCustomId("nomen")
        .setStyle("SECONDARY")
    )

  message.reply({ embeds: [embed], components: [row] })
            }}});

client.on("interactionCreate", async interaction => {
  if (!interaction.isButton()) return;

  if (interaction.customId === "menthere") {
    if (interaction.member.roles.cache.some((role) => role.id === "1241129866708127834")) {
    const message = await interaction.channel.messages.fetch(interaction.message.id);

    const heremanshor = `${manshor}\n@here`

let embed1 = new Discord.MessageEmbed()
      .setTitle(`** هل انت متأكد من إرسال المنشور ؟**`)
  .setDescription(`** يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n المنشور :\n\`${heremanshor}\n\nتواصل مع : ${member}\`**`)
      .setColor(`${colorE}`)
  let row1 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("completeid")
        .setStyle("SUCCESS")
    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("cancelid")
        .setStyle("DANGER")
    )
      interaction.deferUpdate()

    message.edit({ embeds: [embed1], components: [row1] });     } else {
      interaction.reply({ content: `**${emj.False} لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });    } } else if (interaction.customId === "menteve") {
    if (interaction.member.roles.cache.some((role) => role.id === "1241129866708127834")) {
    const message = await interaction.channel.messages.fetch(interaction.message.id); 
const evemanshor = `${manshor}\n@everyone`
let embed2 = new Discord.MessageEmbed()
      .setTitle(`**$ هل انت متأكد من إرسال المنشور ؟**`)
  .setDescription(`** يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n المنشور :\n\`${evemanshor}\n\nتواصل مع : ${member}\`**`)
      .setColor("EA3648")
  let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("completeid2")
        .setStyle("SUCCESS")   )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("cancelid")
        .setStyle("DANGER")   )
    interaction.deferUpdate()
    message.edit({ embeds: [embed2], components: [row2] });     } else {
      interaction.reply({ content: `**${emj.False}
 لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });   }  } else if (interaction.customId === "nomen") {
    if (interaction.member.roles.cache.some((role) => role.id === "1241129866708127834")) {
    const message = await interaction.channel.messages.fetch(interaction.message.id); 
const nomenmanshor = `${manshor}`
let embed2 = new Discord.MessageEmbed()
      .setTitle(`** هل انت متأكد من إرسال المنشور ؟**`)
  .setDescription(`** يرجى الإستجابة مع الأزرار بـ \`إرسال\` أو \`إلغاء\` ..\n المنشور :\n\`${nomenmanshor}\n\nتواصل مع : ${member}\`**`)
      .setColor(`${colorE}`)
  let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("إرسال")
        .setCustomId("completeid3")
        .setStyle("SUCCESS")    )
  .addComponents(
   new Discord.MessageButton()
        .setLabel("إلغاء")
        .setCustomId("cancelid")
        .setStyle("DANGER")    )
    interaction.deferUpdate()
    message.edit({ embeds: [embed2], components: [row2] }); } else {
      interaction.reply({ content: `**${emj.False} لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "cancelid") {
if (interaction.member.roles.cache.some((role) => role.id === "1241129866708127834")) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
let embed3 = new Discord.MessageEmbed()
  .setColor(`EA3648`)
  .setDescription(`** تم إلغاء إرسال هذا المنشور .
 بواسطة :
${interaction.member}
**`)
interaction.deferUpdate()
message.edit({ embeds: [embed3], components: [] }); } else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "completeid") {
if (interaction.member.roles.cache.some(r=>r.id == "1241129866708127834")) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const ManshoratChannel = client.channels.cache.find(channel => channel.name === manshoratRoom);
const ManshoratLog = client.channels.cache.get('1241129867848716407');
  const memhere = `${member}`
  const manshorhere = `${manshor}\n\nتواصل مع : ${memhere}\n@here`
let embed4 = new Discord.MessageEmbed()
  .setColor(`${colorE}`)
  .setDescription(`** تم إرسال هذا المنشور إلى ${ManshoratChannel}
 بواسطة :
${interaction.member}
**`)
message.edit({ embeds: [embed4], components: [] });
interaction.deferUpdate()
await ManshoratChannel.send(`${manshorhere}`)

  await ManshoratChannel.send(`${lineLink}`)

//await ManshoratChannel.send(`${lineLink}`)
await ManshoratLog.send(`** المنشور :\n\`${manshor}\`\n المنشن :\nhere\n المشرف المسؤول :\n${interaction.member}\n صاحب المنشور :\n${memhere}\n تاريخ المنشور : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await ManshoratLog.send(`${lineLink}`) } else {
      interaction.reply({ content: `**${emj.False}
 لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "completeid2") {
if (interaction.member.roles.cache.some((role) => role.id === "1241129866708127834") ) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const ManshoratChannel2 = client.channels.cache.find(channel => channel.name === manshoratRoom);
  const ManshoratLog2 = interaction.guild.channels.cache.get('1241129867848716407');

  const memeve = `${member}`
  const manshoreve = `${manshor}\n\nتواصل مع : ${memeve}\n@everyone`

let embed5 = new Discord.MessageEmbed()
  .setColor(`${colorE}`)
  .setDescription(`**${emj.Dot} تم إرسال هذا المنشور إلى ${ManshoratChannel2}
${emj.Dot} بواسطة :
${interaction.member}
**`)
message.edit({ embeds: [embed5], components: [] });
interaction.deferUpdate()
await ManshoratChannel2.send(`${manshoreve}`);

  await ManshoratChannel2.send(`${lineLink}`)

await ManshoratLog2.send(`** المنشور :\n\`${manshor}\`\n المنشن :\neveryone\n المشرف المسؤول :\n${interaction.member}\n صاحب المنشور :\n${memeve}\n تاريخ المنشور : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await ManshoratLog2.send(`${lineLink}`) } else {
      interaction.reply({ content: `** لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

client.on("interactionCreate" , async interaction => {
if(interaction.customId == "completeid3") {
if (interaction.member.roles.cache.some(r=>r.id == "1241129867848716407")) {
const message = await interaction.channel.messages.fetch(interaction.message.id);
const now = new Date();
  const ManshoratChannel3 = client.channels.cache.find(channel => channel.name === manshoratRoom);
const ManshoratLog3 = client.channels.cache.get('1241129867848716407');
  const nomen = `${member}`
  const manshorno = `${manshor}\n\nتواصل مع : ${nomen}`
let embed4 = new Discord.MessageEmbed()
  .setColor(`${colorE}`)
  .setDescription(`**${emj.Dot} تم إرسال هذا المنشور إلى ${ManshoratChannel3}
${emj.Dot} بواسطة :
${interaction.member}
**`)
message.edit({ embeds: [embed4], components: [] });
interaction.deferUpdate()

await ManshoratChannel3.send(`${manshorno}`)

await ManshoratChannel3.send(`${lineLink}`)

await ManshoratLog3.send(`** المنشور :\n\`${manshor}\`\n المنشن :\nno mention\n المشرف المسؤول :\n${interaction.member}\n صاحب المنشور :\n${nomen}\n تاريخ المنشور : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
  await ManshoratLog3.send(`${lineLink}`) } else {
      interaction.reply({ content: `**
 لا يمكنك إستخدام هذا الزر .**`, ephemeral: true });}}});

/////////////// 
client.on("messageCreate", async message => {
  let args = message.content
    .split(" ")
    .slice(1)
    .join(" ");
  if (args.endsWith("b")) {
    args = args.replace(/b/gi, "") * 1000000000;
  } else if (args.endsWith("m")) {
    args = args.replace(/m/gi, "") * 1000000;
  } else if (args.endsWith("k")) {
    args = args.replace(/k/gi, "") * 1000;
  }

  if (message.author.bot) return;
  if (!message.guild) return;
  if (
    message.content.startsWith(prefix + "/#sjnskwndnsk") ||
    message.content.startsWith("ضريبة") ||
    message.content.startsWith("ضريبه") ||
    message.content.startsWith("$tax") ||
    message.content.startsWith("$ضريبه") ||
    message.content.startsWith("$ضريبة")
  ) {
    let args2 = parseInt(args);
    let tax = Math.floor(args2 * (20 / 19) + 1);
    let tax2 = Math.floor(args2 * (20 / 19) + 1 - args2);
    let tax3 = Math.floor(tax2 * (20 / 19) + 1);
    let tax4 = Math.floor(tax2 + tax3 + args2);
    let embed1 = new Discord.MessageEmbed()
      .setTitle(`**${emj.False} | Error \`:\`**`)
      .setDescription("**يرجى وضع المبلغ المراد حساب ضريبته .**")
      .setThumbnail(message.author.avatarURL({ dynamic: true }))
      .setColor(`${colorE}`)
      .setTimestamp()
      .setFooter("# ~ Everest S.");
    if (!args2) return message.channel.send({ embeds: [embed1] });
    let embed2 = new Discord.MessageEmbed()
      .setTitle(`**${emj.False} | Error \`:\`**`)
      .setDescription("**يرجى وضع المبلغ المراد حساب ضريبته .**")
      .setThumbnail(message.author.avatarURL({ dynamic: true }))
      .setColor(`${colorE}`)
      .setTimestamp()
      .setFooter("# ~ Everest S.");
    if (isNaN(args2)) return message.channel.send({ embeds: [embed2] });
    if (args2 < 1) return message.channel.send(3);
    let embed4 = new Discord.MessageEmbed()
      .setTitle(`** | Tax \`:\`**`)
      .setDescription(`** The amount to be paid \`:\` 1**`)
      .setThumbnail(message.author.avatarURL({ dynamic: true }))
      .setColor(`${colorE}`)
      .setTimestamp()
      .setFooter("# ~ Everest S.");
    if (args2 == 1) return message.channel.send({ embeds: [embed4] });
    let taxmsg = new Discord.MessageEmbed()
      .setTitle(`** | Tax \`:\`**`)
      .setColor(`${colorE}`)
      .setDescription(`** The amount to be paid \`:\` ${tax}\n Mediator tax \`:\` \`الوسيط\` ${tax4}**`)
      .setFooter("# ~ Everest S.")
      .setThumbnail(message.author.avatarURL({ dynamic: true }))
      .setTimestamp();
if (args2 >= 100000000) {
      taxmsg.setImage(`https://i8.ae/OlCHy`); 
    }
    message.channel.send({ embeds: [taxmsg] }); 
  }});

///////////////
client.on("messageCreate", message => {
  if (message.content.startsWith(prefix + "staff-role")) {
          if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
      let r = message.content.split(" ").slice(1).join(" ")
      let role = message.guild.roles.cache.find(r => r.id == r)
      if (!r) {
        if (!role) {
          if (isNaN(r)) {
            message.reply("> **Error : Please put the rank ID**") 
          }
        }
      }
      db.set(`role_${message.guild.id}`, r)
      message.reply(`> **تم تعيين رتبة <@&${r}> مستخدم لـ زر الكلايم .**`) 

  }
});

client.on("channelCreate", channel => {
  if (channel.name.startsWith("ticket-")) {
    let embed = new Discord.MessageEmbed()
      .setDescription("**إضغط على الزر لتصبح مسؤول التذكرة**")
      .setColor(`${colorE}`)
    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("Claim")
        .setCustomId("claim")
        .setStyle("SUCCESS")
        .setEmoji("<:51:1242766258492145714>")
    )
    setTimeout(() => {
      channel.send({ embeds: [embed], components: [row] }).then(m => db.set(`message_${channel.id}`, m.id)) }, 1000);
  }
    
});

client.on("interactionCreate", interaction => {
  if (interaction.isButton()) {
    let message = db.get(`message_${interaction.channel.id}`)
    let msg = interaction.channel.messages.cache.find(r => r.id == message)
    let role = interaction.guild.roles.cache.find(r => r.id == 996364077817405531)
      if (interaction.customId == "claim") {
        if(db.has(`inactive_${interaction.member.id}`)) return interaction.reply({content:`**عليك تسجيل نفسك بالاول : <#1168669813346930779>**` , ephemeral:true})
        if (!interaction.member.roles.cache.some(r => r.id == 1241129866515185669)) return interaction.reply({ content: "**يمكن للإدارة فقط إستخدام هذا الزر .**", ephemeral: true })
        let embed = new Discord.MessageEmbed()
          .setDescription(`**مسؤول التذكرة : ${interaction.member} .**`)
          .setColor(`${colorE}`)
        let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("Unclaim")
        .setCustomId("unclaim")
        .setEmoji("<:50:1242766050144292864>")
        .setStyle("DANGER") )
        interaction.channel.permissionOverwrites.edit(role, {
          SEND_MESSAGES: false, })
        interaction.channel.permissionOverwrites.edit(interaction.member, {
          SEND_MESSAGES: true, })
        interaction.channel.setName(`ticket-${interaction.member.user.username}`)
      db.set(`claimed_${interaction.channel.id}_${interaction.member.id}`, interaction.member.id)
        db.set(`user_${interaction.channel.id}`, interaction.member.id)
        db.add(`weekuser_${interaction.member.id}`, 1)
        db.add(`alluser_${interaction.member.id}`, 1)
        interaction.reply({ embeds: [new Discord.MessageEmbed().setDescription(`**تم إستلام التذكرة من قبل : ${interaction.member} .**`).setColor(`${colorE}`)] })
        msg.edit({ embeds: [embed], components: [row] })      }
      if (interaction.customId == "unclaim") {
        if (!interaction.member.roles.cache.some(r => r.id == db.get(`role_${interaction.guild.id}`))) return interaction.reply({ content: "**يمكن للإدارة فقط إستخدام هذا الزر .**", ephemeral: true })
        if (!db.has(`claimed_${interaction.channel.id}_${interaction.member.id}`)) return interaction.reply({ content: "**يمكن لصاحب التذكرة فقط إستخدام هذا الزر .**", ephemeral: true })
        interaction.reply({ content: `${role}`, embeds: [new Discord.MessageEmbed().setDescription(`**تم ترك التذكرة من قبل : ${interaction.member} .**`).setColor(`${colorE}`)] })
        let embed = new Discord.MessageEmbed()
          .setDescription("**إضغط على الزر لتصبح مسؤول التذكرة**")
          .setColor(`${colorE}`)
        let row = new Discord.MessageActionRow().addComponents(
          new Discord.MessageButton()
            .setLabel("Claim")
            .setCustomId("claim")
            .setEmoji("<:Evsupport:1326656228847521833>")
            .setStyle("SUCCESS") )
        interaction.channel.permissionOverwrites.edit(role, {
          SEND_MESSAGES: true, })
interaction.channel.permissionOverwrites.edit(interaction.member, {
          SEND_MESSAGES: false, })

        db.subtract(`weekuser_${interaction.member.id}`, 1)
        db.subtract(`alluser_${interaction.member.id}`, 1)
        db.delete(`claimed_${interaction.channel.id}_${interaction.member.id}`)
        db.delete(`user_${interaction.channel.id}`)
        msg.edit({ embeds: [embed], components: [row] })
      }
  }
});

client.on("channelDelete" , channel => {
if(db.has(`user_${channel.id}`)) {
const s = db.get(`user_${channel.id}`)    
  if(db.has(`claimed_${channel.id}_${s}`)) {
    db.delete(`claimed_${channel.id}_${s}`) 
  }
    if(db.has(`message_${channel.id}`)) {
    db.delete(`message_${channel.id}`)
    db.delete(`user_${channel.id}`)
    }
}
})

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "نقااط") || message.content.startsWith(prefix + "نقاط") || message.content.startsWith(prefix + "نقط")) {
    let user = message.mentions.members.first()
    if (user) {
      let member = message.guild.members.cache.find(u => u == user.id)
      var points = db.get(`weekuser_${user.id}`)
      var weekwarns = db.get(`weekwarns_${user.id}`)
      var allpoints = db.get(`alluser_${user.id}`)
      var allwarns = db.get(`allwarns_${user.id}`)
      var allmute = db.get(`muteall_${user.id}`)
      var weekmute = db.get(`muteweek_${user.id}`)
      if(!points) {
         points = 0 }
      if(!weekwarns) {
         weekwarns = 0 }
      if(!allpoints) {
         allpoints = 0 } 
      if(!allwarns) {
         allwarns = 0 }
      if(!allmute) {
        allmute = 0 }
      if(!weekmute) {
        weekmute = 0 }
      let embed2 = new Discord.MessageEmbed()
        .setDescription(` **${member.user} , Points :**\n \n> **Week Points : \`${points + weekwarns + weekmute}\`**\n> **All Points : \`${allpoints + allwarns + allmute}\`**\n \n> **Week Tickets : \`${points}\`**\n> **Week Warns : \`${weekwarns}\`**\n> **Week Mutes : \`${weekmute}\`**\n \n> **All Tickets : \`${allpoints}\`**\n> **All Warns : \`${allwarns}\`**\n> **All Mutes : \`${allmute}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed2] }) }
    if (!user) {
      var points = db.get(`weekuser_${message.member.id}`)
      var weekwarns = db.get(`weekwarns_${message.member.id}`)
      var allpoints = db.get(`alluser_${message.member.id}`)
      var allwarns = db.get(`allwarns_${message.member.id}`)
      var allmute = db.get(`muteall_${message.member.id}`)
      var weekmute = db.get(`muteweek_${message.member.id}`)
      if(!points) {
         points = 0 }
      if(!weekwarns) {
         weekwarns = 0 }
      if(!allpoints) {
         allpoints = 0 } 
      if(!allwarns) {
         allwarns = 0 }
      if(!allmute) {
        allmute = 0 }
      if(!weekmute) {
        weekmute = 0 }
      let embed4 = new Discord.MessageEmbed()
        .setDescription(`**${message.member.user} , Points :**\n  \n> **Week Points : \`${points + weekwarns + weekmute}\`**\n>  **All Points : \`${allpoints + allwarns + allmute}\`**\n \n> **Week Tickets : \`${points}\`**\n> **Week Warns : \`${weekwarns}\`**\n> **Week Mutes : \`${weekmute}\`**\n\n> **All Tickets : \`${allpoints}\`**\n> **All Warns : \`${allwarns}\`**\n> **All Mutes : \`${allmute}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed4] }) 
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "tickets") || message.content.startsWith(prefix + "تكتات") || message.content.startsWith(prefix + "تكت")) {
    let user = message.mentions.members.first()
    if (user) {
      let member = message.guild.members.cache.find(u => u == user.id)
      let points = db.get(`weekuser_${user.id}`)
      let allpoints = db.get(`alluser_${user.id}`)
      let embed1 = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`0\`**\n> **All Tickets : \`${allpoints}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested by : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      let embedd = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`${points}\`**\n> **All Tickets : \`0\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested by : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
          let embed44 = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`0\`**\n> **All Tickets : \`0\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested by : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      if (!db.has(`weekuser_${user.id}`)) return message.reply({ embeds: [embed1] })
      if (!db.has(`alluser_${user.id}`)) return message.reply({ embeds: [embedd] })
      let embed2 = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`${points}\`**\n> **All Tickets : \`${allpoints}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed2] })
    }
    if (!user) {
      let points = db.get(`weekuser_${message.member.id}`)
      let allpoints = db.get(`alluser_${message.member.id}`)
      let embed3 = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`0\`**\n> **All Tickets : \`${allpoints}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
        let embedd = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`${points}\`**\n> **All Tickets : \`0\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      if (!db.has(`weekuser_${message.member.id}`)) return message.reply({ embeds: [embed3] })
     if (!db.has(`alluser_${message.member.id}`)) return message.reply({ embeds: [embedd] })
      let embed4 = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Points :`)
        .setDescription(`> **Week Tickets : \`${points}\`**\n> **All Tickets : \`${allpoints}\`**`)

        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed4] }) 
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "mutes") || message.content.startsWith(prefix + "ميوتات")) {
    let user = message.mentions.members.first()
    if (user) {
      let member = message.guild.members.cache.find(u => u == user.id)
      var mutes = db.get(`muteweek_${user.id}`)
      var allmutes = db.get(`muteall_${user.id}`)
      if(!mutes) {
        mutes = 0
      }
      if(!allmutes) {
        allmutes = 0 }
      let embed2 = new Discord.MessageEmbed()
        .setTitle(`${member.user.tag}, Mutes :`)
        .setDescription(`> **All Mutes : \`${allmutes}\`**\n> **Week Mutes : \`${mutes}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed2] }) }
    if (!user) {
      var mutes = db.get(`muteweek_${message.member.id}`)
      var allmutes = db.get(`muteall_${message.member.id}`)
      if(!mutes) {
        mutes = 0 }
      if(!allmutes) {
        allmutes = 0 }
      let embed4 = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Mutes :`)
        .setDescription(`> **Week Mutes : \`${mutes}\`**\n> **All Mutes : \`${allmutes}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed4] }) 
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "ticket(+)")) {
    if (message.member.roles.cache.some(r=> r.id == "1241129866708127834") || message.member.roles.cache.some(r=> r.id == "1241129866708127834")) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`weekuser_${user.id}`, args2)
      await db.add(`alluser_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} ticket points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] })
      let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`** تم اضافة نقطة جديدة**`)
      .setDescription(`> ** المسؤول : ${message.member}**\n> ** الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> ** عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "allticket(+)")) {
    if (message.member.roles.cache.some(r=> r.id == "1241129866708127834") || message.member.roles.cache.some(r=> r.id == "1241129866708127834")) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`alluser_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} ticket points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`** تم اضافة نقطة جديدة**`)
      .setDescription(`> ** المسؤول : ${message.member}**\n> ** الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> ** عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "mute(+)")) {
    if (message.member.roles.cache.some(r=> r.id == "1241129866708127834") || message.member.roles.cache.some(r=> r.id == "1241129866708127834")) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`muteweek_${user.id}`, args2)
      await db.add(`muteall_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} mute points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`** تم اضافة نقطة جديدة**`)
      .setDescription(`> ** المسؤول : ${message.member}**\n> ** الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> ** عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "allmute(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`muteall_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} mute points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`** تم اضافة نقطة جديدة**`)
      .setDescription(`> ** المسؤول : ${message.member}**\n> ** الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> ** عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "allwarn(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`allwarns_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} warn points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`** تم اضافة نقطة جديدة**`)
      .setDescription(`> ** المسؤول : ${message.member}**\n> ** الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> ** عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "ticket(-)")) {
    if (message.member.roles.cache.some(r=> r.id == "1241129866708127834") || message.member.roles.cache.some(r=> r.id == "1241129866708127834")) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      if (!db.has(`weekuser_${user.id}`)) return message.reply("**This user does not have any points**")
      if (!db.has(`alluser_${user.id}`)) return message.reply("**This user does not have any points**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be removed**")
      await db.subtract(`weekuser_${user.id}`, args2)
await db.subtract(`alluser_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done removed ${args2} ticket points from ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`** تم ازالة نقطة جديدة**`)
      .setDescription(`> ** المسؤول : ${message.member}**\n> ** الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> ** عدد النقاط المزالة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }

  }

});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "warn(+)")) {
    if (message.member.roles.cache.some(r=> r.id == 1241129866708127836) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be added**")
      await db.add(`weekwarns_${user.id}`, args2)
      await db.add(`allwarns_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done added ${args2} warn points to ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
            let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم اضافة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المضافة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "warn(-)")) {
    if (message.member.roles.cache.some(r=> r.id == "1241129866708127834") || message.member.roles.cache.some(r=> r.id == "1241129866708127834")) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      if (!db.has(`weekwarns_${user.id}`)) return message.reply("**This user does not have any points**")
      if (!db.has(`allwarns_${user.id}`)) return message.reply("**This user does not have any points**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be removed**")
      await db.subtract(`weekwarns_${user.id}`, args2)
      await db.subtract(`allwarns_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done removed ${args2} warn points from ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
                  let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`** تم ازالة نقطة جديدة**`)
      .setDescription(`> ** المسؤول : ${message.member}**\n> ** الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> ** عدد النقاط المزالة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "mute(-)")) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388) || message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
      let user = message.mentions.members.first()
      if (!user) return message.reply("**Error : Please mention a user**")
      if (!db.has(`muteweek_${user.id}`)) return message.reply("**This user does not have any points**")
      if (!db.has(`muteall_${user.id}`)) return message.reply("**This user does not have any points**")
      let args = message.content.split(" ").slice(2).join(" ")
      if (!args) return message.reply("**Error : Please put a number**")
      let args2 = parseInt(args)
      if (!args2) return message.reply("**Error : This is not a number that can be removed**")
      await db.subtract(`muteweek_${user.id}`, args2)
      await db.subtract(`muteall_${user.id}`, args2)
      let embed = new Discord.MessageEmbed()
        .setDescription(`**Done removed ${args2} mute points from ${user}**`)
        .setColor(`${colorE}`)
      message.reply({ embeds: [embed] }) 
                  let log = message.guild.channels.cache.find(r=>r.id == 1113504839696126044)
      let member = message.guild.members.cache.find(r=>r.id == user.id)
      let embedLog = new Discord.MessageEmbed()
      .setAuthor({name:message.member.user.username , iconURL:message.member.user.displayAvatarURL()})
      .setTitle(`**${emj.Right} تم ازالة نقطة جديدة**`)
      .setDescription(`> **${emj.Dot} المسؤول : ${message.member}**\n> **${emj.Dot} الشخص : ${message.guild.members.cache.find(r=>r.id == user.id)}**\n> **${emj.Dot} عدد النقاط المزالة : ${args2}**`)
      .setFooter({text:member.user.username , iconURL:member.user.displayAvatarURL()})
      .setColor(`${colorE}`)
      log.send({embeds:[embedLog]})
      log.send(`https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=664f13e1&is=664dc261&hm=decc630f7c2060d3637510176de4ca3846e33d06a25bee9c06e65848aee7cd61&`)
    }
  }
});

client.on("messageCreate", message => {
  if (message.content == prefix + "claim") {


      let embed = new Discord.MessageEmbed()
        .setDescription("**إضغط على الزر لتصبح مسؤول التذكرة**")
        .setColor(`${colorE}`)
      let row = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
          .setLabel("Claim")
          .setCustomId("claim")
          .setStyle("SUCCESS")
      )
      message.delete()
      message.channel.send({ embeds: [embed], components: [row] }).then(m => db.set(`message_${message.channel.id}`, m.id)) 

  }
});

///////////////
client.on("messageCreate" , message => {
if(message.content.startsWith("$تحويل")) {
message.delete()
message.channel.send(`** التحويل فقط لـ <@${bankid}> .**`);
}
});



client.on('messageCreate', async (message) => {
  if (message.content.startsWith('$setr')) {
    let args = message.content.split(" ")
    const roles = message.mentions.roles.first() || message.guild.roles.cache.find((x) => x.id == args[1]) || message.guild.roles.cache.find((x) => x.name == message.content.split(' ').slice(1).join(' '));
    if (!message.member.permissions.has("MANAGE_ROLES"))  {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
    if(!args) return message.reply("**حدد رتبة !**")
        if(!roles) return message.reply("**حدد رتبة !**")


    const members = roles.members.map((e) => `${emj.Dot} |  <@${e.user.id}>`);
    const membersCount = roles.members.size;
    const MAX_LENGTH = 2000;
    const chunks = [];
    let currentChunk = '';
    for (const member of members) {
      if (currentChunk.length + member.length + 1 <= MAX_LENGTH) {
        currentChunk += `${member}\n`; } else {
        chunks.push(currentChunk);
        currentChunk = `${member}\n`; }}
    if (currentChunk) {
      chunks.push(currentChunk); }
    for (let i = 0; i < chunks.length; i++) {
      const content = i === chunks.length - 1 ? `**${chunks[i]}\nعددهم : \`${membersCount}\`**` : `**${chunks[i]}**`;
      await message.reply({ content }); }
  }
});

////////////////
client.on("messageCreate" , message => {
if(message.content.startsWith("خط")) {
if(message.content.startsWith("خطط")) return false;
message.channel.send(`${lineLink}`)
        message.delete(); 
}
});

////////////////

client.on("messageCreate" , message => {
  if(message.channel.id == 1164798267004039168) {
  if(message.author.bot) return;
  if(message.content.startsWith(prefix + "طلب")) return false;
  setTimeout(()=> {
    message.delete()
  },3000)
  }
});

    client.on("messageCreate" , message => {
      if(message.content.startsWith(prefix + "طلب")) {
        if(message.channel.id == "") {
        let args = message.content.split(" ").slice(1).join(" ")
        if(!args) {
          message.reply(`**طريقة الطلب \`:\` ${prefix}طلب + طلبك**`).then(m => {
            setTimeout(() => {
              m.delete()
              message.delete()
            },3000)
          })
        }
        if(args) {
        let row = new Discord.MessageActionRow().addComponents(
          new Discord.MessageButton()
          .setLabel("منتجات 🎮")
          .setCustomId("mon")
          .setStyle("SECONDARY"),
          new Discord.MessageButton()
          .setLabel("تصاميم 🎨")
          .setCustomId("des")
          .setStyle("SECONDARY"),
          new Discord.MessageButton()
          .setLabel("برمجيات 💻")
          .setCustomId("dev")
          .setStyle("SECONDARY"),
          new Discord.MessageButton()
          .setLabel("الغاء ❌")
          .setCustomId("can")
          .setStyle("DANGER"), )
        let embed = new Discord.MessageEmbed()
        .setTitle("**__إختر المكان الصحيح لطلبك :__                                                                  **")
        .setDescription(`**منتجات : 🎮                                                                                        
- مثل : نيترو , حسابات , الخ ..
تصاميم : 🎨
- مثل صورة , بنر , الخ ..
برمجيات : 💻
- مثل : بوت , كود , الخ ..
إلغاء الطلب : ❌
- لإلغاء طلبك، عدم إرساله للبائعين .**`)
        .setColor(`${colorE}`)
db.set(`talab_${message.member.id}` , args)        
          message.channel.send({content:`${message.member}` , embeds:[embed] , components:[row]})
        message.delete() 
        }
        }
      }
    })

    client.on("interactionCreate" , interaction => {
      if(interaction.isButton()) {
        if(interaction.customId == "mon") {
          let talab = db.get(`talab_${interaction.member.id}`)
          let number = db.fetch(`OrderMsg_${interaction.guild.id}`)
            if(!number || number === null) number = 1;
db.add(`OrderMsg_${interaction.guild.id}`,1)
          const row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
            .setLabel("Delete")
            .setCustomId("del")
            .setStyle("DANGER") )
          let mon = new Discord.MessageEmbed()
          .setTitle("> **الطلب الجديد :                                                                  **")
          .setAuthor({name : `${interaction.member.user.username}` , iconURL : interaction.member.displayAvatarURL()})
          .setDescription(`**${talab}**`)
          .setColor(`${colorE}`)
          .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
          .setFooter({text : `${interaction.guild.name}` , iconURL : interaction.guild.iconURL()})
          interaction.guild.channels.cache.get("1121188125885071521").send({content: `<@&1121188022227058778>\n**صاحب الطلب : ${interaction.member}\nرقم الطلب : ${number}**`, embeds:[mon] , components:[row]})
    interaction.guild.channels.cache.get("1121188125885071521").send({content: `${lineLink}`})
          interaction.reply("> **تم إرسال طلبك إلى البائعين، الرجاء الإنتظار ليتواصل معك أحدهم .**")
            interaction.message.delete()
  .then((reply) => {
    setTimeout(() => {
      interaction.deleteReply().catch(err=>{}) }, 5000); })
        db.delete(`talab_${interaction.member.id}`)
        }
        if(interaction.customId == "des") {
                    let talab = db.get(`talab_${interaction.member.id}`)

let number = db.fetch(`OrderMsg_${interaction.guild.id}`)
            if(!number || number === null) number = 1;
db.add(`OrderMsg_${interaction.guild.id}`,1)
            const row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
            .setLabel("Delete")
            .setCustomId("del")
            .setStyle("DANGER") )
          let mon = new Discord.MessageEmbed()
          .setTitle("> **الطلب الجديد :                                                                  **")
          .setAuthor({name : `${interaction.member.user.username}` , iconURL : interaction.member.displayAvatarURL()})
          .setDescription(`**${talab}**`)
          .setColor(`${colorE}`)
          .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
          .setFooter({text : `${interaction.guild.name}` , iconURL : interaction.guild.iconURL()})
          interaction.guild.channels.cache.get("1121188127613128724").send({content: `<@&1121188024387121192>\n**صاحب الطلب : ${interaction.member}\nرقم الطلب : ${number}**`, embeds:[mon] , components:[row]})
          interaction.guild.channels.cache.get("1121188127613128724").send({content: `${lineLink}`})
          interaction.reply("> **تم إرسال طلبك إلى المصممين، الرجاء الإنتظار ليتواصل معك أحدهم .**")
            interaction.message.delete()
    .then((reply) => {
    setTimeout(() => {
      interaction.deleteReply().catch(console.error); }, 5000); }) 
    db.delete(`talab_${interaction.member.id}`)
        }
        if(interaction.customId == "dev") {
                    let talab = db.get(`talab_${interaction.member.id}`)

let number = db.fetch(`OrderMsg_${interaction.guild.id}`)
            if(!number || number === null) number = 1;
db.add(`OrderMsg_${interaction.guild.id}`,1)
            const row = new Discord.MessageActionRow().addComponents(
            new Discord.MessageButton()
            .setLabel("Delete")
            .setCustomId("del")
            .setStyle("DANGER") )
          let mon = new Discord.MessageEmbed()
          .setTitle("> **الطلب الجديد :                                                                  **")
          .setAuthor({name : `${interaction.member.user.username}` , iconURL : interaction.member.displayAvatarURL()})
          .setDescription(`**${talab}**`)
          .setColor(`${colorE}`)
          .setThumbnail(interaction.guild.iconURL())
          .setTimestamp()
          .setFooter({text : `${interaction.guild.name}` , iconURL : interaction.guild.iconURL()})
          interaction.guild.channels.cache.get("1121188124068954182").send({content: `<@&1121188023191732296>\n**صاحب الطلب : ${interaction.member}\nرقم الطلب : ${number}**`, embeds:[mon] , components:[row]})
          interaction.guild.channels.cache.get("1121188124068954182").send({content: `${lineLink}`})
          interaction.reply("> **تم إرسال طلبك إلى المبرمجين، الرجاء الإنتظار ليتواصل معك أحدهم .**")
            interaction.message.delete()
    .then((reply) => {
    setTimeout(() => {
      interaction.deleteReply().catch(console.error); }, 5000); })
          db.delete(`talab_${interaction.member.id}`) }
        if(interaction.customId == "can") {
          interaction.reply("> **تم إلغاء طلبك بنجاح .**")
          interaction.message.delete()
    .then((reply) => {
    setTimeout(() => {
      interaction.deleteReply().catch(console.error); }, 5000); }) }
        if(interaction.customId == "del") {
          if(interaction.member.roles.cache.some(r=>r.id == 1121187991763812435)) {
            interaction.message.delete()
    interaction.reply({ content: `**${emj.True} لقد تم حذف الطلب بنجاح .**`, ephemeral: true })
          }
        }
      }
    });

///////////
client.on('messageCreate', message => {
  if (message.content.startsWith(prefix + 'رتب') || message.content.startsWith(prefix + 'معلومات')) {
    let embed1 = new MessageEmbed()
      .setTitle(`**${emj.Right} Everest \`S\` Information・المعلومات**`)
      .setDescription(`**إختر من الأزرار التالية ما يناسبك.**`)
      .setColor(colorE)
      .setImage('https://cdn.discordapp.com/attachments/1318602865153151087/1326647627651223603/1e8bad5edca9f601.png?ex=6788c222&is=678770a2&hm=28c2c1b9b9b579bd84d469815cd73808aa4b4947b06be0914ee683850e541f56&');

    let row1 = new MessageActionRow().addComponents(
      new MessageButton()
        .setLabel('رتب')
        .setCustomId('roles')
        .setStyle('SUCCESS'),
      new MessageButton()
        .setLabel('الرتب المميزه')
        .setCustomId('info')
        .setStyle('SUCCESS'),
      new MessageButton()
        .setLabel('منشورات مميزة')
        .setCustomId('manshorat')
        .setStyle('SUCCESS'),
      new MessageButton()
        .setLabel('رومات خاصة')
        .setCustomId('rooms')
        .setStyle('SUCCESS')
    );

    message.channel.send({ embeds: [embed1], components: [row1] });
  }
});

client.on("interactionCreate", async interaction => {
    if (interaction.customId === "roles") {
        const message = await interaction.channel.messages.fetch(interaction.message.id);
        let embed1 = new MessageEmbed()
           .setDescription(` معلومات الرتب | Everest S 

1 <@&1241129866481635474> :

المميزات :

> إمكانية النشر في كل الرومات .

> إمكانية المنشن في الرومات .

> إمكانية نشر الصور في كل الرومات .

> السـعر = 300.000

2 <@&1241129866481635473> :

> المميزات :

> النشر في جميع الرومات بإستثناء  التصاميم + البرمجيات  .

> إمكانية نشر الصور .

> إمكانية المنشن .

> السـعر = 250.000

3 <@&1241129866481635472> :

> المميزات : 

> النشر في جميع الرومات بإستثناء  التصاميم + البرمجيات  .

> لا يمكن نشر الصور .

> إمكانية المنشن .

> السـعر = 200.000

4 <@&1241129866481635471> :

> المميزات : 

> النشر في جميع الرومات بإستثناء  التصاميم + البرمجيات  .

> لا يمكن نشر الصور .

> لا يمكن المنشن .

> السـعر = 150.000

5 <@&1241129866481635469> :

> المميزات :

> النشر في روم  البرمجيات  فقط .

> إمكانية نشر الصور .

> إمكانية المنشن .

> السـعر = 100.000

6 <@&1241129866481635470> :

> المميزات :

> النشر في روم [ التصاميم ] فقط .

> إمكانية نشر الصور .

> إمكانية المنشن .

> السـعر = 100.000

للطلب يُرجى التوجه إلى <#1241129868515610808> .

 `)     
            .setImage(`https://cdn.discordapp.com/attachments/1318602865153151087/1326647627651223603/1e8bad5edca9f601.png?ex=6788c222&is=678770a2&hm=28c2c1b9b9b579bd84d469815cd73808aa4b4947b06be0914ee683850e541f56&`)
            .setColor(`${colorE}`);
        message.edit({ embeds: [embed1], components: [] });

        setTimeout(() => {
            interaction.channel.send(`** التحويل فقط لـ <@${bankid}> .**`);
        }, 500);
    }
});
//
client.on("interactionCreate" , async interaction => {
if(interaction.isButton()) {
if(interaction.customId == "ads") {
  let embed3 = new Discord.MessageEmbed() 
.setDescription(`
معلومات الاعلانات :

<:74:1242783266348466197> # - NA7LA S : معلومات الاعلانات


قسم حزمة الجولد :

<:74:1242783266348466197> منشن هير
<:emoji_79:1242799096725766154> السعر : 100k <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> منشن ايفري ون
<:emoji_79:1242799096725766154> السعر : 200k <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


قسم حزمة السلفر :

<:74:1242783266348466197> قيفاوي في روم ⁠૱・هدايا・الإعلانات مع منشن ايفري ون
<:74:1242783266348466197> مدة القيف اوي 1 ايام
<:74:1242783266348466197> على 100k
<:emoji_79:1242799096725766154> السعر : 400k <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


قسم حزمه بلاتينيوم :

<:74:1242783266348466197> روم خاص لسيرفرك وقيف اوي
<:74:1242783266348466197> مدة القيف اوي 3 ايام
<:74:1242783266348466197> على 500k
<:emoji_79:1242799096725766154> السعر : 1m <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>
قسم حزمة بروكاست :


<:74:1242783266348466197> بروكاست للاونلاين

<:emoji_79:1242799096725766154> السعر : 10$ <:42:1242766803000754177>



<:74:1242783266348466197> بروكاست للكل

<:emoji_79:1242799096725766154> السعر : 25$ <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

قسم حزمة الدايموند

<:74:1242783266348466197> قيف اوي اول كتروجي في السيرفر شرط دخول سيرفرك
<:74:1242783266348466197> مدة القيف اوي 7 ايام
<:74:1242783266348466197> على 5m
<:74:1242783266348466197> 3 منشن افري
<:emoji_79:1242799096725766154> السعر : 10$ <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


<:74:1242783266348466197> ملاحظات : لطلب إعلان يرجى التواصل مع الدعم الفني: <#996376383896957059>  <:46:1242766808847482900> فقط.

التحويل فقط لـ <@979266698689519618> فقط .
أذا قمت بالتحويل لاحد غير الحساب المذكور أعلاه فلن يتم عمل الأعلان لك ولن نتحمل المسؤولية لخطأك .

**`)
.setImage(`https://media.discordapp.net/attachments/1113504839696126044/1249056481026904144/20240521_222601.jpg?ex=6690c2bf&is=668f713f&hm=358eb850520ba1eed566569563f6186e4e4641a123c2710bc2fed4e8e54e7aac&`)
.setColor(`${colorE}`)
interaction.message.edit({ embeds: [embed3], components: [] })
  setTimeout(() => {
  interaction.channel.send(`** التحويل فقط لـ <@${bankid}> .**`); }, 500); 
}
}
});
//

//
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "info") {
const message = await interaction.channel.messages.fetch(interaction.message.id); 
  let embed3 = new MessageEmbed() 
.setDescription(`معلومات الرتب النادره | Everest S 

1 <@&1241129866481635477> :

المميزات :

>  الطلب و النشر في روم <#1241129868092244039> .

> النشر في كل الرومات .

> نشر الصور في كل الرومات .

> منشن إيفري ون كل يوم مرة .

>  السـعر = 6.000.000

> مُلاحظة : متـوفرة فقط إلى  25 شخص .

> 

2 <@&1241129866481635475> 

> المميزات :

> إمكانية النشر في  روم خاص  التي تكون في اليوزر نيم الخاص بك .

> إمكانية منشن هير .

> إمكانية نشر الصور .

> مُلاحظة : الروم تبقى إلى الأبد .

> السـعر = 4.000.000

> 

3 <@&1241129866481635476> :

المميزات :

> إمكانية النشر في كل الرومات .

> منشن إيفري ون كل يومين .

> نشر الصور في كل الرومات .

> السـعر = 3.000.000 .

> مُلاحظة : متـوفرة فقط إلى  50 شخص .

للطلب يُرجى التوجه إلى <#1241129868515610808> .

 `)
.setImage(`https://cdn.discordapp.com/attachments/1318602865153151087/1326647627651223603/1e8bad5edca9f601.png?ex=678a13a2&is=6788c222&hm=62532579de4b17fd520c5eddf10b550e17ebee8eabd4851fbdc01a99fcc6b0e6&`)
.setColor(`${colorE}`)
message.edit({ embeds: [embed3], components: [] })
  setTimeout(() => {
  interaction.channel.send(`** التحويل فقط لـ <@${bankid}> .**`); }, 500); 
}
});

//
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "manshorat") {
const message = await interaction.channel.messages.fetch(interaction.message.id); 
  let embed3 = new MessageEmbed() 
.setDescription(` معلومات المنشورات المميزة | Everest S 

1) منشور مميز في روم <#1241129867848716407> مع منشن هير  200.000.

) منشور مميز في روم <#1241129867848716407> مع منشن إيفريون 400.000 .

مُلاحظة هامة : المنشورات المميزة تكون طلبات / منشورات ]

للطلب يُرجى التوجه إلى <#1241129868515610808> .

`)
.setImage(`https://cdn.discordapp.com/attachments/1243164449951715389/1326572083777634394/9f2215f33c0c8d9d.png?ex=6789cd47&is=67887bc7&hm=7c493384503dbcb09226e55c480b7ea7cbd207c8f42de10447896793d54f9f45&`)
.setColor(`${colorE}`)
message.edit({ embeds: [embed3], components: []})
  setTimeout(() => {
  interaction.channel.send(`**${emj.Dot} التحويل فقط لـ <@${bankid}>**`); }, 500);
}
});

//
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "rooms") {
  const message = await interaction.channel.messages.fetch(interaction.message.id); 
  let fi = interaction.guild.channels.cache.filter(ch => ch.name.startsWith("〢↯・"))
  var f;
  if(fi.size < 10) {
    f = "مفتوح" }
  if(fi.size >= 10) {
    f = "مغلق" }
  let embed3 = new MessageEmbed() 
.setDescription(`**
# ~ NA7LA S

~ NA7LA S

<:74:1242783266348466197> روم خاص لمدة يوم واحد

<:emoji_79:1242799096725766154> السعر = 50k <:42:1242766803000754177>

<:74:1242783266348466197> روم خاص لمدة اسبوع

<:emoji_79:1242799096725766154> السعر : 250k <:42:1242766803000754177>

<:74:1242783266348466197> تجديد الروم الخاص لمدة اسبوع

<:emoji_79:1242799096725766154> السعر : 200k <:42:1242766803000754177>

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

قوانين الرومات الخاصة <:28:1242766492362342491>

عدم النشر في الروم لمدة يومين يؤدي لحذف الروم

ممنوع ما تشفر الكلمات بالروم الخاص

ممنوع تمنشن ايفري أكثر من مره او هير أكثر من المرات المسموحه لك

يمنع نشر روابط

{ اذا لم تتبع القوانين سوف يتم سحب رومك الخاص ولا يمكنك تجديده الى في الاسبوع القادم }


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

ملاحظة <:emoji_78:1242783447689461822>

في حال تم اعداد الروم الخاص لن يتم استرداد الأموال

للأستفسار و الشراء توجه الى ⁠⌬・الدعم・الفني <:46:1242766808847482900>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> التحويل فقط لـ

@.gg/na7la ( 979266698689519618 )

<:emoji_78:1242783447689461822> لا نتحمل مسؤولية التحويل إلى شخص آخر
**`)

.setColor(`${colorE}`)
message.edit({ embeds: [embed3], components: []})
   
}
});

client.on("messageCreate" , message => {
  if(message.content == prefix + "rooms") {
    if(message.member.permissions.has("ADMINISTRATOR") || message.member.roles.cache.some(r=>r.id == 1186292596356681839)) {
    let embed = new Discord.MessageEmbed()
    .setAuthor({name:`${message.member.user.username}` , iconURL:`${message.member.user.displayAvatarURL()}`})
    .setDescription(`> **${emj.True} = ارجاع الرومات**\n\n> **${emj.False} = حذف الرومات**`)
    .setTimestamp()
    .setColor(`${colorE}`)
    .setFooter({text:`${message.guild.name}` , iconURL:`${message.guild.iconURL()}`})
    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
      .setEmoji(`<:Evup:1326655460824191028>`)
      .setStyle("SUCCESS")
      .setCustomId("create"),
      new Discord.MessageButton()
      .setEmoji(`<:Evup:1326655460824191028>`)
      .setStyle("SUCCESS")
      .setCustomId("delete") )
    message.reply({embeds:[embed] , components:[row]}).then(m=> {
      db.set(`m_${message.guild.id}` , m.id) 
    })
      }
  }
});

const cron = require("node-cron");
let config2 = {
  guildId: "1241129866422653019",//ايدي السيرفر
  channels: ["1313853580414816287","1313853456959799297","1241129868092244043","1313853658236059742","1313853913585291295","1241129868092244041","1241129868092244040","1241129868092244039"],//رومات لاتجيه
  channel: "1328732306797625435", /// الروم اليرسل فيه لو الورمات فتحت او انقفلت
  close_time: "1:00",
   open_time: "8:00" ,
   line: "https://i.postimg.cc/65q9MdQM/line.png" /// الخط 
};

  let close_gg = config2.close_time.split(":");
  cron.schedule(`${close_gg[1]} ${close_gg[0]} * * *`, async () => {
    let guild = client.guilds.cache.get(config2.guildId);
    if (!guild) return;
    let channel = guild.channels.cache.get(config2.channel);
    config2.channels.forEach(c => {
      let ch = guild.channels.cache.get(c);
      if (!ch) return;
      ch.permissionOverwrites.edit(guild.id, {
        VIEW_CHANNEL: false
      }).catch(() => 0);
    });
    if (channel) {
      channel.send({ content: ` **تم اغلاق الرومات ، لكن لا تقلق سيتم فتح الرومات في تاسعة صباحاً اوتماتيك.. \@here**` });
      channel.bulkDelete(100)
      channels.bulkDelete(100)
      channel.send({ files: [config2.line] });
    }
  }, {
    timezone: "Asia/Baghdad" /// ال توقيت بحسب توقيت القاهره
  });
  let open_gg = config2.open_time.split(":");
  cron.schedule(`${open_gg[1]} ${open_gg[0]} * * *`, async () => {
    let guild = client.guilds.cache.get(config2.guildId);
    if (!guild) return;
    let channel = guild.channels.cache.get(config2.channel);
    config2.channels.forEach(c => {
      let ch = guild.channels.cache.get(c);
      if (!ch) return;
      ch.permissionOverwrites.edit(guild.id, {
        VIEW_CHANNEL: true
      }).catch(() => 0);
    });
    if (channel) {
      channel.send({ content: `**تم فتح الرومات يمكنك النشر حالياً ، \@everyone**` });
      channel.bulkDelete(100)
      channels.bulkDelete(100)
      channel.send({ files: [config2.line] });
    }
  }, {
    timezone: "Asia/Baghdad"
  });


client.on("interactionCreate" , async interaction => {
  if(interaction.isButton()) {
    if(interaction.customId == "create") {
      let guild = interaction.guild
      let channel1 = guild.channels.cache.find(r=>r.id == "1235886930479026196")
      let message = db.get(`m_${interaction.guild.id}`)
      let m = interaction.channel.messages.cache.find(r=>r.id == message)
      m.edit({content:`**${emj.True} تم ارجاع الرومات**` , components:[] , embeds:[]})
      db.delete(`m_${interaction.guild.id}`)
const currentDate2 = moment().format('DD-MM-YYYY HH:mm:ss'); 
            channel1.send(`**${emj.Dot} تم إرجاع الرومات .\n${emj.Dot} المشرف المسؤول : ${interaction.member} .
${emj.Dot} بتاريخ : ${currentDate2} .\n @here**`)
await channel1.send(`${lineLink}`)
      let angel = guild.roles.cache.find(r=>r.name == "🜲 || BEE")
      let perfect = guild.roles.cache.find(r=>r.name == "🜲 || HONEY")
      let great = guild.roles.cache.find(r=>r.name == "🜲 || A ROSE")
      let special = guild.roles.cache.find(r=>r.name == "♔・↝ Discord Leader :")
      let normal = guild.roles.cache.find(r=>r.name == "🜲 || Flower")
      let designer = guild.roles.cache.find(r=>r.name
       == "🜲 || Designer S")
      let developer = guild.roles.cache.find(r=>r.name == "🜲 || Developer S")
      let staffs = guild.roles.cache.find(r=>r.name == "♛ || Staff S.")
      let discordstaff = guild.roles.cache.find(r=>r.id == "996364077817405531")
      let arab = guild.roles.cache.find(r=>r.name == "Member")
      let specialrole = guild.roles.cache.find(r=>r.name == "🜲 || NA7LA S")
      let arabs = guild.roles.cache.find(r=>r.id == "1241129866469048367")
      let dealers = guild.roles.cache.find(r=>r.id == "1173940676619157536")
      guild.channels.create("৳・المنشورات・المميزة")
      guild.channels.create("৳・vips")
      guild.channels.create("৳・تصاميم")
      guild.channels.create("৳・برمجيات")
      guild.channels.create("৳・ديسكورد")
      guild.channels.create("৳・حسابات")
      //guild.channels.create("৳・عملات")
      guild.channels.create("৳・العاب")
      //guild.channels.create("❖・طرق")
      guild.channels.create("৳・ٱخرى")
      .then(m=> {

guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
     
guild.channels.cache.find(r=>r.name == "৳・vips").permissionOverwrites.edit(guild.roles.everyone , {
  SEND_MESSAGES:false,
  VIEW_CHANNEL:false
})

guild.channels.cache.find(r=>r.name == "৳・vips").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))

                guild.channels.cache.find(r=>r.name == "৳・vips").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })

                guild.channels.cache.find(r=>r.name == "৳・vips").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・vips").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

/////////////////////////////////////////////////////////////////////

guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })

        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(designer , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })

        guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・تصاميم").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })

guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(developer , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })

                guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・برمجيات").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
        //////////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(perfect , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(great , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(special , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(normal , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:false })

                guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・ديسكورد").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
        /////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
                                  guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(perfect , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(great , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(special , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(normal , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:false })

                guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・حسابات").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
      ///////////////////////////////////////
        //guild.channels.cache.find(r=>r.name == "৳・عملات").permissionOverwrites.edit(guild.roles.everyone , {
          //SEND_MESSAGES:false,
          //VIEW_CHANNEL:false })
        //guild.channels.cache.find(r=>r.name == "৳・عملات").setParent(guild.channels.cache.find(r=>r.id == 1121188043836112968))
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(angel , {
          //SEND_MESSAGES:true,
          //ATTACH_FILES:true,
          //MENTION_EVERYONE:true  })
       //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(specialrole , {
          //SEND_MESSAGES:true,
          //ATTACH_FILES:true,
          //MENTION_EVERYONE:true  })
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(discordstaff , {
         // MANAGE_MESSAGES: true })
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(staffs , {
       //   SEND_MESSAGES:true,
        //  ATTACH_FILES:true,
         // MENTION_EVERYONE:true })
       // guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(arab , {
         // SEND_MESSAGES:false,
         // VIEW_CHANNEL:true  })
       // guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(perfect , {
         // SEND_MESSAGES:true,
          //ATTACH_FILES:true,
         // MENTION_EVERYONE:true })
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(great , {
         // SEND_MESSAGES:true,
         // ATTACH_FILES:false,
          //MENTION_EVERYONE:true })
        //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(special , {
          //SEND_MESSAGES:true,
         // ATTACH_FILES:false,
          //MENTION_EVERYONE:true })
       //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(normal , {
         // SEND_MESSAGES:true,
          //ATTACH_FILES:false,
          //MENTION_EVERYONE:false  })

               //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(arabs , {
          //SEND_MESSAGES:true,
         // ATTACH_FILES:true,
          //MENTION_EVERYONE:true
        //})

               //guild.channels.cache.find(r=>r.name == "❖・عملات").permissionOverwrites.edit(dealers , {
          //SEND_MESSAGES:true,
          //ATTACH_FILES:true,
         //MENTION_EVERYONE:true
        //})
        ////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false })
        guild.channels.cache.find(r=>r.name == "৳・العاب").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true  })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(perfect , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(great , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(special , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true })
        guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(normal , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:false  })

                guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・العاب").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
        /////////////////////////////////////////
        //guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(guild.roles.everyone , {
          //SEND_MESSAGES:false,
          //VIEW_CHANNEL:false  })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").setParent(guild.channels.cache.find(r=>r.id == 1121188043836112968))
        //guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(angel , {
          //SEND_MESSAGES:true,
         // ATTACH_FILES:true,
         // MENTION_EVERYONE:true  })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(specialrole , {
          //SEND_MESSAGES:true,
        //  ATTACH_FILES:true,
        //  MENTION_EVERYONE:true })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(discordstaff , {
       //   MANAGE_MESSAGES: true })
        //guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(staffs , {
     //     SEND_MESSAGES:true,
     ///     ATTACH_FILES:true,
    //      MENTION_EVERYONE:true })
        //guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(arab , {
        //  SEND_MESSAGES:false,
      //    VIEW_CHANNEL:true })

       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(perfect , {
         // SEND_MESSAGES:true,
      //    ATTACH_FILES:true,
       //   MENTION_EVERYONE:true  })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(great , {
       //   SEND_MESSAGES:true,
       //   ATTACH_FILES:false,
         // MENTION_EVERYONE:true  })  
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(special , {
         // SEND_MESSAGES:true,
       //   ATTACH_FILES:false,
       //   MENTION_EVERYONE:true })
       // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(normal , {
      //    SEND_MESSAGES:true,
      //    ATTACH_FILES:false,
      //    MENTION_EVERYONE:false        })

               // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(arabs , {
       //   SEND_MESSAGES:true,
     //     ATTACH_FILES:true,
    //      MENTION_EVERYONE:true
    //    })

               // guild.channels.cache.find(r=>r.name == "❖・طرق").permissionOverwrites.edit(dealers , {
     //     SEND_MESSAGES:true,
     //  ATTACH_FILES:true,
       //   MENTION_EVERYONE:true
     //   })
        ///////////////////////////////////////////
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false        })
       guild.channels.cache.find(r=>r.name == "৳・ٱخرى").setParent(guild.channels.cache.find(r=>r.id == 1248732527733112963))
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(angel , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(specialrole , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true       })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(staffs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true       })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(perfect , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(great , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true        })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(special , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:true       })
        guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(normal , {
          SEND_MESSAGES:true,
          ATTACH_FILES:false,
          MENTION_EVERYONE:false        })
        guild.channels.cache.find(r=>r.name == "𐚱・الطلبات").permissionOverwrites.edit(arab , {
          VIEW_CHANNEL:true        })

              guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(arabs , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })

                guild.channels.cache.find(r=>r.name == "৳・ٱخرى").permissionOverwrites.edit(dealers , {
          SEND_MESSAGES:true,
          ATTACH_FILES:true,
          MENTION_EVERYONE:true
        })
       });
      }
    if(interaction.customId == "delete") {
      let guild = interaction.guild
      let channel2 = guild.channels.cache.find(r=>r.id == "1235886930479026196")
      let roomschannel12345 = '1328732306797625435'
      let arab = guild.roles.cache.find(r=>r.name == ".gg/ev-s")
      const currentDate3 = moment().format('DD-MM-YYYY HH:mm:ss'); 
            channel2.send(`**${emj.Dot} تم حذف الرومات .\n${emj.Dot} المشرف المسؤول : ${interaction.member} .
${emj.Dot} بتاريخ : ${currentDate3} .**`)
await channel2.send(lineLink)
 interaction.guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة").delete()
        
interaction.guild.channels.cache.find(r=>r.name == "৳・vips").delete()
     interaction.guild.channels.cache.find(r=>r.name == "৳・برمجيات").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・ديسكورد").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・حسابات").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・تصاميم").delete()
      //interaction.guild.channels.cache.find(r=>r.name == "❖・عملات").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・العاب").delete()
      //interaction.guild.channels.cache.find(r=>r.name == "❖・طرق").delete()
      interaction.guild.channels.cache.find(r=>r.name == "৳・ٱخرى").delete()


      interaction.message.edit({content:`**${emj.False} تم حذف الرومات**` , components:[] , embeds:[]})
      guild.channels.cache.find(r=>r.name == "𐚱・الطلبات").permissionOverwrites.edit(arab , {
          VIEW_CHANNEL:false })
      guild.channels.cache.forEach(async channel => {
          if(channel.name.startsWith("〢↯・")) {
      const messages = await channel.messages.fetch({ limit: 100 });

      messages.forEach(async (message) => {
       if (message.pinned) {
         return;
        }  
        await message.delete();
      });

            channel.permissionOverwrites.edit(guild.roles.cache.find(r=>r.name == "🜲 || Private S :") , {
              SEND_MESSAGES:false          
            })
          }      
      })
      db.delete(`m_${interaction.guild.id}`) 
    }
  }
});

          ///////////
const warnWork = `1329032012593369119`
const cooldown1 = 10000;

const cooldown2 = new Map();

client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "تحذير")) {
  if(db.has(`inactive_${message.member.id}`)) return message.reply(`**عليك تسجيل نفسك بالاول : <#1168669813346930779>**`)
if (cooldown2.has(message.content)) {
      const timeLeft = cooldown1 - (Date.now() - cooldown2.get(message.content));
      if (timeLeft > 0) {
        return message.reply(`** يجب عليك إنتظار ${Math.ceil(timeLeft / 1000)} ثانية لإستخدام هذا الأمر ..
 يجب التأكد من عدم تكرارك مخالفة شخص تمت مخالفته من قبل زميلك**`);
      }
    }
cooldown2.set(message.content, Date.now());
    if(message.content.startsWith(prefix + "تحذيرات")) return false;
    const wait = require('node:timers/promises').setTimeout;
    if (warnWork.includes(message.channel.id)) {
      const now = new Date()
    let madri = `(=)`
    let channel = message.guild.channels.cache.find(r => r.id == "1241129868301963309");
    let s1 = message.guild.roles.cache.find(r => r.name == "Warn 1");
    let s2 = message.guild.roles.cache.find(r => r.name == "Warn 2");

    let perfect = message.guild.roles.cache.find(r=>r.name == "@Everest S")
    let gold = message.guild.roles.cache.find(r=>r.name == "@Mythic S")
    let great = message.guild.roles.cache.find(r=>r.name == "@Great S")
    let epic = message.guild.roles.cache.find(r=>r.name == "@Super S")
    let normal = message.guild.roles.cache.find(r=>r.name == "@Demon S")
    let designer = message.guild.roles.cache.find(r=>r.name == "@Designer S")
    let developer = message.guild.roles.cache.find(r=>r.name == "@Developer S")
    let prv = message.guild.roles.cache.find(r=>r.name == "@Private S ")
    let special = message.guild.roles.cache.find(r=>r.name == "@Special S")
    let rolesToCheck = ["Private S" , "Great S" , "Mythic S" , "Special S" , "Super S" , "Demon S" , "Designer S" , "Developer S" , "Everest S"]
    let args = message.content.split(" ")
    let user = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id ==      args[1])
    let reason = message.content.split(" ").slice(2).join(" ")
    if(!user) return message.reply(`** يرجى وضع منشن الشخص أولاً !**`)
    const roles = user.roles.cache;
    const roleNames = Array.from(roles.values()).map(role => role.name);
    const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));
    if(rolesUserHas.length === 0) return message.reply(`** هذا الشخص لا يمتلك رتب بيع**`)
    if(!reason) return message.reply(`** يرجى وضع السبب أولاً !**`)
    if(!message.attachments.size) return message.reply(`**يرجى وضع الدليل أولاً !**`)

    if(!user.roles.cache.some(r=>r.name == "Warn 1") && !reason.includes(`(=)`)) {
    message.reply(`** تم إعطاء التحذير لـ ${user} !**`)
    db.add(`weekwarns_${message.member.id}` , 1)
    db.add(`allwarns_${message.member.id}` , 1)
     const attachments = Array.from(message.attachments.values());
      const attachmentFiles = attachments.map((attachment) => attachment.url);
    channel.send({content:`** الشخص : ${user}\n\n الإداري : ${message.member}\n\n نوع التحذير : Warn 1\n\n السبب : ${reason}\n\n الدليل :**` , files:attachmentFiles})
      const a = attachmentFiles.join(`\n`)
      channel.send(`${lineLink}`);
      const roles = user.roles.cache;
      const roleNames = Array.from(roles.values()).map(role => role.name);
      const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));

      user.roles.add([s1])

    }
    if(user.roles.cache.some(r=>r.name == "Warn 1") && !reason.includes(`(=)`)) {
      if(!user.roles.cache.some(r=>r.name == "Warn 2") && !reason.includes(`(=)`)) {
      message.reply(`** تم إعطاء التحذير لـ ${user} !**`)
    db.add(`weekwarns_${message.member.id}` , 1)
    db.add(`allwarns_${message.member.id}` , 1)
     const attachments = Array.from(message.attachments.values());
      const attachmentFiles = attachments.map((attachment) => attachment.url);
    channel.send({content:`** الشخص : ${user}\n\n الإداري : ${message.member}\n\n نوع التحذير : Warn 2\n\n السبب : ${reason}\n\n الدليل :**` , files:attachmentFiles})
       channel.send(`${lineLink}`);
        const a = attachmentFiles.join(`\n`)
        const roles = user.roles.cache;
      const roleNames = Array.from(roles.values()).map(role => role.name);
      const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));

      user.roles.add([s2])

    }
    }
    if(user.roles.cache.some(r=>r.id== "1241129866422653028") && !reason.includes(`(=)`)) {
            user.roles.remove([s1,s2,perfect,gold,great,epic,normal,designer,developer,prv])
                message.reply(`** تم إعطاء التحذير لـ ${user} !**`)
    db.add(`weekwarns_${message.member.id}` , 1)
    db.add(`allwarns_${message.member.id}` , 1)
     const attachments = Array.from(message.attachments.values());
      const attachmentFiles = attachments.map((attachment) => attachment.url);
    channel.send({content:`** الشخص : ${user}\n\n الإداري : ${message.member}\n\n نوع التحذير : سحب رتبة\n\n السبب : ${reason}\n\n الدليل :**` , files:attachmentFiles})
      const a = attachmentFiles.join(`\n`)
      const roles = user.roles.cache;
      const roleNames = Array.from(roles.values()).map(role => role.name);
      const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));

      channel.send(`${lineLink}`);
    }
    if(reason.includes(`(=)`)) {
                message.reply(`** تم إعطاء التحذير لـ ${user} !**`)
    db.add(`weekwarns_${message.member.id}` , 1)
    db.add(`allwarns_${message.member.id}` , 1)
     const attachments = Array.from(message.attachments.values());
      const attachmentFiles = attachments.map((attachment) => attachment.url);
    channel.send({content:`** الشخص : ${user}\n\n الإداري : ${message.member}\n\n نوع التحذير : سحب رتبة\n\n السبب : ${reason}\n\n الدليل :**` , files:attachmentFiles})
      channel.send(`${lineLink}`);
      const a = attachmentFiles.join(`\n`)
      const roles = user.roles.cache;
      const roleNames = Array.from(roles.values()).map(role => role.name);
      const rolesUserHas = rolesToCheck.filter(role => roleNames.includes(role));

              user.roles.remove([s1,s2,perfect,gold,great,epic,normal,designer,developer,prv,special])

    }
      }
  }
});



client.on("messageCreate", async message => {
  if (message.content.startsWith(prefix + "warns") || message.content.startsWith(prefix + "تحذيرات")) {
    let user = message.mentions.members.first()
    if (user) {
      let member = message.guild.members.cache.find(u => u == user.id)
      var warns = db.get(`weekwarns_${user.id}`)
      var allwarns = db.get(`allwarns_${user.id}`)
      if(!warns) {
        warns = 0 }
      if(!allwarns) {
        allwarns = 0 }
      let embed2 = new Discord.MessageEmbed()
       .setTitle(`${member.user.tag}, Warns :`)
        .setDescription(`> **All Warns : \`${allwarns}\`**\n> **Week Warns : \`${warns}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed2] }) }
    if (!user) {
      var warns = db.get(`weekwarns_${message.member.id}`)
      var allwarns = db.get(`allwarns_${message.member.id}`)
      if(!warns) {
        warns = 0 }
      if(!allwarns) {
        allwarns = 0 }
      let embed4 = new Discord.MessageEmbed()
        .setTitle(`${message.member.user.tag}, Warns :`)
        .setDescription(`> **Week Warns : \`${warns}\`**\n> **All Warns : \`${allwarns}\`**`)
        .setColor(`${colorE}`)
        .setFooter({ text: `Requested By : ${message.member.user.tag}`, iconURL: message.member.user.displayAvatarURL() })
      message.reply({ embeds: [embed4] }) 
    }
  }
});

////////
client.on('messageCreate', async (message) => {
    if (message.content.startsWith('$توب تحذيرات')) {
  if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
            try {
                const memberList = await message.guild.members.fetch();
                let usersData = [];
                memberList.forEach((member) => {
                    if (member.roles.cache.has('996364077817405531')) {
                        var points = db.get(`weekuser_${member.id}`);
                        var weekwarns = db.get(`weekwarns_${member.id}`);
                        var weekmute = db.get(`muteweek_${member.id}`);
                        points = parseInt(points) || 0;
                        weekwarns = parseInt(weekwarns) || 0;
                        weekmute = parseInt(weekmute) || 0;
                        if (points > 0 || weekwarns > 0 || weekmute > 0) {
                            usersData.push({ user: member.user, points, weekwarns, weekmute , total : points + weekwarns + weekmute}); }}});
                usersData.sort((a, b) => b.total - a.total);
                const embed = new MessageEmbed()
                    .setColor(`${colorE}`)
                  .setImage(`https://media.discordapp.net/attachments/1167747407954575411/1167747868065534012/c1849e19e6743de8.png?ex=654f40f3&is=653ccbf3&hm=f67937cbd6238e0d617e82d711b453c3692495c5691acfd09bea428ec87d1a54&=&width=1440&height=480`)
                    .setTitle('**Top 10 Week :**');
                const topUsers = usersData.slice(0, 10);
                topUsers.forEach((user, index) => {
                    embed.addField(`**#${index + 1} | **`, `**<@${user.user.id}> - ${user.points} Tickets - ${user.weekwarns} Warns - ${user.weekmute} Mutes - All Week : ${user.points + user.weekwarns + user.weekmute} **`); });
                const channel = message.guild.channels.cache.get('1113504839696126044');
                if (channel && channel.isText()) {
                    await channel.send({ embeds: [embed] });
                    await message.reply('**تم إعادة تعيين نقاط الأسبوع بنجاح.**'); }
                usersData.forEach((user) => {
                    if (user.user.id !== client.user.id) {
if(db.has(`feedback_${user.user.id}`)) {
db.delete(`feedback_${user.user.id}`)
}
                        if (user.points === 0 && user.weekwarns === 0 && user.weekmute === 0) {
                            db.delete(`weekuser_${user.user.id}`);
                            db.delete(`weekwarns_${user.user.id}`);
                            db.delete(`muteweek_${user.user.id}`); } else {
                            db.set(`muteweek_${user.user.id}`, 0);
                          db.set(`weekwarns_${user.user.id}`, 0);
                          db.set(`weekuser_${user.user.id}`, 0); } } }); } catch (error) {
                consol.error('حدث خطأ :', error); 
            }
        }
});

//////////////
client.on('messageCreate', async (message) => {
    if (message.content.startsWith('$top') || message.content.startsWith('$توب')) {
        try {
            const memberList = await message.guild.members.fetch();
            let usersData = [];
            memberList.forEach((member) => {
                if (member.roles.cache.has('996364077817405531')) {
                    var points = db.get(`alluser_${member.id}`);
                    var weekwarns = db.get(`allwarns_${member.id}`);
                    var weekmute = db.get(`muteall_${member.id}`);
                    points = parseInt(points) || 0;
                    weekwarns = parseInt(weekwarns) || 0;
                    weekmute = parseInt(weekmute) || 0;
                    if (points > 0 || weekwarns > 0 || weekmute > 0) {
                        usersData.push({ user: member.user, points, weekwarns, weekmute, totalPoints: points + weekwarns + weekmute });}}});
            usersData.sort((a, b) => b.totalPoints - a.totalPoints);
            const embed = new MessageEmbed()
                .setColor(`${colorE}`)
                .setTitle('**Top 10 Points :**');
            const topUsers = usersData.slice(0, 10);
            if (topUsers.length === 0) {
                embed.setDescription('**لا يوجد أعضاء يمتلكون نقاط .**'); } else {
                topUsers.forEach((user, index) => {
                    embed.addField(`**#${index + 1} | **`, `**<@${user.user.id}> - ${user.points} Tickets - ${user.weekwarns} Warns - ${user.weekmute} Mutes - All Top : ${user.points + user.weekwarns + user.weekmute} **`); }); }
let rowtp = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("All")
        .setCustomId("altop")
        .setStyle("SUCCESS")
        .setDisabled(true) )
  .addComponents(
      new Discord.MessageButton()
        .setLabel("Week")
        .setCustomId("wetop")
        .setStyle("SUCCESS")
        .setDisabled(false) )
            await message.channel.send({ embeds: [embed], components: [rowtp] })
        } catch (error) {
            console.error('حدث خطأ :', error); 
        }
    }
});
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "wetop") {
const message = await interaction.channel.messages.fetch(interaction.message.id);
try {
            const memberList = await message.guild.members.fetch();
            let usersData = [];
            memberList.forEach((member) => {
                if (member.roles.cache.has('996364077817405531')) {
                    var points = db.get(`weekuser_${member.id}`);
                    var weekwarns = db.get(`weekwarns_${member.id}`);
                    var weekmute = db.get(`muteweek_${member.id}`);

                    points = parseInt(points) || 0;
                    weekwarns = parseInt(weekwarns) || 0;
                    weekmute = parseInt(weekmute) || 0;
                    if (points > 0 || weekwarns > 0 || weekmute > 0) {
                        usersData.push({ user: member.user, points, weekwarns, weekmute, totalPoints: points + weekwarns + weekmute });                   }                }});
            usersData.sort((a, b) => b.totalPoints - a.totalPoints);
            const embed = new MessageEmbed()
                .setColor(`${colorE}`)
                .setTitle('**Top 10 Week :**');
            const topUsers = usersData.slice(0, 10);
            if (topUsers.length === 0) {
                embed.setDescription('**لا يوجد أعضاء يمتلكون نقاط في هذا الإسبوع .**'); } else {
                topUsers.forEach((user, index) => {
                    embed.addField(`**#${index + 1} | **`, `**<@${user.user.id}> - ${user.points} Tickets - ${user.weekwarns} Warns - ${user.weekmute} Mutes - All Week : ${user.points + user.weekwarns + user.weekmute} **`); }); }
let rowtpreply = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("All")
        .setCustomId("altop")
        .setStyle("SUCCESS")
        .setDisabled(false) )
  .addComponents(
      new Discord.MessageButton()
        .setLabel("Week")
        .setCustomId("wetop")
        .setStyle("SUCCESS")
        .setDisabled(true) )
  await message.edit({ embeds: [embed], components: [rowtpreply] }); } catch (error) {
                console.error('حدث خطأ :', error); }       }    
})
client.on("interactionCreate" , async interaction => {
if(interaction.customId == "altop") {
const message = await interaction.channel.messages.fetch(interaction.message.id);
try {
            const memberList = await message.guild.members.fetch();
            let usersData = [];
            memberList.forEach((member) => {
                if (member.roles.cache.has('996364077817405531')) {
                    var points = db.get(`alluser_${member.id}`);
                    var weekwarns = db.get(`allwarns_${member.id}`);
                    var weekmute = db.get(`muteall_${member.id}`);
                    points = parseInt(points) || 0;
                    weekwarns = parseInt(weekwarns) || 0;
                    weekmute = parseInt(weekmute) || 0;
                    if (points > 0 || weekwarns > 0 || weekmute > 0) {
                        usersData.push({ user: member.user, points, weekwarns, weekmute, totalPoints: points });                    }                }            });
            usersData.sort((a, b) => b.totalPoints - a.totalPoints);
            const embed = new MessageEmbed()
                .setColor(`${colorE}`)
                .setTitle('**Top 10 Points :**');
            const topUsers = usersData.slice(0, 10);
            if (topUsers.length === 0) {
                embed.setDescription('**لا يوجد أعضاء يمتلكون نقاط .**');
            } else {
                topUsers.forEach((user, index) => {
                    embed.addField(`**#${index + 1} | **`, `**<@${user.user.id}> - ${user.points} Tickets - ${user.weekwarns} Warns - ${user.weekmute} Mutes - All Points : ${user.points + user.weekwarns + user.weekmute} **`);                });            }
let rowtpreply = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
        .setLabel("All")
        .setCustomId("altop")
        .setStyle("SUCCESS")
        .setDisabled(true)    )
  .addComponents(
      new Discord.MessageButton()
        .setLabel("Week")
        .setCustomId("wetop")
        .setStyle("SUCCESS")
        .setDisabled(false)    )              
  await message.edit({ embeds: [embed], components: [rowtpreply] });           
} catch (error) {
                console.error('حدث خطأ :', error);        
}      
}  

})

///////////
let messageCount = 0;
client.on('messageCreate', async (message) => {
    if (message.content.startsWith('$ترقيات')) {
      if (!message.member.permissions.has("ADMINISTRATOR")) {
  return message.reply("**للأسف لا تمتلك صلاحية**"); 
}
        try {
            const memberList = await message.guild.members.fetch();
            memberList.forEach(async (member) => {
                if (member.roles.cache.has('996364077817405531')) { 
                    var points = db.get(`weekuser_${member.id}`)
                    let ticketmoney = points * 5
                    var weekwarns = db.get(`weekwarns_${member.id}`)
                    let warnsmoney = weekwarns * 5
                    var weekmute = db.get(`muteweek_${member.id}`) 
                    let mutemoney = weekmute * 5
                    points = parseInt(points) || 0;
                    weekwarns = parseInt(weekwarns) || 0;
                    weekmute = parseInt(weekmute) || 0;
                    messageCount++;
                    var roleToAssign = "996364077817405531";
                    var roleToAssignHighStaff = "996364341462970388";
                    if (!member.roles.cache.some(r => r.id == 1001974960090251375)) {
                        if (points + weekwarns >= 80) {
                            roleToAssign = "دبل ترقية";
                        } else if (points + weekwarns >= 40 && points + weekwarns <= 79) {
                            roleToAssign = "ترقية";
                        } else if (points + weekwarns >= 15 && points + weekwarns <= 39) {
                            roleToAssign = "ثابت";
                        } else if (points + weekwarns < 15) {
                            roleToAssign = "تخفيض";                        }                    }
                    if (member.roles.cache.some(r => r.id == 996364077817405531)) {
                        if (points + weekwarns >= 130) {
                            roleToAssignHighStaff = "دبل ترقية";                        } else if (points + weekwarns >= 40 && points + weekwarns <= 79) {
                            roleToAssignHighStaff = "ترقية";
                        } else if (points + weekwarns >= 15 && points + weekwarns + weekmute < 39) {
                            roleToAssignHighStaff = "ثابت";                        }
                      else if (points + weekwarns < 15) {
                            roleToAssignHighStaff = "تخفيض";                        }                   }
                    let replyMessage = `> ** الإداري : <@${member.user.id}>**\n> ** الإداري رقم : ${messageCount}**\n** عدد التكتات : ${points}\n عدد التحذيرات : ${weekwarns}\n مجموع النقاط الكلي : ${points + weekwarns}\n الراتب: ${points*3 + weekwarns*2} **`;
                    if 
(member.roles.cache.some(r => r.id == 996364077817405531)) {
                        if (roleToAssign !== "996364341462970388") {
                            replyMessage += `\n** النتيجة : ${roleToAssign}**`;                       } }
                    if (member.roles.cache.some(r => r.id == 996364077817405531)) {
                        if (roleToAssignHighStaff !== "996364077817405531") {
                          replyMessage += `  النتيجة : ${roleToAssignHighStaff}`;                   
                        }             
                    }

                    await message.channel.send(replyMessage);           
                }            
            });       
        } catch (error) {
            console.error('خطأ :', error);      
        }  
    }
});

////////////

client.on("messageCreate", async message => {
  const args = message.content.split(" ")
  const now = new Date()
  if(message.content.startsWith(prefix + 'sub')) {
    if (message.member.roles.cache.some(r=> r.id == 996364341462970388)) {
    let prv = message.guild.roles.cache.find(r=>r.id == 1124855135395401738)
    let arab = message.guild.roles.cache.find(r=>r.name == "Member")
    let discordstaff = message.guild.roles.cache.find(r=>r.name == "Staff")
    let args = message.content.split(" ")
    let member = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
   if(!args[1]) return message.reply(` | **منشن شخص !**`)
   if(!member) return message.reply(` | **منشن شخص !**`)
       if(db.has(`prvuser_${member.id}`)) return message.reply(` | **هذا الشخص يمتلك بالفعل روم خاص**`)
    if(!args[2]) return message.reply(` | **حدد مدة الروم !**`)
    if(!args[2].endsWith("d")) {
    if(!args[2].endsWith("h")) {
    if(!args[2].endsWith("m")) {
      return message.reply(`** | حدد الوقت بالأيام - بالساعات أو بالدقائق**`)
    }}}
    if(isNaN(args[2][0])) return message.reply(` | **حدد وقت صحيح !**`)

  message.reply(` **| تم إنشاء روم خاص لـ ${member} لمدة \`${args[2]}\`**`)
member.roles.remove('1124855135395401738')
  let embed = new Discord.MessageEmbed()
  .setDescription(`** Everest \`S\` Private Rooms・الرومات الخاصه**\n\n> ** صاحب الروم : <@${member.id}> **

> ** صنع بواسطة : ${message.member} **

> ** صنع في : <t:${Math.floor(now.getTime() / 1000)}:d> **

> ** ينتهي في : <t:${Math.floor((now.getTime() + ms(args[2])) / 1000)}:R> **

> ** مدة الروم : ${args[2]} **
`)
  .setColor(`${colorE}`)
  let mm = await message.guild.channels.create(`〢↯・${member.user.username}` , {type:"text"})
  .then(async m => {
  m.setParent(message.guild.channels.cache.find(r=>r.id == 996388001779298324))
  member.roles.add([prv]).catch(err=>{})
  db.set(`prvuser_${member.id}` , member.id)
  db.set(`prvroom_${m.id}` , member.id)
  db.set(`prv_${member.id}_${m.id}`, m.id)
  m.permissionOverwrites.edit(message.guild.roles.everyone , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:false
        })

    m.permissionOverwrites.edit(arab , {
          SEND_MESSAGES:false,
          VIEW_CHANNEL:true
        })
    m.permissionOverwrites.edit(discordstaff , {
          MANAGE_MESSAGES: true,
        })
  m.permissionOverwrites.edit(member.id,{
    SEND_MESSAGES: true,
    MENTION_EVERYONE: true,
    ATTACH_FILES:true
  })

  m.send({content:`<@${member.id}>` , embeds:[embed]}).then(m=> {
    m.pin()
  })
  db.push(`room` , {
  server:message.guild.id,
  id:member.id,
  endsAt:Date.now() + ms(args[2]),
  channelid:m.id
  })
  });
  }
  }
  });




    //////////////////
    client.on("messageCreate" , async message => {
      if(message.content.startsWith(prefix + "ميوت") || message.content.startsWith(prefix + "mute")) {
          if(message.content.startsWith(prefix + "mutes")) return;
      if(message.content.startsWith(prefix + "ميوتات")) return;
          let ch = "1125856665548365865"
          if(ch.includes(message.channel.id)) {
          const guild = message.guild;
          const channel10 = await guild.channels.cache.find(r=>r.name == "♯・شات・الأونرز")
          const now = new Date();
          let args = message.content.split(" ")
          if(!args) return message.reply("**حدد الشخص !**")
          let user = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
          if(!user) return message.reply("**حدد الشخص !**")
          let role = message.guild.roles.cache.find(r=>r.name == "Muted")
          user.roles.add([role]).catch(err=>{})
          db.add(`muteweek_${message.member.id}` , 1)
          db.add(`muteall_${message.member.id}` , 1)

          message.reply(`**تم إسكات ${user} بنجاح !**`)

            let SpecialEmbedLog10 = new Discord.MessageEmbed()
            .setTitle(`**${emj.Right} Add Order Mute !**`)
            .setDescription(`> **${emj.Lift} تم إضافة ميوت لـ ${user} , المشرف المسؤول ${message.author} **
      **${emj.Dot} إيدي الشخص : ${user.id}
      ${emj.Dot} إيدي المشرف المسؤول : ${message.author.id} \n\n${emj.Dot} تاريخ إضافة الميوت : <t:${Math.floor(now.getTime() / 1000)}:d>**`)
            .setColor(`${colorE}`)
            .setTimestamp()

         channel10.send({ embeds: [SpecialEmbedLog10] })
            db.set(`muted_${user.id}` , user.id)
          db.push(`mute` , {
          server: message.guild.id,
          id: user.id,
          endsAt: Date.now() + ms(`5h`),
          })
        }
      }
      });

      client.on("guildMemberAdd" , member => {
        if(db.has(`muted_${member.id}`)) {
          db.push(`mute` , {
            server: member.guild.id,
            id: member.id,
            endsAt: Date.now() + ms(`5h`),
            })
            member.roles.add([member.guild.roles.cache.find(r=>r.name == "Muted")])
        }
      });

      client.on("guildMemberRemove" , async member => {
        if(db.has(`muted_${member.id}`)) {
          if(db.has(`mute`)) {
            const data = await db.get(`mute`)
            for (const x of data) {
            if(x.id == member.id) {
            const index = data.indexOf(x);
            if (index !== -1) {
              data.splice(index, 1);
              await db.set('mute', data);
            }
        }
      }
          }
        }
      });

      async function mute() {
         if(db.has(`mute`)) {
         const data = await db.get(`mute`)
         for (const x of data) {
           let end = x.endsAt
           let g = await x.server
           if(end < new Date()) {
           const guild = await client.guilds.cache.get(g)
           const member = await guild.members.cache.get(x.id)
           const role = await guild.roles.cache.find(r=>r.name == "Muted")
           const channel = await guild.channels.cache.find(r=>r.name == "♯・شات・الأونرز")
           channel.send(`**لقد انتهت مدة الميوت للشخص ${member} .**`)
           member.roles.remove([role]).catch(err=>{})
           //db.delete(`muted_${member.id}`)
           const index = data.indexOf(x);
           if (index !== -1) {
             data.splice(index, 1);
             await db.set('mute', data);
           }

         }
      }
    }
    }
      setInterval(async () => {
        mute()
      },15000)

////////////


client.on('messageCreate', (message) => {
  if (message.content.startsWith('$discount') || message.content.startsWith('$تخفيض') || message.content.startsWith('تخفيض')) {
    const discountPercentage = message.content.split(" ")[1]
    if (isNaN(discountPercentage) || discountPercentage < 0 || discountPercentage > 100) return message.reply('**حدد نسبة بين 0 و 100 !**');
    const originalPrice = message.content.split(" ")[2]
    if (isNaN(originalPrice) || originalPrice <= 0) return message.reply('**حدد رقم للخصم !**');
    const discountAmount = (discountPercentage / 100) * originalPrice;
    const discountedPrice = originalPrice - discountAmount;
    message.reply(`**${emj.Dot} المبلغ الاساسي : ${originalPrice}**\n**${emj.Dot} نسبة الخصم : ${discountPercentage}%**\n${emj.Dot} **قيمة الخصم : ${discountAmount}**\n${emj.Dot} **المبلغ النهائي مع الخصم : ${discountedPrice}**`)
  }
});

/*
 client.on("ready" , () => { 

    const fs = require('fs');

  fs.readFile('database.json', 'utf8', (err, data) => {
    if (err) {
     console.error('Error reading the file:', err);
      return;
   }

   try {
    const dbObject = JSON.parse(data);

     const containsMessage = (key) => key.toLowerCase().startsWith("message");

      for (const key in dbObject) {
        if (containsMessage(key)) {
       delete dbObject[key];
       }
     }

    fs.writeFile('database.json', JSON.stringify(dbObject, null, 2), 'utf8', (err) => {
      if (err) {
         console.error('Error writing to the file:', err);
       } else {
         console.log('Keys containing "message" have been deleted.');
     }
     });
   } catch (error) {
     console.error('Error parsing JSON:', error);
   }
  });
 }) 

*/

let buttonwinner = false

  client.on("messageCreate" , async message => {
    if(message.content == prefix + "زر" || message.content == prefix + "button") {
      const wait = require('node:timers/promises').setTimeout;
      buttonwinner = false
      const embed = new Discord.MessageEmbed()
      .setTitle("**اسرع شخص يضغط الزر : ⚡**")
      .setDescription("**معكم 10 ثواني تضغطون الزر**\n**اسرع واحد يضغط الزر يفوز**")
      .setTimestamp()
      .setColor("333333")
      const row = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
        .setCustomId("r1")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r2")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r3")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r4")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r5")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
      )
      const row2 = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
        .setCustomId("r6")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r7")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r8")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r9")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r10")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
      )
      const row3 = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
        .setCustomId("r11")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r12")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r13")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r14")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r15")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
      )
      const row4 = new Discord.MessageActionRow().addComponents(
        new Discord.MessageButton()
        .setCustomId("r16")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r17")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r18")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r19")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
        new Discord.MessageButton()
        .setCustomId("r20")
        .setLabel("・")
        .setDisabled(true)
        .setStyle("SECONDARY"),
      )
      message.channel.send({components:[row,row2,row3,row4] , embeds:[embed]}).then(async m=> {
      await wait(3500)
      const all = [...row.components , ...row2.components , ...row3.components , ...row4.components]
      const r = Math.floor(Math.random() * all.length);
      const button = all[r]
      button.setStyle("SUCCESS")
      button.setDisabled(false)
      const embed2 = new Discord.MessageEmbed()
      .setTitle("**اسرع شخص يضغط الزر : ⚡**")
      .setDescription("**معكم 10 ثواني تضغطون الزر**\n**اضغط على الزر الأخضر 🟢**")
      .setTimestamp()
      .setColor("GREEN")
      m.edit({components:[row,row2,row3,row4] , embeds:[embed2]})
      const time = setTimeout(() => {
        button.setDisabled(true)
        button.setStyle("DANGER")
        const embed3 = new Discord.MessageEmbed()
        .setTitle("**اسرع شخص يضغط الزر : ⚡**")
        .setDescription("**انتهى الوقت**\n**🔴 لا يوجد اي فائز**")
        .setTimestamp()
         .setColor("WHITE")
        m.edit({components:[row,row2,row3,row4] , embeds:[embed3]})
      },10000)
      client.on("interactionCreate" , interaction => {
        if(interaction.isButton()) {
          if(interaction.customId == `${button.customId}` && buttonwinner == false) {
            buttonwinner = true
            button.setDisabled(true)
            const embed4 = new Discord.MessageEmbed()
            .setTitle("**اسرع شخص يضغط الزر : ⚡**")
            .setDescription(`**👑 | ${interaction.member}**`)
            .setTimestamp()
            .setColor("YELLOW")
            m.edit({components:[row,row2,row3,row4] , embeds:[embed4]})
            interaction.channel.send(`**⚡ | الفائز هو : ${interaction.member}**`)
            interaction.deferUpdate()
            clearTimeout(`${time}`)
          }
        }
      });

      })
    }
  });







client.on("messageCreate" , message => {
  if(!message.author.bot) {
  let channels = [
    "৳・vips","৳・برمجيات","৳・تصاميم","৳・ديسكورد","৳・حسابات","৳・العاب","৳・ٱخرى"
  ]
  if(!channels) return;
  if(channels.includes(message.channel.name)) {
    message.channel.send(`${lineLink}`)
  }
  }
});





client.on("messageCreate", async message => {
  const args = message.content.split(" ")
  const now = new Date()
  if(message.content.startsWith(prefix + 'renew')){
    if (message.member.roles.cache.some(r=> r.id == "1241129866645209140")) {
    let prv = message.guild.roles.cache.find(r=>r.id == "1241129866645209140")
   let member = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
   let channel = message.mentions.channels.first() || message.guild.channels.cache.find(r=>r.id == args[2])
   if(!args[1]) return message.reply(`**منشن شخص !**`)
   if(!member) return message.reply(`**منشن شخص !**`)
    if(!channel) return message.reply(`  **منشن الروم !**`)
    if(!args[2]) return message.reply(` **منشن الروم !**`)

    if(!args[3]) return message.reply(`  **حدد مدة الروم !**`)
    if(!args[3].endsWith("d")) {
    if(!args[3].endsWith("h")) {
    if(!args[3].endsWith("m")) {
      return message.reply(`** حدد الوقت بالأيام - بالساعات أو بالدقائق**`)
    }}}
    if(isNaN(args[3][0])) return message.reply(` **حدد وقت صحيح !**`)

  if(!db.has(`enduser_${member.id}`)) return message.reply(`**هذا الشخص لا يمتلك روم منتهي**`)
  if(!db.has(`endroom_${channel.id}`)) return message.reply(`$**هذا الروم ليس منتهي**`)

  message.reply(` **| تم تجديد الروم ${channel} لـ ${member} لمدة \`${args[3]}\`**`)
  db.set(`prvuser_${member.id}` , member.id)
  db.set(`prvroom_${channel.id}` , member.id)
  let embed = new Discord.MessageEmbed()
  .setDescription(`** Everest \`S\` Private Rooms・الرومات الخاصه**\n\n> ** صاحب الروم : <@${member.id}> **

> ** تم التجديد بواسطة : ${message.member} **

> ** تم التجديد في : <t:${Math.floor(now.getTime() / 1000)}:d> **

> ** ينتهي في : <t:${Math.floor((now.getTime() + ms(args[3])) / 1000)}:R> **

> ** مدة الروم : ${args[3]} **
`)
  .setColor(`${colorE}`)
channel.bulkDelete(100)
  member.roles.add([prv]).catch(err=>{})
  db.delete(`enduser_${member.id}`)
  db.delete(`endroom_${channel.id}`)
  channel.permissionOverwrites.edit(member.id , {
    SEND_MESSAGES:true
  })
  channel.send({content:`<@${member.id}>` , embeds:[embed]}).then(m=> {
    m.pin()
  })
  db.push(`room` , {
    server:message.guild.id,
    id:member.id,
    endsAt:Date.now() + ms(args[3]),
    channelid:channel.id
  })
  }
  }
  });

    client.on("messageCreate" , async message => {
    const args = message.content.split(" ")
    if(message.content.startsWith(prefix + 'close')) {
      let prv = message.guild.roles.cache.find(r=>r.id == "1241129866645209140")
      if (message.member.roles.cache.some(r=> r.id == "1241129866645209140")) {
      let member = message.mentions.members.first() || message.guild.members.cache.find(r=>r.id == args[1])
      let channel = message.mentions.channels.first() || message.guild.channels.cache.find(r=>r.id == args[2])
      if(!args[1]) return message.reply(`${emj.False} | **منشن شخص !**`)
      if(!member) return message.reply(`${emj.False} | **منشن شخص !**`)
      if(!channel) return message.reply(`${emj.False} | **منشن الروم !**`)
      if(!args[2]) return message.reply(`${emj.False} | **منشن الروم !**`)
      if(!db.has(`prvuser_${member.id}`)) return message.reply(`${emj.False} | **هذا الشخص ليس ليده روم خاص**`)
    await message.reply(`${emj.True} | **تم حذف الروم ${channel.name} للشخص ${member} .**`)
    await channel.delete()
    await member.roles.remove([prv])
    if(db.has(`enduser_${member.id}`)) {
      await db.delete(`enduser_${member.id}`)
    }
    if(db.has(`endroom_${channel.id}`)) {
      await db.delete(`endroom_${channel.id}`)
    }
    if(db.has(`prvuser_${member.id}`)) {
      await db.delete(`prvuser_${member.id}`)
    }
    if(db.has(`prvroom_${channel.id}`)) {
      await db.delete(`prvroom_${channel.id}`)
    }
    if(db.has(`prv_${member.id}_${channel.id}`)) {
      await db.delete(`prv_${member.id}_${channel.id}`)
    }
    if(db.has(`room`)) {
      const data = await db.get(`room`)
    for (const x of data) {
      if(x.id == member.id) {
      if(x.channelid == channel.id) {
    const index = data.indexOf(x);
    if (index !== -1) {
      data.splice(index, 1);
      await db.set('room', data);
    }
    }  
    }
    }
  }
    }
  }
    });

client.on("channelDelete" , async channel => {
  if(db.has(`prvroom_${channel.id}`)) {
    let member = channel.guild.members.cache.find(r=>r.id == db.get(`prvroom_${channel.id}`))
     if(db.has(`enduser_${member.id}`)) {
      await db.delete(`enduser_${member.id}`)
    }
    if(db.has(`endroom_${channel.id}`)) {
      await db.delete(`endroom_${channel.id}`)
    }
    if(db.has(`prvuser_${member.id}`)) {
      await db.delete(`prvuser_${member.id}`)
    }
    if(db.has(`prvroom_${channel.id}`)) {
      await db.delete(`prvroom_${channel.id}`)
    }
    if(db.has(`room`)) {
      const data = await db.get(`room`)
    for (const x of data) {
      if(x.id == member.id) {
      if(x.channelid == channel.id) {
    const index = data.indexOf(x);
    if (index !== -1) {
      data.splice(index, 1);
      await db.set('room', data);
    }
    }  
    }
    }
  }
  }
});





client.on('channelCreate', (channel) => {
  if (channel.name.startsWith("ticket-")) {
    let filter = m => m.member.roles.cache.some(r=>r.id == "996364077817405531")
    const collector = channel.createMessageCollector({filter , time:60000 , max:1})
    collector.on('collect', async message => {
        if(message.member.bot) return;
          message.reply(`**سياتبع معك التكت الاداري : ${message.member} <:50:1242766050144292864>

${emj.Warn} يرجى عدم الازعاج بالمنشن او السبام **`)
      })
  }
});

client.on("messageCreate" , message => {
  if(message.content == prefix + "bots") {
    if(message.member.permissions.has("ADMINISTRATOR")) {
    message.guild.members.cache.forEach(member => {
      if(member.user.bot) {
        message.channel.send(`<@${member.id}>`)
      }
    })
  }
  }
})

let mn = '1001642483278688347';/// ايدي رول الي تتمنشن في روم المنتجات

let br = '1001641510359547974';/// ايدي رول الي تتمنشن في روم البروجكتات

let ta = '1001641277852483695'; /// ايدي رول الي تتمنشن في روم التصاميم

const targetRoleId = '996364077817405531'; /// ايدي الرول الي تحذف الطلبات
const logChannelId = ''; /// لوق التصاميم
const brmjeatID = ''; /// لوق برمجيات
const logmntgatID = ''; /// لوق منتجات

client.on('messageCreate', async (message) => {
  if (message.content === '!sendEmbed') {
    const embed = new MessageEmbed()
      .setDescription(`** N7 Talabat - طلـبات Everest

<:74:1242783266348466197> ما هو نوع طلبك؟ 

<:74:1242783266348466197> لطلب منتجات مثل :

<:29:1242766737200644136> حسابات , نيترو , فيزا , العاب , طرق , الخ... , الرجاء الضغط على منتجات


<:74:1242783266348466197> لطلب تصاميم مثل : 

<:29:1242766737200644136> صور سيرفر , افتار , بنر , لوقو قناة , إلخ.... , الرجاء الضغط على تصاميم

<:74:1242783266348466197> لطلب برمجة مثل : 

<:29:1242766737200644136> بروجكتات , مواقع , برمجة , حل ايرورات , صنع اكواد , إلخ..... , الرجاء الضغط على برمجيات

<:emoji_79:1242799096725766154> الرجاء الألتزام ب <#1235870246116528128> قبل أرسال طلبك.
**`)
      .setColor('15FFAF')
      .setImage('https://cdn.discordapp.com/attachments/1113504839696126044/1242782719583191162/20240521_222832.jpg?ex=664f171a&is=664dc59a&hm=b266b3caa5ff6087822d4f61111c764df7d082b33aad9f9dc1346dd753c2a358&');/// رابط الصوره الي تبيها

    const button = new MessageButton()
      .setCustomId('design')
      .setLabel('تصاميم')
      .setStyle('SUCCESS')
      .setEmoji('<:59:1242766285704790136>');

    const button1 = new MessageButton()
      .setCustomId('myButton1')
      .setLabel('برمجيات')
      .setStyle('SUCCESS')
      .setEmoji('<:60:1242766334341677116>');

    const button2 = new MessageButton()
      .setCustomId('myButton2')
      .setLabel('منتجات')
      .setStyle('SUCCESS')
      .setEmoji('<:60:1242766334341677116>');

    const row = new MessageActionRow().addComponents(button , button1 , button2);

    await message.channel.send({ embeds: [embed], components: [row] });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const customId = interaction.customId;

  if (customId === 'design') {
    const addOwnerModal = new Modal()
      .setCustomId('designmodal')
      .setTitle('اضف طلبك');
    const ownerIdInput = new TextInputComponent()
      .setCustomId('designtext')
      .setLabel('الطلب اكتبه هنا')

      .setMaxLength(4000)
      .setStyle(`PARAGRAPH`)
      .setRequired(true)
  
    
    


    const modalRow = new MessageActionRow().addComponents(ownerIdInput);

   addOwnerModal.addComponents(modalRow);


 await interaction.showModal(addOwnerModal);
  } else if (customId === 'deleteButton') {
    if (interaction.member.roles.cache.has(targetRoleId)) {
      await interaction.message.delete();
       const logChannel = interaction.guild.channels.cache.get(logChannelId);
      if (logChannel) {
        const deletedBy = interaction.user.toString();
        const embed = new MessageEmbed()
          .setTitle('تصاميم')
          .setDescription(`الرسالة تم حذفها بواسطة: ${deletedBy}`)
          .setTimestamp();
        await logChannel.send({ embeds: [embed] });
      }
    } else {
      await interaction.reply({ content: 'ليس لديك الإذن الكافي لحذف الرسالة.', ephemeral: true });
    }
  }
});

client.on('interactionCreate', async (i) => {
  if (!i.isModalSubmit()) return;
  if (i.customId === 'designmodal') {
    const myButton = i.fields.getTextInputValue('designtext');
    const user = i.user;
	const design_orders = await db.get("design_orders");
      if(!design_orders) {
         db.set('design_orders', 1);
      } else {
         db.add("design_orders", 1);
}

      
    let er = db.get('er');
	if(!er){
        await db.add('er', 1)
    } else {
       er++;
    await db.set('er', er);
}
      console.log(await db.get("er"))
   

    const mention = user.toString();

    const sl = `<@&${ta}>`;
    const channel = await client.channels.fetch('1235870809432657972'); // روم تصاميم

    const embed = new MessageEmbed()
      .setTitle('تصاميم')
      .setDescription(`**الطلب : ${myButton}\n\nطلب من: ${mention}\n\n الطلب رقم : ${design_orders}**`);

    const deleteButton = new MessageButton()
      .setCustomId('deleteButton')
      .setLabel('حذف الطلب')
      .setStyle('DANGER');

    await channel.send({ content: `${sl}\n`, embeds: [embed], components: [new MessageActionRow().addComponents(deleteButton)] });
      channel.send({content: `https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=665af161&is=66599fe1&hm=61e62a687bfbfa96c7576f2417821c138125815e34a9b65c917bdf02edae229d&`});

    await i.reply({ content: 'تم ارسال الطلب', ephemeral: true });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const customId = interaction.customId;

  if (customId === 'myButton1') {
    const addOwnerModal = new Modal()
      .setCustomId('myButton1')
      .setTitle('اضف طلبك');
    const ownerIdInput = new TextInputComponent()
      .setCustomId('myButton1')
      .setLabel('الطلب اكتبه هنا')
      .setMaxLength(4000)
      .setStyle(`PARAGRAPH`)
      .setRequired(true);

    const modalRow = new MessageActionRow().addComponents(ownerIdInput);

    addOwnerModal.addComponents(modalRow);

    await interaction.showModal(addOwnerModal);
  } else if (customId === 'del') {
    if (interaction.member.roles.cache.has(targetRoleId)) {
      await interaction.message.delete();
       const brmjeat = interaction.guild.channels.cache.get(brmjeatID);
      if (brmjeat) {
        const deletedBy = interaction.user.toString();
        const embed = new MessageEmbed()
          .setTitle('برمجيات')
          .setDescription(`الرسالة تم حذفها بواسطة: ${deletedBy}`)
          .setTimestamp();
        await brmjeat.send({ embeds: [embed] });
      }
    } else {
      await interaction.reply({ content: 'ليس لديك الإذن الكافي لحذف الرسالة.', ephemeral: true });
    }
  }
});

client.on('interactionCreate', async (i) => {
  if (!i.isModalSubmit()) return;
  if (i.customId === 'myButton1') {

    const myButton1 = i.fields.getTextInputValue('myButton1');
    const user = i.user;
      const dev_orders = await db.get("dev_orders");
      if(!dev_orders) {
        db.set('dev_orders', 1)
} else {
     db.add("dev_orders", 1);
}
      
    let or = db.get("or") || 0;
    or++;
    db.set("or", or);

    const mention = user.toString();

    const kl = `<@&${br}>`;
    const channel = await client.channels.fetch('1235870868840648744');/// روم برمجيات

    const embed = new MessageEmbed()
      .setTitle('برمجيات')
      .setDescription(`**الطلب : ${myButton1}\n\nطلب من: ${mention}\n\n الطلب رقم : ${dev_orders}**`)

  const del = new MessageButton()
      .setCustomId('del')
      .setLabel('حذف الطلب')
      .setStyle('DANGER');

    await channel.send({ content: `${kl}\n`, embeds: [embed], components: [new MessageActionRow().addComponents(del)] });
      channel.send({content: 'https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=665af161&is=66599fe1&hm=61e62a687bfbfa96c7576f2417821c138125815e34a9b65c917bdf02edae229d&'});

    await i.reply({ content: 'تم ارسال الطلب', ephemeral: true });
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const customId = interaction.customId;

  if (customId === 'myButton2') {
    const addOwnerModal = new Modal()
      .setCustomId('myButton2')
      .setTitle('اضف طلبك');
    const ownerIdInput = new TextInputComponent()
      .setCustomId('myButton2')
      .setLabel('الطلب اكتبه هنا')
      .setMaxLength(4000)
      .setStyle(`PARAGRAPH`)
      .setRequired(true);

    const modalRow = new MessageActionRow().addComponents(ownerIdInput);

    addOwnerModal.addComponents(modalRow);


    await interaction.showModal(addOwnerModal);
  }else if (customId === 'delt') {
    if (interaction.member.roles.cache.has(targetRoleId)) {
      await interaction.message.delete();
       const logmntgat = interaction.guild.channels.cache.get(logmntgatID);
      if (logmntgat) {
        const deletedBy = interaction.user.toString();
        const embed = new MessageEmbed()
          .setTitle('منتجات')
          .setDescription(`الرسالة تم حذفها بواسطة: ${deletedBy}`)
          .setTimestamp();
        await logmntgat.send({ embeds: [embed] });
      }
    } else {
      await interaction.reply({ content: 'ليس لديك الإذن الكافي لحذف الرسالة.', ephemeral: true });
    }
  }
});

client.on('interactionCreate', async (i) => {
  if (!i.isModalSubmit()) return;
  if (i.customId === 'myButton2') {

    const myButton2 = i.fields.getTextInputValue('myButton2');
    const user = i.user;
      const prudect_orders = db.get("prudect_orders");
      if(prudect_orders) {
 		await db.add("prudect_orders", 1);

} else {
     await db.set('prudect_orders', 1)
}

    let orderNumber = db.get("orderNumber") || 0;
    orderNumber++;
    db.set("orderNumber", orderNumber);

    const mention = user.toString();

    const additionalMessage = `<@&${mn}>`;
    const channel = await client.channels.fetch('1235870737978621963');/// روم منتجات

    const embed = new MessageEmbed()
      .setTitle('منتجات')
      .setDescription(`**الطلب : ${myButton2}\n\nطلب من: ${mention}\n\n الطلب رقم : ${prudect_orders}**`);

    const delt = new MessageButton()
      .setCustomId('delt')
      .setLabel('حذف الطلب')
      .setStyle('DANGER');

     channel.send({ content: `${additionalMessage}\n`, embeds: [embed], components: [new MessageActionRow().addComponents(delt)] });
      channel.send({content: 'https://cdn.discordapp.com/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=665af161&is=66599fe1&hm=61e62a687bfbfa96c7576f2417821c138125815e34a9b65c917bdf02edae229d&'});

    await i.reply({ content: 'تم ارسال الطلب', ephemeral: true });
  }
});
 client.on("messageCreate", async message => {

    if(message.content.startsWith(prefix + "mo")){

        if(!message.member.roles.cache.has("996364077817405531")) return;
        if(message.author.bot || !message.guild) return;

        if(!message.channel.name.startsWith("ticket-")) return;


message.reply(`**تم نقل الروم إلى كتروجي التسليمات <:53:1242766069970501764>**`) 


        setTimeout(() => {

        message.channel.edit({

            parent: ``

        })

        }, 2000)

    }

});
client.on('messageCreate', async msg => {
if(msg.content === prefix + "تسليم"){
if(!msg.member.roles.cache.has('996364077817405531'))return;
msg.reply({content: `**مبروك عزيزي العضو \ الرجاء انتظار تسليمك بدون ازعاج او منشن**`})
msg.delete()
}

})
client.on('messageCreate', async msg => {
if(msg.content === prefix + "خمول"){
if(!msg.member.roles.cache.has('996364077817405531'))return;
msg.reply({content: `** خلال 10 دقائق اذا لم يتم الرد على التذكرة يتم اغلاقها <:3_:1242766733610188872>**`})

}

})
client.on('messageCreate', async message => {
  if (message.content === '!sendm5drat') {
      if(!message.member.permissions.has(`ADMINISTRATOR`))return;
    const row = new MessageActionRow()
      .addComponents(
        new MessageSelectMenu()
          .setCustomId('select')
          .setPlaceholder('لروية المعلومات اضغط هنا')
          .addOptions([
            {
              label: 'الرتب العامة',
              description: 'اضغط لروية الرتب العامة',
              value: 'option1',
            },
            {
              label: 'الرتب المميزة',
              description: 'اضغط لروية الرتب المميزة',
              value: 'option2',
            },
            {
              label: 'الرومات الخاصة',
              description: 'اضغط لروية الرومات الخاصه',
              value: 'option3',
            },
 
{
              label: 'معلومات الاعلانات',
              description: 'اضغط لروية معلومات اعلانات',
              value: 'option4',
            },
{
              label: 'معلومات المنشورات',
              description: 'اضغط لروية معلومات المنشورات',
              value: 'option5',
            },
{
              label: 'الإضافات',
              description: 'اضغط لرورية جميع الإضافات',
              value: 'option6',
            },

          ]),
      );

    const embed = new MessageEmbed()
      .setTitle('# ~ NA7LA S')
      .setColor('#15FFAF')
      .setImage('https://cdn.discordapp.com/attachments/1113504839696126044/1242812458981134376/20240521_222753.jpg?ex=664f32cc&is=664de14c&hm=729f4d31aa0a5a3e26504841d4cae5174c2cb10ccfc813b9c2a41fcfbdbf4201&')
      .setDescription(`** 
 # ~ NA7LA S | المعلومات 

<:29:1242766737200644136> لمعرفة معلومات الرتب العاديه <:21:1242766459592249394> - اضغط على الرتب العامة <:32:1242766743018143795> 
<:29:1242766737200644136> لمعرفة معلومات الرتب المميزة <:21:1242766459592249394> - اضغط على الرتب المميزة <:32:1242766743018143795> 
<:29:1242766737200644136> لمعرفة معلومات الرومات الخاصة <:21:1242766459592249394> - اضغط على الرومات الخاصة <:22:1242766486687322163> 
<:29:1242766737200644136> لمعرفة معلومات الأعلانات <:21:1242766459592249394> - اضغط على معلومات الأعلانات <:31:1242766745744314418> 
<:29:1242766737200644136> لمعرفة معلومات المنشورات <:21:1242766459592249394> - اضغط على معلومات المنشورات <:27:1242766494639722527> 
<:29:1242766737200644136> لمعرفة معلومات العامة <:21:1242766459592249394> - اضغط على الأضافات <:64:1242766344924172330> 

<:emoji_79:1242799096725766154> أن كان لديك استفسار الرجاء التوجه الى <:29:1242766737200644136> <#996376383896957059>  <:46:1242766808847482900> لمساعدتك
**`);

    const message1 = await message.channel.send({ embeds: [embed], components: [row] });
}
});
client.on('interactionCreate', async interaction => {
if(!interaction.isSelectMenu())return;
    if(interaction.customId == "select"){
if(interaction.values == "option1"){
let embed = new MessageEmbed()
.setColor("#15FFAF")
.setTitle("# ~ NA7LA S")
.setImage(`https://media.discordapp.net/attachments/1113504839696126044/1249056554150269070/20240521_222425.jpg?ex=6665ea10&is=66649890&hm=df7091d9e82a77aac8452739317a80442caadb3088979a18eb0e1aa70d5d2811&`)
.setDescription(`**# ~ NA7LA S
معلومات الرتب | # ~ NA7LA S
<@&996368935211503616>

مميزاتها <:emoji_72:1242783131510116401> :
<:74:1242783266348466197> يمكن النشر في كل رومات البيع ما عدا ( تصاميم / برمجيات)

<:74:1242783266348466197> نشر الصور بكل رومات البيع

<:74:1242783266348466197> امكانية المنشن هير في كل رومات البيع

السـعـر : 250k <:emoji:1054764721267556382>


<@&996382617198927873>

مميزاتها <:emoji_72:1242783131510116401> :

<:74:1242783266348466197> امكانية النشر في كل رومات البيع ما عدى ( ⁠تصاميم / برمجيات)

<:74:1242783266348466197> امكانية المنشن في كل رومات البيع

<:74:1242783266348466197> امكانية نشر الصور

السـعـر : 150k <:emoji:1054764721267556382>

<@&996382760564445184>

مميزاتها <:emoji_72:1242783131510116401> :

<:74:1242783266348466197> امكانية النشر في كل رومات البيع ماعدا (تصاميم / برمجيات)

<:74:1242783266348466197> امكانية المنشن هير في كل رومات البيع 

<:74:1242783266348466197> لا يمكن نشر صور

السـعـر : 80k <:emoji:1054764721267556382>

<@&996382954521624666>

مميزاتها <:emoji_72:1242783131510116401> :

<:74:1242783266348466197> امكانية النشر في كل الرومات ماعدا ( ⁠تصاميم / برمجيات)

<:74:1242783266348466197> عدم امكانية نشر صور

<:74:1242783266348466197> عدم امكانية المنشن

السـعـر : 40k <:emoji:1054764721267556382>

<@&997259592176246835>

مميزاتها <:emoji_72:1242783131510116401> :

<:74:1242783266348466197> امكانية النشر في روم (⁠تصاميم)

<:74:1242783266348466197> مع امكانية المنشن هير بروم ( ⁠تصاميم )

<:74:1242783266348466197> مع امكانية نشر صور بروم ( ⁠تصاميم )

السـعـر : 80k <:emoji:1054764721267556382>

<@&997260131962204262>

مميزاتها <:emoji_72:1242783131510116401> :

<:74:1242783266348466197> امكانية النشر بروم (برمجيات)

<:74:1242783266348466197> امكانية المنشن بروم (⁠برمجيات)

<:74:1242783266348466197> امكانية نشر الصور بروم (برمجيات)

السـعـر : 80k <:emoji:1054764721267556382>
<:74:1242783266348466197> التحويل فقط لـ

<@979266698689519618> ( 979266698689519618 )

<:emoji_78:1242783447689461822> لا نتحمل مسؤولية التحويل إلى شخص آخر .**`)


interaction.reply({embeds: [embed], ephemeral: true})
}else if(interaction.values == "option2"){
let embed = new MessageEmbed()
.setColor("#15FFAF")
.setTitle("# ~ NA7LA S")
.setImage(`https://media.discordapp.net/attachments/1113504839696126044/1242813165419499571/20240521_222533-1.jpg?ex=66679734&is=666645b4&hm=855b6ad983767a9965ad02f21aacb8e95cc43777dc0b643c3eec1c111e5e5a3d&`)
.setDescription(`**# ~ NA7LA S
~ NA7LA S | الرتب المميزة
<:74:1242783266348466197> # - NA7LA S : الرتب النادرة

<:74:1242783266348466197> اسم الرتبة النادرة : N7
رتبة بلمنشن : <@&996365835465674792>
<:74:1242783266348466197> السعر : 500,000

المميزات :


<:74:1242783266348466197> تقدر تكتب ف كل الرومات
<:74:1242783266348466197> تقدر تكتب ف رومات البرمجة و التصميم
<:74:1242783266348466197> لون اصفر
<:74:1242783266348466197> (منشور مميز (هير
<:74:1242783266348466197> vip تقدر تنشر كل يوم مره افري ون ف الروم 

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> اسم الرتبه النادرة : N7 SUPERHERO
<:74:1242783266348466197> رتبة بلمنشن : <@&1173940676619157536>
<:74:1242783266348466197> السعر : 1,000,000

المميزات :

<:74:1242783266348466197>تقدر اكتب ف كل الرومات
<:74:1242783266348466197> تقدر تكتب ف رومات البرمجة و التصميم
<:74:1242783266348466197> تقدر تنزل منشور مميز كل يوم منشورين هير و ايفري
<:74:1242783266348466197> لون بنفسجي مميز
<:74:1242783266348466197> vip تقدر تنشر كل يوم مرتين افري ون ف الروم 

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>
<:74:1242783266348466197> ملاحظات : لشراء رتبة يرجى التواصل مع الدعم الفني
<#996376383896957059> .
التحويل فقط ل <@979266698689519618> فقط
أذا قمت بالتحويل لاحد غير الحساب المذكور أعلاه فلن يتم استلامك الرتبة النادرة ولن نتحمل المسؤولية لخطأك .**`)


interaction.reply({embeds: [embed], ephemeral: true})
}else if(interaction.values == "option3"){
let embed = new MessageEmbed()
.setColor("#15FFAF")
.setTitle("# ~ NA7LA S")
.setImage()
.setDescription(`**
# ~ NA7LA S

~ NA7LA S

<:74:1242783266348466197> روم خاص لمدة يوم واحد

<:emoji_79:1242799096725766154> السعر = 50k <:42:1242766803000754177>

<:74:1242783266348466197> روم خاص لمدة اسبوع

<:emoji_79:1242799096725766154> السعر : 250k <:42:1242766803000754177>

<:74:1242783266348466197> تجديد الروم الخاص لمدة اسبوع

<:emoji_79:1242799096725766154> السعر : 200k <:42:1242766803000754177>

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

قوانين الرومات الخاصة <:28:1242766492362342491>

عدم النشر في الروم لمدة يومين يؤدي لحذف الروم

ممنوع ما تشفر الكلمات بالروم الخاص

ممنوع تمنشن ايفري أكثر من مره او هير أكثر من المرات المسموحه لك

يمنع نشر روابط

{ اذا لم تتبع القوانين سوف يتم سحب رومك الخاص ولا يمكنك تجديده الى في الاسبوع القادم }


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

ملاحظة <:emoji_78:1242783447689461822>

في حال تم اعداد الروم الخاص لن يتم استرداد الأموال

للأستفسار و الشراء توجه الى ⁠⌬・الدعم・الفني <:46:1242766808847482900>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> التحويل فقط لـ

@.gg/na7la ( 979266698689519618 )

<:emoji_78:1242783447689461822> لا نتحمل مسؤولية التحويل إلى شخص آخر
**`)


interaction.reply({embeds: [embed], ephemeral: true})
}else if(interaction.values == "option4"){
let embed = new MessageEmbed()
.setColor("#c1e1f3")
.setTitle("# ~ Everest S")
.setImage(`https://media.discordapp.net/attachments/1113504839696126044/1249056481026904144/20240521_222601.jpg?ex=6665e9ff&is=6664987f&hm=04dcc042baf699da34a5b28ba050d8509db20f7bf76e8019814eae18f1a8e27a&`)
.setDescription(`**
معلومات الاعلانات :

<:74:1242783266348466197> # - NA7LA S : معلومات الاعلانات


قسم حزمة الجولد :

<:74:1242783266348466197> منشن هير
<:emoji_79:1242799096725766154> السعر : 100k <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> منشن ايفري ون
<:emoji_79:1242799096725766154> السعر : 200k <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


قسم حزمة السلفر :

<:74:1242783266348466197> قيفاوي في روم ⁠૱・هدايا・الإعلانات مع منشن ايفري ون
<:74:1242783266348466197> مدة القيف اوي 3 ايام
<:74:1242783266348466197> على 100k
<:emoji_79:1242799096725766154> السعر : 400k <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


قسم حزمه بلاتينيوم :

<:74:1242783266348466197> روم خاص لسيرفرك وقيف اوي
<:74:1242783266348466197> مدة القيف اوي 5 ايام
<:74:1242783266348466197> على 500k
<:emoji_79:1242799096725766154> السعر : 1m <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>
قسم حزمة بروكاست :


<:74:1242783266348466197> بروكاست للاونلاين

<:emoji_79:1242799096725766154> السعر : 10$ <:42:1242766803000754177>



<:74:1242783266348466197> بروكاست للكل

<:emoji_79:1242799096725766154> السعر : 25$ <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

قسم حزمة الدايموند

<:74:1242783266348466197> قيف اوي اول كتروجي في السيرفر شرط دخول سيرفرك
<:74:1242783266348466197> مدة القيف اوي 7 ايام
<:74:1242783266348466197> على 5m
<:74:1242783266348466197> 3 منشن افري
<:emoji_79:1242799096725766154> السعر : 10$ <:42:1242766803000754177>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


<:74:1242783266348466197> ملاحظات : لطلب إعلان يرجى التواصل مع الدعم الفني: <#996376383896957059>  <:46:1242766808847482900> فقط.

التحويل فقط لـ <@979266698689519618> فقط .
أذا قمت بالتحويل لاحد غير الحساب المذكور أعلاه فلن يتم عمل الأعلان لك ولن نتحمل المسؤولية لخطأك .

**`)


interaction.reply({embeds: [embed], ephemeral: true})
}else if(interaction.values == "option5"){
let embed = new MessageEmbed()
.setColor("#c1e1f3")
.setTitle("# ~ Everest S")
.setImage(`https://media.discordapp.net/attachments/1113504839696126044/1249056610542682163/20240521_222553-1.jpg?ex=6665ea1e&is=6664989e&hm=f8323df09a8681c9858b8237034923bced633ace11765ec8ca1f3b65acfcef1c&`)
.setDescription(`**
# ~ NA7LA S
معلومات المنشورات :

<:74:1242783266348466197> # - NA7LA S : المنشورات المميزة

<:74:1242783266348466197> منشور هير ( للمتصلين )
<:emoji_79:1242799096725766154> السعر : 100k <:42:1242766803000754177>

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>

<:74:1242783266348466197> منشور ايفري ( للكل )
<:emoji_79:1242799096725766154> السعر : 200k <:42:1242766803000754177>

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>


ملاحظة <:emoji_78:1242783447689461822>

لم يتم عمل اي منشور مخالف لقوانين الديسكورد و السيرفر و قوانين البيع

<:74:1242783266348466197> للأستفسار الرجاء التوجه الى <:29:1242766737200644136> ⁠⌬・الدعم・الفني <:46:1242766808847482900>


<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305>
<:74:1242783266348466197> التحويل فقط لـ

@.gg/na7la ( 979266698689519618 )

<:emoji_78:1242783447689461822> لا نتحمل مسؤولية التحويل إلى شخص آخر .
`)


interaction.reply({embeds: [embed], ephemeral: true})
}else if(interaction.values == "option6"){
let embed = new MessageEmbed()
.setColor("#c1e1f3")
.setTitle("# ~ Everest S")
.setImage(`https://media.discordapp.net/attachments/1113504839696126044/1249056643363115199/20240521_222629.jpg?ex=6665ea26&is=666498a6&hm=fb816e1a4df9f82ac769dec88c9d44e29aeb931db98194f096109e586b143860&`)
.setDescription(`** <:74:1242783266348466197> إضافات | # - Na7la S

<:74:1242783266348466197> رتبة تراست او موثوق : <@&1028594799961444472> 

# مميزاتها :
<:74:1242783266348466197> تكون مميز بين البائعين
<:74:1242783266348466197> تتميز بـ الثقة

# شروطها :
<:74:1242783266348466197> تنشر 15 عملية ناجحة في <#1236645925598793830> 
<:74:1242783266348466197> تجيب 5 آراء عنك في <#1235865566238081024> 

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

<:74:1242783266348466197> <@&1135173094269534228> 
<:74:1242783266348466197> <@&1135173285596893244> 
<:74:1242783266348466197> <@&1135173388948738170> 

# مميزاتها :
<:74:1242783266348466197> تعطيك 3 فرص لكي لا تنسحب رتبتك البيع , بمعنى إنك حصلت على 3 تحذيرات فـ سوف نُزيل منك رتبة واحده من اللايف ويبقى معك اثنين فقط , وكل 3 تحذيرات سوف نُزيل لايف واحد .

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 

# سـ3ـر الايفات :
<:74:1242783266348466197> ثلاث = 100k

<:73:1242783209901789305><:73:1242783209901789305><:73:1242783209901789305> 
# معلومات إضافية :

<:74:1242783266348466197> لإزالة التحذيرات :

<:74:1242783266348466197> <@&996693208111251477> 
<:74:1242783266348466197> <@&996693069183332352> 

<:74:1242783266348466197> لإزالة وارن واحد = 50k

<:74:1242783266348466197> لنقل رتب البيع من حساب إلى آخر = 50k

<:emoji_78:1242783447689461822> ملاحظات : ماتقدر تطلب لايف واحده ! , يأتي ثلاثه مع بعض ( اللايفات ) , لشراء لايفات او لأستلام رتبة تراست او إزالة تحذير او نقل رتبة والخ.. يرجى التواصل مع <#996376383896957059> فقط .

<:74:1242783266348466197> __التحويل فقط لـ <@979266698689519618> 
إذا قُمت بالتحويل لأحد غير الحساب المذكور أعلاه فلن يتم تسليمك اي شي ولن نتحمل المسؤولية لخطأك .__**`)


interaction.reply({embeds: [embed], ephemeral: true})
}
    }})


client.on("messageCreate" , message => {
  if(message.content == prefix + "شراء") {
    let embed = new Discord.MessageEmbed()
    .setColor("#c1e1f3")
    .setTitle("**شراء منتجات Everest S :**")
    .setDescription(`> **اختار نوع المنتج المراد شرائه عبر الازرار في الاسفل سواء كان :**\n\`رتب البيع - المنشورات المميزة - الرومات الخاصة\`\n\n> **اذا كنت تريد الالغاء , اضغط على الزر في الاسفل**\n\n> **اذا كنت تريد شراء رتبة- ازالة تحذيرات - نقل الرتبة ...**\n> **توجه الى <#1241129868515610808>**`)
    .setAuthor({name : `${message.member.user.username}` , iconURL:`${message.member.user.displayAvatarURL()}`})
    .setFooter({text:`${message.guild.name}` , iconURL:`${message.guild.iconURL()}`})
    .setThumbnail(message.guild.iconURL())
    .setTimestamp()
    let row = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
      .setLabel("رتب البيع")
      .setCustomId("buy-roles")
      .setStyle("SUCCESS"),
      new Discord.MessageButton()
      .setLabel("منشورات مميزة")
      .setCustomId("buy-manshor")
      .setStyle("SUCCESS"),
      new Discord.MessageButton()
      .setLabel("الرومات الخاصة")
      .setCustomId("buy-rooms")
      .setStyle("SUCCESS"),
      new Discord.MessageButton()
      .setEmoji(`${emj.False}`)
      .setCustomId("cancel")
      .setStyle("DANGER"),
    )
    message.reply({embeds:[embed] , components:[row]})
  }
});

client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {
    if(interaction.customId == "buy-roles") {
      let row = new Discord.MessageActionRow().addComponents(
        new Discord.MessageSelectMenu()
        .setPlaceholder("Select Role ..")
          .setCustomId("role-select")
          .setMaxValues(1)
          .addOptions([
            {
              label: 'Super S',
              value: 'perfect'
            },
            {
              label: 'Myithic S',
              value: 'gold'
            },
            {
              label: 'Special S',
              value: 'great'
            },
            {
              label: 'Great S',
              value: 'epic'
            },
            {
              label: 'Domen S',
              value: 'normal'
            },
            {
              label: 'Designer S',
              value: 'designer'
            },
            {
              label: 'Developer S',
              value: 'developer'
            }, ])
      )
      let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
      .setEmoji(`${emj.False}`)
      .setCustomId("cancel")
      .setStyle("SECONDARY")

      )
      let embed = new Discord.MessageEmbed()
           .setColor("15FFAF")
    .setTitle("**شراء رتب البيع في Everest S :**")
    .setDescription(`> **اختار الرتبة المراد شرائها عبر القائمة في الاسفل , ومن ثم قم بالتحويل الى 1022493170598154311 **\n\n> **اذا كنت تريد الالغاء , اضغط على الزر في الاسفل**`)
    .setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})
    .setFooter({text:`${interaction.guild.name}` , iconURL:`${interaction.guild.iconURL()}`})
    .setThumbnail(interaction.guild.iconURL())
    .setTimestamp()
      interaction.deferUpdate()
      interaction.message.edit({embeds:[embed] , components:[row , row2]})

    }
        if(interaction.customId == "buy-manshor") {
      if(!interaction.guild.channels.cache.find(r=>r.name == "المنشورات・المميزة")) return interaction.reply({content:`**لا استطيع ايجاد روم المنشورات !**` , ephemeral:true})
      let row = new Discord.MessageActionRow().addComponents(
        new Discord.MessageSelectMenu()
        .setPlaceholder("Select The Type ..")
          .setCustomId("manshor-select")
          .setMaxValues(1)
          .addOptions([
            {
              label: 'Here',
              value: 'here'
            },
            {
              label: 'Everyone',
              value: 'everyone'
            }
          ])
      )
                let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
      .setEmoji(`${emj.False}`)
      .setCustomId("cancel")
      .setStyle("SECONDARY")
      )
      let embed = new Discord.MessageEmbed()
           .setColor("15FFAF")
    .setTitle("**المنشورات المميزة :**")
    .setDescription(`> **اختار نوع المنشن في المنشور المميز سواء كان :**\n\`Here - Everyone\`\n\n> **بعد الاختيار ستظهر لك قائمة , عليك وضع فيها منشورك**\n> **وتجنب وضع اي منشن في المنشور لان البوت يفعلها تلقائيا**`)
    .setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})
    .setFooter({text:`${interaction.guild.name}` , iconURL:`${interaction.guild.iconURL()}`})
    .setThumbnail(interaction.guild.iconURL())
    .setTimestamp()
      interaction.deferUpdate()
      interaction.message.edit({embeds:[embed] , components:[row , row2]})
    }
  }
});

client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {
    if(interaction.customId == "cancel") {
      interaction.message.edit({ content:`**${emj.True} تم الغاء العملية بنجاح !**`})
    }
  }
});

client.on("interactionCreate" , interaction => {
  if(interaction.isSelectMenu()) {
    if(interaction.customId == "role-select") { 
    if(interaction.values == "perfect") {
    let price = `3000000`
    let owner = `1022493170598154311`
    let role = interaction.guild.roles.cache.find(r=>r.id == `1241129866481635476`,`1241129866469048369`)
    if(interaction.member.roles.cache.some(r=>r.id == role.id)) return interaction.reply({content:`**انت تمتلك بالفعل هذه الرتبة !**` , ephemeral:true})
    let filter = m =>  m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
    const collector = interaction.channel.createMessageCollector({filter , time:120000})
    interaction.message.edit({embeds:[new Discord.MessageEmbed() .setColor("#c1e1f3").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})] , components:[]})
    interaction.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      interaction.message.edit({embeds:[] , components:[] , content:`** تم اعطائك الرتبة التي اشتريتها**`})
      interaction.deleteReply()
      interaction.member.roles.add([role])
    });

    const time = setTimeout(() => {
      interaction.message.edit({embeds:[] , components:[] , content:`** انتهى وقت التحويل !**`})
      interaction.deleteReply()
    },120000)

    }
    if(interaction.values == "gold") {
    let price = `300000`
    let owner = `1022493170598154311`
    let role = interaction.guild.roles.cache.find(r=>r.id == `1241129866481635474`,`1241129866469048369`)
          if(interaction.member.roles.cache.some(r=>r.id == role.id)) return interaction.reply({content:`**انت تمتلك بالفعل هذه الرتبة !**` , ephemeral:true})
            let filter = m =>  m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = interaction.channel.createMessageCollector({filter , time:120000})
    interaction.message.edit({embeds:[new Discord.MessageEmbed() .setColor("#c1e1f3").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})] , components:[]})
    interaction.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      interaction.message.edit({embeds:[] , components:[] , content:`** تم اعطائك الرتبة التي اشتريتها**`})
      interaction.deleteReply()
      interaction.member.roles.add([role])
    });

    const time = setTimeout(() => {
      interaction.message.edit({embeds:[] , components:[] , content:`** انتهى وقت التحويل !**`})
      interaction.deleteReply()
    },120000)
    }
    if(interaction.values == "great") {
    let price = `250000`
    let owner = `1022493170598154311`
    let role = interaction.guild.roles.cache.find(r=>r.id == `1241129866481635472`,`1241129866469048369`)
          if(interaction.member.roles.cache.some(r=>r.id == role.id)) return interaction.reply({content:`**انت تمتلك بالفعل هذه الرتبة !**` , ephemeral:true})
            let filter = m =>  m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = interaction.channel.createMessageCollector({filter , time:120000})
    interaction.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})] , components:[]})
    interaction.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      interaction.message.edit({embeds:[] , components:[] , content:`** تم اعطائك الرتبة التي اشتريتها**`})
      interaction.deleteReply()
      interaction.member.roles.add([role])
    });

    const time = setTimeout(() => {
      interaction.message.edit({embeds:[] , components:[] , content:`** انتهى وقت التحويل !**`})
      interaction.deleteReply()
    },120000)
    }
    if(interaction.values == "epic") {
    let price = `200000`
    let owner = `1022493170598154311`
    let role = interaction.guild.roles.cache.find(r=>r.id == `1241129866481635471`,`1241129866469048369`)
        if(interaction.member.roles.cache.some(r=>r.id == role.id)) return interaction.reply({content:`**انت تمتلك بالفعل هذه الرتبة !**` , ephemeral:true})
          let filter = m =>  m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = interaction.channel.createMessageCollector({filter , time:120000})
    interaction.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})] , components:[]})
    interaction.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      interaction.message.edit({embeds:[] , components:[] , content:`** تم اعطائك الرتبة التي اشتريتها**`})
      interaction.deleteReply()
      interaction.member.roles.add([role])
    });

    const time = setTimeout(() => {
      interaction.message.edit({embeds:[] , components:[] , content:`** انتهى وقت التحويل !**`})
      interaction.deleteReply()
    },120000)
    }
    if(interaction.values == "normal") {
          let price = `150000`
    let owner = `1022493170598154311`
    let role = interaction.guild.roles.cache.find(r=>r.id == `1241129866481635471`,`1241129866469048369`)
          if(interaction.member.roles.cache.some(r=>r.id == role.id)) return interaction.reply({content:`**انت تمتلك بالفعل هذه الرتبة !**` , ephemeral:true})
            let filter = m =>  m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = interaction.channel.createMessageCollector({filter , time:120000})
    interaction.message.edit({embeds:[new Discord.MessageEmbed() .setColor("WHITE").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})] , components:[]})
    interaction.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      interaction.message.edit({embeds:[] , components:[] , content:`** تم اعطائك الرتبة التي اشتريتها**`})
      interaction.deleteReply()
      interaction.member.roles.add([role])
    });

    const time = setTimeout(() => {
      interaction.message.edit({embeds:[] , components:[] , content:`** انتهى وقت التحويل !**`})
      interaction.deleteReply()
    },120000)
    }
    if(interaction.values == "designer") {
          let price = `100000`
    let owner = `1022493170598154311`
    let role = interaction.guild.roles.cache.find(r=>r.id == `1241129866481635470`,`1241129866469048369`)
          if(interaction.member.roles.cache.some(r=>r.id == role.id)) return interaction.reply({content:`**انت تمتلك بالفعل هذه الرتبة !**` , ephemeral:true})
            let filter = m =>  m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = interaction.channel.createMessageCollector({filter , time:120000})
    interaction.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})] , components:[]})
    interaction.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      interaction.message.edit({embeds:[] , components:[] , content:`** تم اعطائك الرتبة التي اشتريتها**`})
      interaction.deleteReply()
      interaction.member.roles.add([role])
    });

    const time = setTimeout(() => {
      interaction.message.edit({embeds:[] , components:[] , content:`** انتهى وقت التحويل !**`})
      interaction.deleteReply()
    },120000)
    }
    if(interaction.values == "developer") {
    let price = `100000`
    let owner = `1022493170598154311`
    let role = interaction.guild.roles.cache.find(r=>r.id == `1241129866481635469`,`1241129866469048369`)
          if(interaction.member.roles.cache.some(r=>r.id == role.id)) return interaction.reply({content:`**انت تمتلك بالفعل هذه الرتبة !**` , ephemeral:true})
            let filter = m =>  m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = interaction.channel.createMessageCollector({filter , time:120000})
    interaction.message.edit({embeds:[new Discord.MessageEmbed() .setColor("#c1e1f3").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})] , components:[]})
    interaction.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      interaction.message.edit({embeds:[] , components:[] , content:`**تم أعطائك الرتبة التي اشتريتها**`})
      interaction.deleteReply()
      interaction.member.roles.add([role])
    });

    const time = setTimeout(() => {
      interaction.message.edit({embeds:[] , components:[] , content:`** انتهى وقت التحويل !**`})
      interaction.deleteReply()
    },120000)
    }
  }
  }
});







client.on("interactionCreate" , interaction => {
  if(interaction.isSelectMenu()) {
    if(interaction.customId == "manshor-select") {
      if(interaction.values == "here") {


     const modal1 = new Discord.Modal()
      .setCustomId('here1')
      .setTitle('منشورك المميز : ( منشن هير )')

      const t = new Discord.TextInputComponent()
      .setCustomId('manshhere')
      .setRequired(true)
      .setPlaceholder("ادخل منشورك المميز هنا دون منشن")
      .setLabel("منشورك المميز : ")
      .setStyle('PARAGRAPH')

            const firstActionRow = new MessageActionRow().addComponents(t);
            modal1.addComponents(firstActionRow);

            interaction.showModal(modal1) 
      }
       if(interaction.values == "everyone") {

     const modal = new Discord.Modal()
      .setCustomId('everyone1')
      .setTitle('منشورك المميز : ( منشن افري ون )')

      const tt = new Discord.TextInputComponent()
      .setCustomId('mansheveryone')
      .setRequired(true)
      .setPlaceholder("ادخل منشورك المميز هنا دون منشن")
      .setLabel("منشورك المميز : ")
      .setStyle('PARAGRAPH')

              const firstActionRow1 = new MessageActionRow().addComponents(tt);
              modal.addComponents(firstActionRow1);


            interaction.showModal(modal);   
      }
    }
  }
})

client.on('interactionCreate', async modal => {
  if (!modal.isModalSubmit()) return;
  let channel = modal.guild.channels.cache.find(r=>r.name == "المنشورات・المميزة")
    if(modal.customId == "here1") {
     const manshor = modal.fields.getTextInputValue("manshhere")
    let price = `100000`
    let owner = `1022493170598154311`
    let filter = m =>  m.content.includes(modal.member.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = modal.channel.createMessageCollector({filter , time:120000})
    modal.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})] , components:[]})
    modal.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.True} تم ارسال منشورك !**`})
      channel.send(`${manshor}\n\n**التواصل مع : <@${modal.member.id}>**\n\n@here`)
      channel.send(`${lineLink}`)
      modal.deleteReply()
    });

    const time = setTimeout(() => {
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.False} انتهى وقت التحويل !**`})
      modal.deleteReply()
    },120000)
    }
  if(modal.customId == "everyone1") {
    const manshor = modal.fields.getTextInputValue("mansheveryone")
    let price = `250000`
    let owner = `1022493170598154311`
    let filter = m =>  m.content.includes(modal.member.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = modal.channel.createMessageCollector({filter , time:120000})
    modal.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})] , components:[]})
    modal.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', m => {
      clearTimeout(`${time}`)
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.True} تم ارسال منشورك !**`})
      channel.send(`${manshor}\n\n**التواصل مع : <@${modal.member.id}>**\n\n@everyone`)
      channel.send(`${lineLink}`)
      modal.deleteReply()
    });

    const time = setTimeout(() => {
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.False} انتهى وقت التحويل !**`})
      modal.deleteReply()
    },120000)
  }
});

const duration = ms('7d');

client.on("interactionCreate", async interaction => {
  if (interaction.isButton()) {
    if (interaction.customId == "buy-rooms") {
      if (db.has(`prvuser_${interaction.member.id}`)) return interaction.reply({ content: `**ليدك روم خاص بالفعل !**`, ephemeral: true });

      let fi = interaction.guild.channels.cache.filter(ch => ch.id.startsWith("1241129868092244047"));
      if (fi.size >= 10) {
        return interaction.reply({ content: `**لا يوجد رومات متوفرة حاليا !**`, ephemeral: true });
      }

      if (fi.size < 10) {
        let price = `10`;
        let owner = `1022493170598154311`;
        let filter = m => m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && (m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`));
        const collector = interaction.channel.createMessageCollector({ filter, time: 120000 });

        interaction.message.edit({
          embeds: [new Discord.MessageEmbed()
            .setColor("15FFAF")
            .setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``)
            .setAuthor({ name: `${interaction.member.user.username}`, iconURL: `${interaction.member.user.displayAvatarURL()}` })],
          components: []
        });

        interaction.reply(`c ${owner} ${probot.taxs(price)}`);

        collector.on('collect', async m => {
          clearTimeout(time);

          const now = new Date();
          let prv = interaction.guild.roles.cache.find(r => r.id == 1318611389102948463);
          let arab = interaction.guild.roles.cache.find(r => r.name == ".gg/ev-s");
          let discordstaff = interaction.guild.roles.cache.find(r => r.name == "♛ || Discord Staff :");
          let member = interaction.member;

          interaction.message.edit({ embeds: [], components: [], content: `${emj.True} **| تم إنشاء روم خاص لـ ${member} لمدة 7 ايام**` });

          const endTimestamp = Date.now() + duration;
          const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
          const timestamp = `<t:${Math.floor(sevenDaysFromNow.getTime() / 1000)}:R>`;
          console.log(timestamp);

          let embed = new Discord.MessageEmbed()
            .setDescription(`** Everest \`S\` Private Rooms・الرومات الخاصه**\n\n> ** صاحب الروم : <@${member.id}> **

> ** صنع بواسطة : ${interaction.member} **

> ** صنع في : <t:${Math.floor(now.getTime() / 1000)}:d> **

> ** ينتهي في : ${timestamp} **

> ** مدة الروم : 7 ايام **`)
            .setColor(`${colorE}`);

          let mm = await interaction.guild.channels.create(`〢↯・${member.user.username}`, { type: "text" }).then(async m => {
            m.setParent(interaction.guild.channels.cache.find(r => r.id == "1241129868092244047"));
            member.roles.add([prv]).catch(err => { });
            db.set(`prvuser_${member.id}`, member.id);
            db.set(`prv_${member.id}_${m.id}`, member.id);
            db.set(`prvroom_${m.id}`, member.id);

            m.permissionOverwrites.edit(interaction.guild.roles.everyone, {
              SEND_MESSAGES: false,
              VIEW_CHANNEL: false
            });

            m.permissionOverwrites.edit(arab, {
              SEND_MESSAGES: false,
              VIEW_CHANNEL: true
            });

            m.permissionOverwrites.edit(discordstaff, {
              MANAGE_MESSAGES: true,
            });

            m.permissionOverwrites.edit(member.id, {
              SEND_MESSAGES: true,
              MENTION_EVERYONE: true,
              ATTACH_FILES: true
            });

            m.send({ content: `<@${member.id}>`, embeds: [embed] }).then(tt => {
              tt.pin();
            });

            db.push(`room`, {
              server: interaction.guild.id,
              id: member.id,
              endsAt: endTimestamp,
              channelid: m.id
            });

            interaction.deleteReply();
          });
        });

        const time = setTimeout(() => {
          interaction.message.edit({ embeds: [], components: [], content: `**${emj.False} انتهى وقت التحويل !**` });
          interaction.deleteReply();
        }, 120000);
      }
    }
  }
});

async function saleh() {
  if (db.has(`room`)) {
    const data = await db.get(`room`);
    for (const x of data) {
      let end = x.endsAt;
      let g = await x.server;
      if (end < new Date()) {
        const guild = await client.guilds.cache.get(g);
        const channel = await guild.channels.cache.find(r => r.id == x.channelid);
        if (!channel) return;

        await db.set(`enduser_${x.id}`, x.id);
        await db.set(`endroom_${x.channelid}`, x.channelid);

        await channel.bulkDelete(100);

        let row = new Discord.MessageActionRow().addComponents(
          new Discord.MessageButton()
            .setLabel("تجديد الروم")
            .setCustomId("renew")
            .setStyle("SECONDARY")
        );

        const embed = new Discord.MessageEmbed()
          .setDescription(`** Everest S Rooms Ended・إنتهاء الروم**\n> ** لقد انتهت مدة هذا الروم، لديك مهلة 24 ساعه لتجديده ..**\n> ** للتجديد قم بالضغط على الزر في الاسفل .**`)
          .setColor(`${colorE}`)
          .setTimestamp();

        channel.permissionOverwrites.edit(guild.members.cache.get(x.id), {
          SEND_MESSAGES: false,
        });

        channel.send({ content: `<@${x.id}>`, embeds: [embed], components: [row] }).then(tt => {
          tt.pin();
        });

        const index = data.indexOf(x);
        if (index !== -1) {
          data.splice(index, 1);
          await db.set('room', data);
        }
      }
    }
  }
}
setInterval(async () => {
  saleh();
}, 10000);

client.on("interactionCreate", async interaction => {
  if (interaction.isButton()) {
    if (interaction.customId == "renew") {
      if (!db.has(`prv_${interaction.member.id}_${interaction.channel.id}`)) return interaction.reply({ content: `**لست صاحب هذا الروم !**`, ephemeral: true });

      let price = `200000`;
      let owner = `979266698689519618`;
      let filter = m => m.content.includes(interaction.user.username) && m.content.includes(`$${price}`) && (m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`));
      const collector = interaction.channel.createMessageCollector({ filter, time: 120000 });

      interaction.channel.send({
        embeds: [new Discord.MessageEmbed()
          .setColor("c1e1f3")
          .setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``)
          .setAuthor({ name: `${interaction.member.user.username}`, iconURL: `${interaction.member.user.displayAvatarURL()}` })],
        components: []
      }).then(me => {
        interaction.reply(`c ${owner} ${probot.taxs(price)}`);
        const now = new Date();
        const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        const timestamp = `<t:${Math.floor(sevenDaysFromNow.getTime() / 1000)}:R>`;

        collector.on('collect', async m => {
          clearTimeout(time);

          let prv = interaction.guild.roles.cache.find(r => r.id == 1124855135395401738);
          let member = interaction.member;
          let channel = interaction.channel;

          interaction.reply(`${emj.True} **| تم تجديد الروم ${channel} لـ ${member} لمدة 7 ايام**`);
          db.set(`prvuser_${member.id}`, member.id);
          db.set(`prvroom_${channel.id}`, member.id);

          let embed = new Discord.MessageEmbed()
            .setDescription(`**${emj.Right} Na7la \`S\` Private Rooms・الرومات الخاصه**\n\n> **${emj.Dot} صاحب الروم : <@${member.id}> **

> **${emj.Dot} تم التجديد بواسطة : ${interaction.member} **

> **${emj.Dot} تم التجديد في : <t:${Math.floor(now.getTime() / 1000)}:d> **

> **${emj.Dot} ينتهي في : ${timestamp} **

> **${emj.Dot} مدة الروم : 7 ايام **`)
            .setColor(`${colorE}`);

          channel.bulkDelete(100);
          member.roles.add([prv]).catch(err => { });
          db.delete(`enduser_${member.id}`);
          db.delete(`endroom_${channel.id}`);
          channel.permissionOverwrites.edit(member.id, {
            SEND_MESSAGES: true
          });

          channel.send({ content: `<@${member.id}>`, embeds: [embed] }).then(tt => {
            tt.pin();
          });

          db.push(`room`, {
            server: interaction.guild.id,
            id: member.id,
            endsAt: Date.now() + duration,
            channelid: channel.id
          });

          interaction.deleteReply();
        });

        const time = setTimeout(() => {
          interaction.reply({ embeds: [], components: [], content: `**${emj.False} انتهى وقت التحويل !**`, ephemeral: true });
          interaction.deleteReply();
        }, 120000);
      });
    }
  }
});



client.on("interactionCreate" , interaction => {
  if(interaction.isButton()) {
    if(interaction.customId == "buy-ads") {
      let row = new Discord.MessageActionRow().addComponents(
        new Discord.MessageSelectMenu()
        .setPlaceholder("Select Ur Ads ..")
          .setCustomId("ads-select")
          .setMaxValues(1)
          .addOptions([
            {
              label: 'إعلان منشن هير',
              value: 'adshere',
              description: '100,000 Credits '
            },
            {
              label: 'إعلان منشن ايفري وان',
              value: 'adsevery',
              description: '200,000 Credits'
            },
            {
              label: 'Giveaway - في هدايه الأعلانات',
              value: 'givegive',
              description: '400,000 Credits'
            },
            {
              label: 'Giveaway・روم خاص لـ سيرفرك',
              value: 'pvroom',
              description: '1,000,000 Credits'
            },])
      )
      let row2 = new Discord.MessageActionRow().addComponents(
      new Discord.MessageButton()
      .setEmoji(`${emj.False}`)
      .setCustomId("cancel")
      .setStyle("SECONDARY")

      )
        let embed = new Discord.MessageEmbed()
             .setColor("15FFAF")
      .setTitle("**شراء إعلانات في نحلة شوب :**")
      .setDescription(`> **اختار الاعلان الذي تريده , وستفتح لك قائمة ضع الاعلان بدون اي منشن وقم بالتحويل بعد التحديد .**`)
      .setAuthor({name : `${interaction.member.user.username}` , iconURL:`${interaction.member.user.displayAvatarURL()}`})
      .setFooter({text:`${interaction.guild.name}` , iconURL:`${interaction.guild.iconURL()}`})
      .setThumbnail(interaction.guild.iconURL())
      .setTimestamp()
        interaction.deferUpdate()
        interaction.message.edit({embeds:[embed] , components:[row , row2]})
    }
  }
});
process.on('unhandledRejection', error =>{
  console.log(error)
})
client.on("interactionCreate" , async interaction => {
if(interaction.isSelectMenu()) {
if(interaction.customId == "ads-select") {
if(interaction.values == "adshere") {
     const modal1 = new Discord.Modal()
      .setCustomId('heread')
      .setTitle('اعلانك : ( منشن هير )')

      const t = new Discord.TextInputComponent()
      .setCustomId('head')
      .setRequired(true)
      .setPlaceholder("ادخل اعلانك هنا دون منشن")
      .setLabel("الاعلان : ")
      .setStyle('PARAGRAPH')

       const firstActionRow = new MessageActionRow().addComponents(t);
       modal1.addComponents(firstActionRow);

       interaction.showModal(modal1) 
}
if(interaction.values == "adsevery") {
     const modal2 = new Discord.Modal()
      .setCustomId('everyad')
      .setTitle('اعلانك : ( منشن افري ون )')

      const t2 = new Discord.TextInputComponent()
      .setCustomId('evad')
      .setRequired(true)
      .setPlaceholder("ادخل اعلانك هنا دون منشن")
      .setLabel("الاعلان : ")
      .setStyle('PARAGRAPH')

       const firstActionRow = new MessageActionRow().addComponents(t2);
       modal2.addComponents(firstActionRow);

       interaction.showModal(modal2) 
}
if(interaction.values == "givegive") {
  const modal2 = new Discord.Modal()
  .setCustomId('givead')
  .setTitle('اعلانك : (Giveaway - في هدايه الأعلانات)')

  const t2 = new Discord.TextInputComponent()
  .setCustomId('givead2')
  .setRequired(true)
  .setPlaceholder("ادخل اعلانك هنا دون منشن")
  .setLabel("الاعلان : ")
  .setStyle('PARAGRAPH')

   const firstActionRow = new MessageActionRow().addComponents(t2);
   modal2.addComponents(firstActionRow);

  await interaction.showModal(modal2) 
}
if(interaction.values == "pvroom") {
  const modal2 = new Discord.Modal()
  .setCustomId('roomad')
  .setTitle('اعلانك : (Giveaway・روم خاص لـ سيرفرك)')

  const t2 = new Discord.TextInputComponent()
  .setCustomId('roomad2')
  .setRequired(true)
  .setPlaceholder("ادخل اعلانك هنا دون منشن")
  .setLabel("الاعلان : ")
  .setStyle('PARAGRAPH')

   const firstActionRow = new MessageActionRow().addComponents(t2);
   modal2.addComponents(firstActionRow);

  await interaction.showModal(modal2) 
}
if(interaction.values == "pvgive") {
  const modal2 = new Discord.Modal()
  .setCustomId('pvgive')
  .setTitle('اعلانك : (روم خاص لسيرفك    )')

  const t2 = new Discord.TextInputComponent()
  .setCustomId('pvgive2')
  .setRequired(true)
  .setPlaceholder("ادخل اعلانك هنا دون منشن")
  .setLabel("الاعلان : ")
  .setStyle('PARAGRAPH')
  const t3 = new Discord.TextInputComponent()
  .setCustomId('pvgive3')
  .setRequired(true)
  .setPlaceholder("ادخل اسم الروم هنا")
  .setLabel("الاسم : ")
  .setStyle('SHORT')

   const firstActionRow = new MessageActionRow().addComponents(t2);
   const secondActionRow = new MessageActionRow().addComponents(t3);
   modal2.addComponents(firstActionRow,secondActionRow);

  await interaction.showModal(modal2) 
}
}
}
})

client.on('interactionCreate', async modal => {
  if (!modal.isModalSubmit()) return;
    if(modal.customId == "heread") {
     const manshor = modal.fields.getTextInputValue("head")
    let price = `100000`
    let owner = `979266698689519618`
    let filter = m =>  m.content.includes(modal.member.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = modal.channel.createMessageCollector({filter , time:120000})
    modal.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})] , components:[]})
    modal.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', async m => {
    clearTimeout(`${time}`)
await modal.guild.channels.create(`here-${modal.user.username}`, { type: "GUILD_TEXT" }).then(async (m) => {
m.setParent(modal.guild.channels.cache.find(r => r.id == 1235866663983906871));
m.permissionOverwrites.edit(modal.member, {
    "VIEW_CHANNEL":true,
    "SEND_MESSAGES":false
    })
    m.permissionOverwrites.edit(modal.guild.roles.cache.find(r=>r.id == 1122861235759747115) , {
    "VIEW_CHANNEL":true
    })
    m.permissionOverwrites.edit(modal.guild.roles.everyone , {
    "VIEW_CHANNEL":false
    })
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.True} توجه حالا الى <#${m.id}> !**`})
    let embed = new Discord.MessageEmbed()
    .setAuthor({name:`${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})
    .setDescription(`\`\`\`${manshor}\`\`\``)
    .setFooter({text:`${modal.guild.name}` , iconURL:`${modal.guild.iconURL()}`})
    .setColor("15FFAF")
    let channel = m.guild.channels.cache.get('1110183189982482553')
    channel.send({content: `بدك مثله ؟ شيك <#996376383896957059>`})
    let row = new Discord.MessageActionRow().addComponents(
    new Discord.MessageButton()
    .setLabel("قبول")
    .setCustomId("kbolhe")
    .setStyle("SECONDARY"),
    new Discord.MessageButton()
    .setLabel("رفض")
    .setCustomId("rfdhe")
    .setStyle("SECONDARY"),
    )	
    m.send({ content: `<@&${adsManagerRole}>`, embeds:[embed] , components:[row]}).then(msg => {
    db.set(`ad_${msg.id}` , manshor)
    db.set(`admember_${msg.id}` , modal.member.id)
    })
      modal.deleteReply()
    });
    });
    const time = setTimeout(() => {
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.False} انتهى وقت التحويل !**`})
      modal.deleteReply()
    },120000)
    }
  if(modal.customId == "everyad") {
    const manshor = modal.fields.getTextInputValue("evad")
    let price = `200000`
    let owner = `979266698689519618`
    let filter = m =>  m.content.includes(modal.member.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = modal.channel.createMessageCollector({filter , time:120000})
    modal.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})] , components:[]})
    modal.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', async m => {
      clearTimeout(`${time}`)
await modal.guild.channels.create(`everyone-${modal.user.username}`, { type: "GUILD_TEXT" }).then(async (m) => {
m.setParent(modal.guild.channels.cache.find(r => r.id == 1235866663983906871));
m.permissionOverwrites.edit(modal.member, {
    "VIEW_CHANNEL":true,
    "SEND_MESSAGES":false
    })
    m.permissionOverwrites.edit(modal.guild.roles.cache.find(r=>r.id == 1122861235759747115) , {
    "VIEW_CHANNEL":true
    })
    m.permissionOverwrites.edit(modal.guild.roles.everyone , {
    "VIEW_CHANNEL":false
    })
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.True} توجه حالا الى <#${m.id}> !**`})
    let embed = new Discord.MessageEmbed()
    .setAuthor({name:`${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})
    .setDescription(`\`\`\`${manshor}\`\`\``)
    .setFooter({text:`${modal.guild.name}` , iconURL:`${modal.guild.iconURL()}`})
    .setColor("15FFAF")
    let channel = m.guild.channels.cache.get('1110183189982482553')
    channel.send({content: `بدك مثله ؟ شيك <#996376383896957059>`})
    let row = new Discord.MessageActionRow().addComponents(
    new Discord.MessageButton()
    .setLabel("قبول")
    .setCustomId("kbolev")
    .setStyle("SECONDARY"),
    new Discord.MessageButton()
    .setLabel("رفض")
    .setCustomId("rfdev")
    .setStyle("SECONDARY"),
    )	
    m.send({embeds:[embed] , components:[row]}).then(msg => {
    db.set(`ad_${msg.id}` , manshor)
    db.set(`admember_${msg.id}` , modal.member.id)
    })
      modal.deleteReply()
    });
    });
    const time = setTimeout(() => {
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.False} انتهى وقت التحويل !**`})
      modal.deleteReply()
    },120000)
  }else if(modal.customId == "givead") {
    const manshor = modal.fields.getTextInputValue("givead2")
    let price = `400000`
    let owner = `979266698689519618`
    let filter = m =>  m.content.includes(modal.member.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = modal.channel.createMessageCollector({filter , time:120000})
    modal.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})] , components:[]})
    modal.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', async m => {
      clearTimeout(`${time}`)
      let channel = m.guild.channels.cache.get('1210537674272931860')
      channel.send({content: `**${manshor}** \n @everyone`})
      channel.send({content: `-start <#${channel.id}> 3d 1 100k`})
      channel.send({content: `\`أعلان مدفوع و مالنا أي علاقة بالسيرفرات الي ننشرها\``})
      channel.send({content: `بدك مثله ؟ شيك <#996376383896957059>`})
      modal.message.edit({content: `**تم ارسال منشورك بنجاح ${emj.True}**`,embeds: [],  components: []})
      
    });
    const time = setTimeout(() => {
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.False} انتهى وقت التحويل !**`})
      modal.deleteReply()
    },120000)
  }else if(modal.customId === "roomad"){
    const manshor = modal.fields.getTextInputValue("roomad2")
    let price = `1000000`
    let owner = `979266698689519618`
    let filter = m =>  m.content.includes(modal.member.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = modal.channel.createMessageCollector({filter , time:120000})
    modal.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})] , components:[]})
    modal.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', async m => {
    clearTimeout(`${time}`)
await modal.guild.channels.create(`everyone-${modal.user.username}`, { type: "GUILD_TEXT" }).then(async (m) => {
m.setParent(modal.guild.channels.cache.find(r => r.id == 1235866663983906871));
m.permissionOverwrites.edit(modal.member, {
    "VIEW_CHANNEL":true,
    "SEND_MESSAGES":false
    })
    m.permissionOverwrites.edit(modal.guild.roles.cache.find(r=>r.id == 1122861235759747115) , {
    "VIEW_CHANNEL":true
    })
    m.permissionOverwrites.edit(modal.guild.roles.everyone , {
    "SEND_MESSAGES":false
    })
    m.send({content: `**${manshor}** \n @everyone`})
    m.send({content: `\`أعلان مدفوع و مالنا أي علاقة بالسيرفرات الي ننشرها\``})
    m.send({content: `بدك مثله ؟ شيك <#996376383896957059>`})
    channel.send({content: `-start <#${channel.id}> 3d 1 500k`})
    modal.message.edit({content: `**تم ارسال منشورك بنجاح ${emj.True}**`,embeds: [],  components: []})
    });
    
    });
    const time = setTimeout(() => {
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.False} انتهى وقت التحويل !**`})
      modal.deleteReply()
    },120000)
  } else if(modal.customId === "pvgive"){
    const manshor = modal.fields.getTextInputValue("pvgive2")
    const name = modal.fields.getTextInputValue("pvgive3")
    let price = `10$`
    let owner = `979266698689519618`
    let filter = m =>  m.content.includes(modal.member.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)
        const collector = modal.channel.createMessageCollector({filter , time:120000})
    modal.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})] , components:[]})
    modal.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', async m => {
    clearTimeout(`${time}`)
      await modal.guild.channels.create(`${name}` , {type:"text"}).then(async m => {
    m.setParent(modal.guild.channels.cache.find(r=>r.id == 1235866663983906871))
    m.permissionOverwrites.edit(modal.member , {
    "VIEW_CHANNEL":true,
    "SEND_MESSAGES":false
    })
    m.permissionOverwrites.edit(modal.guild.roles.cache.find(r=>r.id == 1122861235759747115) , {
    "VIEW_CHANNEL":true
    })
    m.permissionOverwrites.edit(modal.guild.roles.everyone , {
    "SEND_MESSAGES":false
    })
    m.send({content: `**${manshor}** \n @everyone`})
    m.send({content: `\`أعلان مدفوع و مالنا أي علاقة بالسيرفرات الي ننشرها\``})
    m.send({content: `-start <#${m.id}> 3d 1 1m`})
    m.send({content: `بدك مثله ؟ شيك <#996376383896957059>`})
    modal.message.edit({content: `**تم ارسال منشورك بنجاح ${emj.True}**`,embeds: [],  components: []})
    });
    
    });
    const time = setTimeout(() => {
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.False} انتهى وقت التحويل !**`})
      modal.deleteReply()
    },120000)
  }
});

client.on("interactionCreate" , interaction => {
if(interaction.isButton()) {
if(interaction.customId == "kbolev") {
let channel = interaction.guild.channels.cache.find(r=>r.id == 1110183189982482553)
let ad = db.get(`ad_${interaction.message.id}`)
channel.send(`${ad}\n\n@everyone`)
channel.send(`\`اعلان مدفوع , ليس لنا اي علاقة بالسيرفرات التي ننشرها\``)

channel.send(`${lineLink}`)
interaction.reply(`**تم ارسال الاعلان !**`)
interaction.channel.send(`**سيتم حذف هذا الروم خلال 5 ثواني ...**`)
if(db.has(`ad_${interaction.message.id}`)) {
db.delete(`ad_${interaction.message.id}`)
}
if(db.has(`admember_${interaction.message.id}`)) {
db.delete(`admember_${interaction.message.id}`)
}
setTimeout(() => {
interaction.channel.delete()
},5000)
}
}
})

client.on("interactionCreate" , interaction => {
if(interaction.isButton()) {
if(interaction.customId == "rfdev") {
let member = interaction.guild.members.cache.find(r=>r.id == db.get(`admember_${interaction.message.id}`))
interaction.reply(`**${member} هناك خطأ في اعلانك**\n**قم بمتابعة المسؤولين لمعرفة ما هو خطأك**`)
}
}
})

client.on("interactionCreate" , interaction => {
if(interaction.isButton()) {
if(interaction.customId == "kbolhe") {
let channel = interaction.guild.channels.cache.find(r=>r.id == 1110183189982482553)
let ad = db.get(`ad_${interaction.message.id}`)
channel.send(`${ad}\n\n@here`)
channel.send(`\`اعلان مدفوع , ليس لنا اي علاقة بالسيرفرات التي ننشرها\``)

channel.send(`${lineLink}`)
interaction.reply(`**تم ارسال الاعلان !**`)
interaction.channel.send(`**سيتم حذف هذا الروم خلال 5 ثواني ...**`)
if(db.has(`ad_${interaction.message.id}`)) {
db.delete(`ad_${interaction.message.id}`)
}
if(db.has(`admember_${interaction.message.id}`)) {
db.delete(`admember_${interaction.message.id}`)
}
setTimeout(() => {
interaction.channel.delete()
},5000)
}
}
})

client.on("interactionCreate" , interaction => {
if(interaction.isButton()) {
if(interaction.customId == "rfdhe") {
let member = interaction.guild.members.cache.find(r=>r.id == db.get(`admember_${interaction.message.id}`))
interaction.reply(`**${member} هناك خطأ في اعلانك**\n**قم بمتابعة المسؤولين لمعرفة ما هو خطأك**`)
}
}
})

client.on("interactionCreate" , interaction => {
if(interaction.isSelectMenu()) {
if(interaction.customId == "ads-select") {
if(interaction.values == "givegive") {
     const modal1 = new Discord.Modal()
      .setCustomId('giveawayad')
      .setTitle('اعلانك : ( هدايا الاعلانات )')

      const t = new Discord.TextInputComponent()
      .setCustomId('givead')
      .setRequired(true)
      .setPlaceholder("ادخل اعلانك هنا دون منشن")
      .setLabel("الاعلان : ")
      .setStyle('PARAGRAPH')

       const firstActionRow = new MessageActionRow().addComponents(t);

       modal1.addComponents(firstActionRow);

       interaction.showModal(modal1) 
}
}
}
})



client.on('interactionCreate', async modal => {
  if (!modal.isModalSubmit()) return;
  let channel = modal.guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة")
    if(modal.customId == "giveawayad") {
    const manshor = modal.fields.getTextInputValue("givead")
    let owner = `979266698689519618`
  let price = 150000
  let filter = m =>  m.content.includes(modal.member.user.username) && m.content.includes(`$${price}`) && m.content.includes(`<@!${owner}>`) || m.content.includes(`<@${owner}>`)

     const collector = modal.channel.createMessageCollector({filter , time:120000})
    modal.message.edit({embeds:[new Discord.MessageEmbed() .setColor("15FFAF").setDescription(`**يرجى التحويل المبلغ المطلوب لـ <@${owner}>**\n**لديك دقيقتين للتحويل والا سيتم الغاء العملية ...**\n\`\`\`c ${owner} ${probot.taxs(price)}\`\`\``).setAuthor({name : `${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})] , components:[]})
    modal.reply(`c ${owner} ${probot.taxs(price)}`)
    collector.on('collect', async m => {
    clearTimeout(`${time}`)
      await modal.guild.channels.create(`∮・3-150k・${modal.member.user.username}` , {type:"text"}).then(async m => {
    m.setParent(modal.guild.channels.cache.find(r=>r.id == 1235866663983906871))
    m.permissionOverwrites.edit(modal.member , {
    "VIEW_CHANNEL":true,
    "SEND_MESSAGES":true
    })
    m.permissionOverwrites.edit(modal.guild.roles.cache.find(r=>r.id == 1122861235759747115) , {
    "VIEW_CHANNEL":true,
    "SEND_MESSAGES":false
    })
    m.permissionOverwrites.edit(modal.guild.roles.everyone , {
    "VIEW_CHANNEL":false
    })
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.True} توجه حالا الى <#${m.id}> !**`})
    let embed = new Discord.MessageEmbed()
    .setAuthor({name:`${modal.member.user.username}` , iconURL:`${modal.member.user.displayAvatarURL()}`})
    .setDescription(`\`\`\`${manshor}\`\`\``)
    .setFooter({text:`${modal.guild.name}` , iconURL:`${modal.guild.iconURL()}`})
    .setColor("15FFAF")
    let row = new Discord.MessageActionRow().addComponents(
    new Discord.MessageButton()
    .setLabel("قبول")
    .setCustomId("kbolgive")
    .setStyle("SECONDARY"),
    new Discord.MessageButton()
    .setLabel("رفض")
    .setCustomId("rfdgive")
    .setStyle("SECONDARY"),
    )	
     m.send({content: `\`أعلان مدفوع و مالنا أي علاقة بالسيرفرات الي ننشرها\``})
    m.send({content: `بدك مثله ؟ شيك <#996376383896957059>`})
    m.send({content: `-start <#${channel.id}> 3d 1 50k`})
    m.send({embeds:[embed] , components:[row]}).then(msg => {
    db.set(`ad_${msg.id}` , manshor)
    db.set(`admember_${msg.id}` , modal.member.id)
    })
      modal.deleteReply()
    });
    });
    const time = setTimeout(() => {
      modal.message.edit({embeds:[] , components:[] , content:`**${emj.False} انتهى وقت التحويل !**`})
      modal.deleteReply()
    },120000)
    }
});


client.on('messageCreate' , async message => {
if(message .channel.id === "1235865566238081024"){
if(message.author.bot)return;
if(message.author.id === "1209774109823606824")return;
let embed = new MessageEmbed()
.setColor(`15FFAF`)
.setThumbnail(message.guild.iconURL())
.setTimestamp()
.setAuthor(`NA7LA S`, message.guild.iconURL())
.setFooter(`NA7LA S`, message.guild.iconURL())
.setDescription(` شكرا لرأيك <:emoji_77:1242783427799810090> \n- **رائي من : ${message.content}**`)
message.channel.send({content: `- ${message.author}`, embeds: [embed]}).then((m) => {
m.react('<:emoji_77:1242783427799810090>')
})
message.channel.send(lineLink)
message.delete()
}

})

client.setMaxListeners(0)

client.on('messageCreate', async msg => {

  if (msg.content.startsWith(prefix + "meet")) {

    // التحقق من صلاحيات المسؤول

    if (!msg.member.permissions.has("ADMINISTRATOR")) return;

    let members = msg.guild.roles.cache.get('996364077817405531').members.map(m => m.id);

    let voicechannel = await msg.guild.channels.cache.get('1001533659880374352')

    for (var i = 0; i < members.length; i++) {

      let member = await msg.guild.members.cache.get(members[i])

      let response = [];

      if (member.voice.channel) {

        response = 'حضر الاجتماع <:53:1242766069970501764> ';

      } else {

        response = 'لم يحضر الاجتماع <:52:1242766106020544542> ';

      }

      let channel = msg.guild.channels.cache.get('1030053111349391410')

      channel.send({

        content: `**${member} ${response}**\n \n `

      })

    }

  }

});
client.on('messageCreate', async msg => {
  if(msg.content === prefix + "sellerrole"){
    if(!msg.member.permissions.has('ADMINISTRATOR'))return;
    let embed = new MessageEmbed()
    .setColor('#15FFAF')
    .setDescription('**للحصول على رتبة مجانا يرجى الضغط على رتبة مجانية <:32:1242766743018143795>**')
    let row = new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setStyle('SUCCESS')
      .setEmoji('1242766743018143795')
      .setCustomId('autorole')
      .setLabel('رتبة مجانية')
    )
    msg.channel.send({embeds: [embed], components: [row]})
  }
})
client.on('interactionCreate', async interaction => {
if(!interaction.isButton())return;
if(interaction.customId == 'autorole'){
  let role = interaction.guild.roles.cache.get('996382617198927873')
  if(interaction.member.roles.cache.has('996382617198927873'))return interaction.reply({content: `**انت لديك الرول بلفعل :x:**`, ephemeral: true})
  interaction.member.roles.add('996382617198927873')
  interaction.reply({content: `**تم اضافة الرتبه بنجاح**`, ephemeral: true})
  
}
})
client.on('messageCreate', async msg => {
if(msg.content === prefix + "slowmode"){
if(!msg.member.permissions.has('ADMINISTRATOR'))return;
 let manshor = msg.guild.channels.cache.find(r=>r.name == "৳・المنشورات・المميزة")
        
    let vips =  msg.guild.channels.cache.find(r=>r.name == "৳・vips")
    let programming =  msg.guild.channels.cache.find(r=>r.name == "৳・برمجيات")
    let discord =   msg.guild.channels.cache.find(r=>r.name == "৳・ديسكورد")
     let accounts =  msg.guild.channels.cache.find(r=>r.name == "৳・حسابات")
     let designs =  msg.guild.channels.cache.find(r=>r.name == "৳・تصاميم")
      //msg.guild.channels.cache.find(r=>r.name == "❖・عملات").delete()
     let games =  msg.guild.channels.cache.find(r=>r.name == "৳・العاب")
      //msg.guild.channels.cache.find(r=>r.name == "❖・طرق").delete()
     let others =  msg.guild.channels.cache.find(r=>r.name == "৳・ٱخرى")
if(!manshor)return;
if(!vips)return;
if(!programming)return;
   if(!discord)return;
    if(!accounts)return;
       if(!designs)return;
    if(!games)return;
       if(!others)return;
 manshor.setRateLimitPerUser(3600)
    vips.setRateLimitPerUser(3600)
    programming.setRateLimitPerUser(3600)
    discord.setRateLimitPerUser(3600)
    accounts.setRateLimitPerUser(3600)
    designs.setRateLimitPerUser(3600)
    games.setRateLimitPerUser(3600)
    others.setRateLimitPerUser(3600)
    msg.reply({content: `تم وضع سلو مود للرومات لمده ساعه بنجأح`})
}


})
client.on('channelCreate', async channel => {
  if(channel.name.startsWith(`ticket-`)){
    if(channel.parentId !== "1206869761422655498")return;
  
    let embed = new MessageEmbed()
    .setColor('#FFDE54')
    .setThumbnail(channel.guild.iconURL())
    .setFooter(channel.guild.name,channel.guild.iconURL())
    .setDescription(`**
      - اهلا بك في اختبار نحلة شوب لـقضاة
      

      - يرجى أولا الضغط على الزر الاول تعبئة ما يوجد فيه بحذر .


      - وايضا الضغط على الزر الثاني و الثالث ، وإكمال الإختبار عن طريق خبرتك في القضاة !
**`)
let row = new MessageActionRow()
.addComponents(
  new MessageButton()
  .setLabel('الاختبار الاول')
  .setCustomId('m5drat1')
  .setStyle('SUCCESS'),
  new MessageButton()
  .setLabel('الاختبار الثاني')
  .setCustomId('m5drat2')
  .setStyle('SUCCESS')

)
setTimeout(() => {
  channel.send({embeds: [embed], components: [row]})
}, 2000)
  }
})
client.on('interactionCreate', async interaction => {
  if(interaction.isButton()){
      if(interaction.customId === "m5drat1"){

const modal = new Modal()
    .setCustomId('firsttest')
    .setTitle('تقديم قضاء');
          const question = new TextInputComponent()
    .setCustomId('1')
     
    .setLabel(" اشرح لي الية عمل القضاة ؟")
      
    .setStyle('SHORT');
          const question2 = new TextInputComponent()
    .setCustomId('2')
     
    .setLabel("ماذا تفعل اذا قام النصاب بغلق التذكرة . ؟")
      
    .setStyle('SHORT');
          const question3 = new TextInputComponent()
    .setCustomId('3')
     
    .setLabel("ماذا تفاعل اذا قام النصاب بالسب و الـشتم؟ ")
      
    .setStyle('SHORT');
          const question4 = new TextInputComponent()
    .setCustomId('4')
     
    .setLabel("كيف تضيف الشخص إلى التذكرة ؟")
      
    .setStyle('SHORT');
          const question5 = new TextInputComponent()
    .setCustomId('5')
     
    .setLabel("كيف تزيل الشخص من التذكرة . ؟")
      
    .setStyle('SHORT');
          const m5drat = new MessageActionRow().addComponents(question);
  const m5drat2 = new MessageActionRow().addComponents(question2);
      const m5drat3 = new MessageActionRow().addComponents(question3);
      const m5drat4 = new MessageActionRow().addComponents(question4);
      const m5drat5 = new MessageActionRow().addComponents(question5);
      modal.addComponents(m5drat, m5drat2,m5drat3,m5drat4,m5drat5);
  await interaction.showModal(modal);




      }else   if(interaction.customId === "m5drat2"){

          const modal = new Modal()
                      .setCustomId('secondtest')
                      .setTitle('تقديم مشهر');
                      const question = new TextInputComponent()
                      .setCustomId('11')
                     
                      .setLabel("كيف تـشهير النصاب؟")
                      
                      .setStyle('SHORT');
                      const question2 = new TextInputComponent()
                      .setCustomId('21')
                     
                      .setLabel("ماذا تفعل اذا النصاب جَلب ادلة تثبت انه بريء")
                      
                      .setStyle('SHORT');
                      const question3 = new TextInputComponent()
                      .setCustomId('31')
                     
                      .setLabel("عندما تحتاج الى مساعده الى من تتجه")
                      
                      .setStyle('SHORT');
                      const question4 = new TextInputComponent()
                      .setCustomId('41')
                     
                      .setLabel("ماهي اسباب التشهير؟")
                      
                      .setStyle('SHORT');
                      const question5 = new TextInputComponent()
                      .setCustomId('51')
                     
                      .setLabel("كم من الممكن اعطاء مهله للنصاب اذا كان { أوفلاين - أونلاين }")
                      
                      .setStyle('SHORT');
                      const m5drat = new MessageActionRow().addComponents(question);
                  const m5drat2 = new MessageActionRow().addComponents(question2);
                  const m5drat3 = new MessageActionRow().addComponents(question3);
                  const m5drat4 = new MessageActionRow().addComponents(question4);
                  const m5drat5 = new MessageActionRow().addComponents(question5);
                  modal.addComponents(m5drat, m5drat2,m5drat3,m5drat4,m5drat5);
                  await interaction.showModal(modal);
          
          
          
          
                  }
  }
})
client.on('interactionCreate', async interaction => {
	if (!interaction.isModalSubmit()) return;

	if (interaction.customId === 'firsttest') {
		const question = interaction.fields.getTextInputValue('1');
        const question2 = interaction.fields.getTextInputValue('2');
        const question3 = interaction.fields.getTextInputValue('3');
        const question4 = interaction.fields.getTextInputValue('4');
        const question5 = interaction.fields.getTextInputValue('5');
        let channel = interaction.guild.channels.cache.get('1256555618106347610')
        let embed = new MessageEmbed()
        .setColor('#FFDE54')
        .addFields(
            { name: 'اشرح لي عمل القضاة', value: `${question}` },
            { name: 'ماذا تفعل اذا قام النصاب بغلق التذكرة .', value: `${question2}` },
            { name: 'ماذا تفاعل اذا قام النصاب بالسب و الـشتم؟', value: `${question3}`, inline: true },
            { name: 'كيف تضيف الشخص إلى التذكرة', value: `${question4}`, inline: true },
            { name: 'كيف تزيل الشخص من التذكرة .', value: `${question5}`, inline: true },
        )
        .setTitle(interaction.user.username)
        .setFooter(interaction.guild.name,interaction.guild.iconURL())
        .setThumbnail(interaction.guild.iconURL())
        .setTimestamp()
        channel.send({embeds: [embed]})
        let row = new MessageActionRow()
.addComponents(
  new MessageButton()
  .setLabel('الاختبار الاول')
  .setCustomId('m5drat1')
  .setStyle('SECONDRY')
  .setDisabled(true),
  new MessageButton()
  .setLabel('الاختبار الثاني')
  .setCustomId('m5drat2')
  .setStyle('SUCCESS')
 

)
interaction.message.edit({components: [row]})
	}else if (interaction.customId === 'secondtest') {
		const question = interaction.fields.getTextInputValue('11');
        const question2 = interaction.fields.getTextInputValue('21');
        const question3 = interaction.fields.getTextInputValue('31');
        const question4 = interaction.fields.getTextInputValue('41');
        const question5 = interaction.fields.getTextInputValue('51');
        let channel = interaction.guild.channels.cache.get('1256555618106347610')
        let embed = new MessageEmbed()
        .setColor('#FFDE54')
        .addFields(
            { name: 'كيف تـشهير النصاب؟', value: `${question}` },
            { name: 'ماذا تفعل اذا النصاب جَلب ادلة تثبت انه بريء', value: `${question2}` },
            { name: 'عندما تحتاج الى مساعده الى من تتجه', value: `${question3}`, inline: true },
            { name: 'ماهي اسباب التشهير؟', value: `${question4}`, inline: true },
            { name: 'كم من الممكن اعطاء مهله للنصاب اذا كان { أوفلاين - أونلاين }', value: `${question5}`, inline: true },
        )
        .setTitle(interaction.user.username)
        .setFooter(interaction.guild.name,interaction.guild.iconURL())
        .setThumbnail(interaction.guild.iconURL())
        .setTimestamp()
        channel.send({embeds: [embed]})
    }
});

let autoline_channel = ['1262287540635963423','1262287542628257865','1262287544759095438','1262287546843664414','1262287548559134802','1262287550228201543','1262287552635994173','1262287554250543188'] // ايدي الروم
let line = `https://media.discordapp.net/attachments/1113504839696126044/1242779260486160384/20240521_223046.png?ex=66aa0b61&is=66a8b9e1&hm=a3e612cb1c4205927cdc155c4ff32c83226e87cd71d60ed4e82b4b56e0cf9c01&`//رابط الخط

client.on(`messageCreate`, async message => {
        if(message.channel.type === "DM"|| message.author.bot) return
        if(autoline_channel.includes(message.channel.id)) {
                message.channel.send({files : [line]})
        }
})